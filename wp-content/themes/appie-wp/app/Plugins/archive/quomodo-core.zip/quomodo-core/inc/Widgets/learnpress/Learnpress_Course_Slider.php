<?php
namespace Element_Ready_Pro\Widgets\learnpress;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit;
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

class Learnpress_Course_Slider extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public $base;

    public function get_name() {
        return 'element-ready-lp-course-slider';
    }

    public function get_title() {
        return esc_html__( 'ER Course Slider', 'element-ready-pro' );
    }

    public function get_icon() { 
        return 'eicon-post-slider';
    }

    public function get_categories() {
      return [ 'element-ready-pro' ];
   }
  
   public function get_script_depends(){
         
         return [
          'slick',
          'element-ready-core'
         ];
   }
   
   public function get_style_depends(){
         
         return [
          'slick',
          'element-ready-learnpress'
        ];
   }

    	// Get list courses category
      public function course_category(){

        if(!defined('LP_COURSE_CPT')){
          return [];
        }
        
        $tax_terms = get_terms('course_category', array('hide_empty' => false));
        $category_list = [];
         
        foreach($tax_terms as $term_single) {      
          $category_list[$term_single->term_id] = [$term_single->name];
         
        }
        
        return $category_list;
        }

    protected function register_controls() {

    

      $this->start_controls_section(
        'content',
        [
          'label' => esc_html__( 'Courses', 'element-ready-pro' )
        ]
      );
  

          $this->add_control(
            'layout',
            [
              'label'   => esc_html__( 'Layout', 'element-ready-pro' ),
              'type'    => Controls_Manager::SELECT,
              'options' => [
                'style1'         => esc_html__( 'Style 1', 'element-ready-pro' ),
              
              ],
              'default' => 'style1'
            ]
          );

          $this->add_control(
            'slider_on',
            [
                'label'     => esc_html__('Slider', 'element-ready-pro'),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                'label_off' => esc_html__('No', 'element-ready-pro'),
                'default'   => 'yes',
            
            ]
        );
  
          $this->add_control(
            'order',
            [
              'label'   => esc_html__( 'Order By', 'element-ready-pro' ),
              'type'    => Controls_Manager::SELECT,
              'options' => [
                'popular'  => esc_html__( 'Popular', 'element-ready-pro' ),
                'latest'   => esc_html__( 'Latest', 'element-ready-pro' ),
              ],
              'default' => 'latest',
              'condition' => array(
                'layout' => ['style1', 'tabs']
              )
            ]
          );
   
          $this->add_control(
            'limit',
            [
              'label'   => esc_html__( 'Limit Number of Courses', 'element-ready-pro' ),
              'type'    => Controls_Manager::NUMBER,
              'default' => 8,
              'min'     => 1,
              'step'    => 1,
              'condition' => array(
                'layout' => ['style1', 'tabs']
              )
            ]
          );
  
          $this->add_control(
            'cat_id',
            [
              'label'     => esc_html__( 'Select Category', 'element-ready-pro' ),
              'type'      => Controls_Manager::SELECT2,
              'options'   => $this->course_category(),
              'multiple'    => true,
              'label_block' => true,
              'default'     => 'all',
              'condition' => array(
                'layout' => ['style1']
              )
            ]
          );

          $this->add_control(
            'course_list',
            [
              'label'     => esc_html__( 'Select Category', 'element-ready-pro' ),
              'type'      => Controls_Manager::SELECT,
              'options'   => $this->course_list(),
              'condition' => array(
                'layout' => ['grid-single']
              )
            ]
          );

            $this->add_control(
              'featured',
              [
                'label'        => esc_html__( 'Display Featured Courses?', 'element-ready-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
                'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
                'return_value' => 'yes',
                'default'      => '',
                'condition' => array(
                  'layout' => ['style1', 'tabs']
                )
              ]
            );
  
     
          $this->add_control(
              'course_rating_show',
              [
                  'label'        => esc_html__( 'Rating', 'element-ready-pro' ),
                  'type'         => Controls_Manager::SWITCHER,
                  'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
                  'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
                  'return_value' => 'yes',
                  'default'      => 'yes',
                  'condition' => array(
                    'layout' => ['style1', 'tabs']
                  )
              ]
          );

          $this->add_control(
            'show_content',
            [
                'label'        => esc_html__( 'Show Content', 'element-ready-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
                'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition' => array(
                  'layout' => ['style1', 'tabs']
                )
            ]
        );

        $this->add_control(
          'content_limit',
          [
            'label'   => esc_html__( 'Content Limit', 'element-ready-pro' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 8,
            'min'     => 1,
            'step'    => 1,
            'condition' => array(
              'show_content' => ['yes']
            )
          ]
        );

        $this->add_control(
          'show_author',
          [
              'label'        => esc_html__( 'Show Author', 'element-ready-pro' ),
              'type'         => Controls_Manager::SWITCHER,
              'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
              'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
              'return_value' => 'yes',
              'default'      => 'yes',
              'condition' => array(
                'layout' => ['style1', 'tabs']
              )
          ]
        );

        $this->add_control(
          'background_shape',
          [
              'label' => esc_html__( 'Background Shape', 'element-ready-pro' ),
              'type'  => \Elementor\Controls_Manager::MEDIA,
          ]
        );

        
		$this->add_control(
			'lesson_icon',
			[
				'label' => __( 'Lesson Icon', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-book',
					'library' => 'solid',
				],
			]
    );
    
    $this->add_control(
			'student_icon',
			[
				'label' => __( 'Student Icon', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-user',
					'library' => 'solid',
				],
			]
		);

      
     
      $this->end_controls_section();
      
      
      $this->start_controls_section(
        'course_content_sort', [
          'label'	 => esc_html__( 'Course Detail Sort', 'element-ready-pro' ),
          
        ]
      );

      $this->add_control(
        'panel_more_options',
        [
          'label' => esc_html__( 'Important', 'element-ready-pro' ),
          'type' => \Elementor\Controls_Manager::RAW_HTML,
          'raw' => esc_html__( 'Please Check content detail in style tab display -> flex.', 'element-ready-pro' ),
          'content_classes' => 'content-details',
        ]
      );

      $this->add_control(
        'meta_order',
        [
          'label'   => esc_html__( 'Lesson and Student ', 'element-ready-pro' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 1,
          'min'     => 1,
          'step'    => 1,
          'selectors'	 => [
            '{{WRAPPER}} .fcf-bottom' => 'order: {{VALUE}};',
         
          ],
        ]
      );
      $this->add_control(
        'title_order',
        [
          'label'   => esc_html__( 'Title Sort', 'element-ready-pro' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 1,
          'min'     => 1,
          'step'    => 1,
          'selectors'	 => [
            '{{WRAPPER}} .title' => 'order: {{VALUE}};',
         
          ],
        ]
      ); 
      
      $this->add_control(
        'content_order',
        [
          'label'   => esc_html__( 'Content Sort', 'element-ready-pro' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 1,
          'min'     => 1,
          'step'    => 1,
          'selectors'	 => [
            '{{WRAPPER}} .content' => 'order: {{VALUE}};',
         
          ],
        ]
      );
      
      $this->add_control(
        'author_order',
        [
          'label'   => esc_html__( 'Author Sort', 'element-ready-pro' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 1,
          'min'     => 1,
          'step'    => 1,
          'selectors'	 => [
            '{{WRAPPER}} .author' => 'order: {{VALUE}};',
         
          ],
        ]
      );
      
      
      $this->add_control(
        'prices_order',
        [
          'label'   => esc_html__( 'Price Rating Sort', 'element-ready-pro' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 1,
          'min'     => 1,
          'step'    => 1,
          'selectors'	 => [
            '{{WRAPPER}} .price-rate' => 'order: {{VALUE}};',
         
          ],
        ]
      );

      $this->end_controls_section();

      $this->slick_slider_option(); 
  
     
      $this->start_controls_section(
        'title_style', [
          'label'	 => esc_html__( 'Course Title', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          'title_color', [
            'label'		 => esc_html__( 'Title color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .course-details .title a' => 'color: {{VALUE}};',
              '{{WRAPPER}} .course-details .title' => 'color: {{VALUE}};',
            ],
          ]
        );

        $this->add_control(
          'title_hover_color', [
            'label'		 => esc_html__( 'Title hover color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .course-details .title:hover a' => 'color: {{VALUE}};',
             
            ],
          ]
        );
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'title_typography',
          'selector'	 => '{{WRAPPER}} .course-details .title a',
          ]
        );
   
        $this->add_responsive_control(
          'title_margin',
          [
            'label' => esc_html__( 'Title margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .course-details .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              
            ],
          ]
        );

        $this->add_responsive_control(
          'title_back_padding',
          [
            'label' => esc_html__( 'Padding', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .course-details .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              
            ],
          ]
        );

        
      
      $this->end_controls_section();

      $this->start_controls_section(
        '_content_style', [
          'label'	 => esc_html__( 'Course Content', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

            $this->add_control(
              '_content_color', [
                'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
                'type'		 => Controls_Manager::COLOR,
                'selectors'	 => [
                  '{{WRAPPER}} .course-details .content' => 'color: {{VALUE}};',
                
                ],
              ]
            );
         
            $this->add_group_control(
              Group_Control_Typography::get_type(), [
              'name'		 => '_course_content_typography',
              'selector'	 => '{{WRAPPER}} .course-details .content',
              ]
            );
   
            $this->add_responsive_control(
              '_content_margin',
              [
                'label' => esc_html__( 'Margin', 'element-ready-pro' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                  '{{WRAPPER}} .course-details .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
                ],
              ]
            );

            $this->add_responsive_control(
              '__content_padding',
                [
                  'label' => esc_html__( 'Padding', 'element-ready-pro' ),
                  'type' => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px', '%', 'em' ],
                  'selectors' => [
                    '{{WRAPPER}} .course-details .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                  ],
                ]
            );
   
      
      $this->end_controls_section();

      $this->start_controls_section(
        'category_meta_style', [
          'label'	 => esc_html__( 'Category', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          '_category_meta_color', [
            'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .ci-thumb .c-cate' => 'color: {{VALUE}};',
             
            
            ],
          ]
        );

        $this->add_control(
          'category_hover_color', [
            'label'		 => esc_html__( 'Hover Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .c-cate:hover' => 'color: {{VALUE}};',
            ],
          ]
        );

        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'category_meta_typography',
          'selector'	 => '{{WRAPPER}} .ci-thumb .c-cate',
          ]
        );  

     
        $this->add_control(
          'categhory_bg_color', [
            'label'		 => esc_html__( 'Background color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .ci-thumb .c-cate' => 'background-color: {{VALUE}};',
             
             
            ],
          ]
          );

          $this->add_control(
            'categhory_hover_bg_color', [
              'label'		 => esc_html__( 'Hover Background', 'element-ready-pro' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ci-thumb .c-cate:hover' => 'background-color: {{VALUE}};',
              
                
              ],
            ]
          ); 
          
          $this->add_responsive_control(
            'category_margin',
            [
              'label' => esc_html__( 'Margin', 'element-ready-pro' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .ci-thumb .c-cate' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
              ],
            ]
          );

          $this->add_responsive_control(
            'category_padding',
            [
              'label' => esc_html__( 'Padding', 'element-ready-pro' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .ci-thumb .c-cate' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
              ],
            ]
          );

      $this->end_controls_section();

      $this->start_controls_section(
        'lesson_meta_style', [
          'label'	 => esc_html__( 'Lesson', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );
      $this->add_control(
        'lesson_meta_color', [
          'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .element-ready-lesson:not(i)' => 'color: {{VALUE}};',
          ],
        ]
      );

    

      $this->add_control(
        'lesson_hover_color', [
          'label'		 => esc_html__( 'Hover Color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .element-ready-lesson:hover:not(i)' => 'color: {{VALUE}};',
           
           
          ],
        ]
        );
  
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'lesson_meta_typography',
          'selector'	 => '{{WRAPPER}} .element-ready-lesson',
          ]
        );

        $this->add_control(
          'lesson_icon_meta_color', [
            'label'		 => esc_html__( 'Icon Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .element-ready-lesson i' => 'color: {{VALUE}};',
            ],
          ]
        );

        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'lesson_icon_meta_typography',
          'selector'	 => '{{WRAPPER}} .element-ready-lesson i',
          ]
        );

        $this->add_responsive_control(
          'lesson_margin',
          [
            'label' => esc_html__( 'Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
             
              '{{WRAPPER}} .fcf-bottom .element-ready-lesson' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'lesson_padding',
          [
            'label' => esc_html__( 'Padding', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              
              '{{WRAPPER}} .fcf-bottom .element-ready-lesson' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

      $this->end_controls_section();

      $this->start_controls_section(
        'students_meta_style', [
          'label'	 => esc_html__( 'Students', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

      $this->add_control(
        'students_meta_color', [
          'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
           
            '{{WRAPPER}} .element-ready-students:not(i)' => 'color: {{VALUE}};',
           
          ],
        ]
      );

      $this->add_control(
        'students_hover_color', [
          'label'		 => esc_html__( 'Hover Color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
          
            '{{WRAPPER}} .fcf-bottom .element-ready-students:hover' => 'color: {{VALUE}};',
           
          ],
        ]
        );
  
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'students_meta_typography',
          'selector'	 => '{{WRAPPER}} .fcf-bottom .element-ready-students',
          ]
        );

        $this->add_control(
          'students_icon_meta_color', [
            'label'		 => esc_html__( 'Icon Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
            
              '{{WRAPPER}} .fcf-bottom .element-ready-students i' => 'color: {{VALUE}};',
             
            ],
          ]
        );
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'students_icon_meta_typography',
          'selector'	 => '{{WRAPPER}} .fcf-bottom .element-ready-students i',
          ]
        );

        $this->add_responsive_control(
          'students_margin',
          [
            'label' => esc_html__( 'Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              
              '{{WRAPPER}} .fcf-bottom .element-ready-students' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'students_padding',
          [
            'label' => esc_html__( 'Padding', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              
              '{{WRAPPER}} .fcf-bottom .element-ready-students' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

      $this->end_controls_section();

      $this->start_controls_section(
        'price_meta_style', [
          'label'	 => esc_html__( 'Price', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );
      
            $this->add_control(
              'price_meta_color', [
                'label'		 => esc_html__( 'Price Color', 'element-ready-pro' ),
                'type'		 => Controls_Manager::COLOR,
                'selectors'	 => [
               
                  '{{WRAPPER}} .course-price span' => 'color: {{VALUE}};',
                
                ],
              ]
            );

            $this->add_group_control(
              Group_Control_Typography::get_type(), [
              'name'		 => 'price__meta_typography',
              'selector'	 => '{{WRAPPER}} .course-price span',
              ]
            );

            $this->add_control(
              'sale_price_color', [
                'label'		 => esc_html__( 'Sale Price Color', 'element-ready-pro' ),
                'type'		 => Controls_Manager::COLOR,
                'selectors'	 => [
                 
                  '{{WRAPPER}} .course-price' => 'color: {{VALUE}};',
                
                ],
              ]
            );
      
            
            $this->add_group_control(
              Group_Control_Typography::get_type(), [
              'name'		 => 'sale_price_meta_typography',
              'selector'	 => '{{WRAPPER}} .course-price',
              ]
            );


            $this->add_responsive_control(
              'price_margin',
              [
                'label' => esc_html__( 'Margin', 'element-ready-pro' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                 
                  '{{WRAPPER}} .course-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
              ]
            );

            $this->add_responsive_control(
              'price_padding',
              [
                'label' => esc_html__( 'Padding', 'element-ready-pro' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                 
                  '{{WRAPPER}} .course-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
              ]
            );

      $this->end_controls_section();
     
     
      $this->start_controls_section(
        'instructor_style', [
          'label'	 => esc_html__( 'Instructor', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          'instructor_color', [
            'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .author a' => 'color: {{VALUE}};',
            ],
          ]
        );
  
         
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
        'name'		 => 'instructor_title_typography',
        'selector'	 => '{{WRAPPER}} .author a',
        ]
        );

        $this->add_responsive_control(
          'instructor_margin',
          [
            'label' => esc_html__( 'Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'instructor_padding',
          [
            'label' => esc_html__( 'Padding', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'instructor_name_margin',
          [
            'label' => esc_html__( 'Name Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );


      $this->end_controls_section();

      $this->start_controls_section(
        'course_rating', [
          'label'	 => esc_html__( 'Course Rating', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          
        ]
      );

         
          $this->add_control(
            'course_rating_color_', [
              'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ratings i' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_control(
            'course_rating_active_color_', [
              'label'		 => esc_html__( 'Active Color', 'element-ready-pro' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ratings .active' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
              'name'     => 'course_Rating_border_',
              'label'    => esc_html__( 'Top Border', 'element-ready-pro' ),
              'selector' => '{{WRAPPER}} .price-rate',
            ]
          );

          $this->add_responsive_control(
            'course_rating_margin',
            [
              'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors'  => [
                '{{WRAPPER}} .ratings' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_responsive_control(
            'course_rating_padding',
            [
              'label' => esc_html__( 'Padding', 'element-ready-pro' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .ratings' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

      $this->end_controls_section();
      
   

      $this->box_css(
        array(
           'title' => esc_html__('Course Details','element-ready-pro'),
           'slug' => 'lp_course_details_box_style',
           'element_name' => 'lp_course_details_eready_',
           'selector' => '{{WRAPPER}} .course-details',
        )
       );

      $this->box_css(
        array(
           'title' => esc_html__('Course Item Box','element-ready-pro'),
           'slug' => 'lp_course_wrapper_box_style',
           'element_name' => 'lp_course_element_ready_',
           'selector' => '{{WRAPPER}} .element__ready__single__post',
        )
       );

         /*----------------------------
            SLIDER NAV WARP
        -----------------------------*/
        $this->start_controls_section(
          'slider_control_warp_style_section',
          [
              'label' => __( 'Slider Arrow Warp', 'element-ready-pro' ),
              'tab'       => Controls_Manager::TAB_STYLE,
              'condition' => [
                  'slider_on' => 'yes',
                  'slarrows'  => 'yes',
              ],
          ]
      );

      // Background
      $this->add_group_control(
          Group_Control_Background:: get_type(),
          [
              'name'     => 'slider_nav_warp_background',
              'label'    => __( 'Background', 'element-ready-pro' ),
              'types'    => [ 'classic', 'gradient' ],
              'selector' => '{{WRAPPER}} .sldier-content-area .owl-nav',
          ]
      );

      // Border
      $this->add_group_control(
          Group_Control_Border:: get_type(),
          [
              'name'     => 'slider_nav_warp_border',
              'label'    => __( 'Border', 'element-ready-pro' ),
              'selector' => '{{WRAPPER}} .sldier-content-area .owl-nav',
          ]
      );

      // Border Radius
      $this->add_control(
          'slider_nav_warp_radius',
          [
              'label'      => __( 'Border Radius', 'element-ready-pro' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors'  => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
          ]
      );

      // Shadow
      $this->add_group_control(
          Group_Control_Box_Shadow:: get_type(),
          [
              'name'     => 'slider_nav_warp_shadow',
              'selector' => '{{WRAPPER}} .sldier-content-area .owl-nav',
          ]
      );

      // Display;
      $this->add_responsive_control(
          'slider_nav_warp_display',
          [
              'label'   => __( 'Display', 'element-ready-pro' ),
              'type'    => Controls_Manager::SELECT,
              'default' => '',
              'options' => [
                  'initial'      => __( 'Initial', 'element-ready-pro' ),
                  'block'        => __( 'Block', 'element-ready-pro' ),
                  'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
                  'flex'         => __( 'Flex', 'element-ready-pro' ),
                  'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
                  'none'         => __( 'none', 'element-ready-pro' ),
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'display: {{VALUE}};',
              ],
          ]
      );

      // Before Postion
      $this->add_responsive_control(
          'slider_nav_warp_position',
          [
              'label'   => __( 'Position', 'element-ready-pro' ),
              'type'    => Controls_Manager::SELECT,
              'default' => '',
              
              'options' => [
                  'initial'  => __( 'Initial', 'element-ready-pro' ),
                  'absolute' => __( 'Absulute', 'element-ready-pro' ),
                  'relative' => __( 'Relative', 'element-ready-pro' ),
                  'static'   => __( 'Static', 'element-ready-pro' ),
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'position: {{VALUE}};',
              ],
          ]
      );

      // Postion From Left
      $this->add_responsive_control(
          'slider_nav_warp_position_from_left',
          [
              'label'      => __( 'From Left', 'element-ready-pro' ),
              'type'       => Controls_Manager::SLIDER,
              'size_units' => [ 'px', '%' ],
              'range'      => [
                  'px' => [
                      'min'  => -1000,
                      'max'  => 1000,
                      'step' => 1,
                  ],
                  '%' => [
                      'min' => -100,
                      'max' => 100,
                  ],
              ],
              'default' => [
                  'unit' => 'px',
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'left: {{SIZE}}{{UNIT}};',
              ],
              'condition' => [
                  'slider_nav_warp_position' => ['absolute','relative']
              ],
          ]
      );

      // Postion From Right
      $this->add_responsive_control(
          'slider_nav_warp_position_from_right',
          [
              'label'      => __( 'From Right', 'element-ready-pro' ),
              'type'       => Controls_Manager::SLIDER,
              'size_units' => [ 'px', '%' ],
              'range'      => [
                  'px' => [
                      'min'  => -1000,
                      'max'  => 1000,
                      'step' => 1,
                  ],
                  '%' => [
                      'min' => -100,
                      'max' => 100,
                  ],
              ],
              'default' => [
                  'unit' => 'px',
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'right: {{SIZE}}{{UNIT}};',
              ],
              'condition' => [
                  'slider_nav_warp_position' => ['absolute','relative']
              ],
          ]
      );

      // Postion From Top
      $this->add_responsive_control(
          'slider_nav_warp_position_from_top',
          [
              'label'      => __( 'From Top', 'element-ready-pro' ),
              'type'       => Controls_Manager::SLIDER,
              'size_units' => [ 'px', '%' ],
              'range'      => [
                  'px' => [
                      'min'  => -1000,
                      'max'  => 1000,
                      'step' => 1,
                  ],
                  '%' => [
                      'min' => -100,
                      'max' => 100,
                  ],
              ],
              'default' => [
                  'unit' => 'px',
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'top: {{SIZE}}{{UNIT}};',
              ],
              'condition' => [
                  'slider_nav_warp_position' => ['absolute','relative']
              ],
          ]
      );

      // Postion From Bottom
      $this->add_responsive_control(
          'slider_nav_warp_position_from_bottom',
          [
              'label'      => __( 'From Bottom', 'element-ready-pro' ),
              'type'       => Controls_Manager::SLIDER,
              'size_units' => [ 'px', '%' ],
              'range'      => [
                  'px' => [
                      'min'  => -1000,
                      'max'  => 1000,
                      'step' => 1,
                  ],
                  '%' => [
                      'min' => -100,
                      'max' => 100,
                  ],
              ],
              'default' => [
                  'unit' => 'px',
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'bottom: {{SIZE}}{{UNIT}};',
              ],
              'condition' => [
                  'slider_nav_warp_position' => ['absolute','relative']
              ],
          ]
      );

      // Align
      $this->add_responsive_control(
          'slider_nav_warp_align',
          [
              'label'   => __( 'Alignment', 'element-ready-pro' ),
              'type'    => Controls_Manager::CHOOSE,
              'options' => [
                  'left' => [
                      'title' => __( 'Left', 'element-ready-pro' ),
                      'icon'  => 'fa fa-align-left',
                  ],
                  'center' => [
                      'title' => __( 'Center', 'element-ready-pro' ),
                      'icon'  => 'fa fa-align-center',
                  ],
                  'right' => [
                      'title' => __( 'Right', 'element-ready-pro' ),
                      'icon'  => 'fa fa-align-right',
                  ],
                  'justify' => [
                      'title' => __( 'Justify', 'element-ready-pro' ),
                      'icon'  => 'fa fa-align-justify',
                  ],
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'text-align: {{VALUE}};',
              ],
              'default' => '',
          ]
      );

      // Width
      $this->add_responsive_control(
          'slider_nav_warp_width',
          [
              'label'      => __( 'Width', 'element-ready-pro' ),
              'type'       => Controls_Manager::SLIDER,
              'size_units' => [ 'px', '%' ],
              'range'      => [
                  'px' => [
                      'min'  => 0,
                      'max'  => 1000,
                      'step' => 1,
                  ],
                  '%' => [
                      'min' => 0,
                      'max' => 100,
                  ],
              ],
              'default' => [
                  'unit' => 'px',
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'width: {{SIZE}}{{UNIT}};',
              ],
          ]
      );

      // Height
      $this->add_responsive_control(
          'slider_nav_warp_height',
          [
              'label'      => __( 'Height', 'element-ready-pro' ),
              'type'       => Controls_Manager::SLIDER,
              'size_units' => [ 'px', '%' ],
              'range'      => [
                  'px' => [
                      'min'  => 0,
                      'max'  => 1000,
                      'step' => 1,
                  ],
                  '%' => [
                      'min' => 0,
                      'max' => 100,
                  ],
              ],
              'default' => [
                  'unit' => 'px',
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'height: {{SIZE}}{{UNIT}};',
              ],
          ]
      );

      // Opacity
      $this->add_control(
          'slider_nav_warp_opacity',
          [
              'label' => __( 'Opacity', 'element-ready-pro' ),
              'type'  => Controls_Manager::SLIDER,
              'range' => [
                  'px' => [
                      'max'  => 1,
                      'min'  => 0.10,
                      'step' => 0.01,
                  ],
              ],
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'opacity: {{SIZE}};',
              ],
          ]
      );

      // Z-Index
      $this->add_control(
          'slider_nav_warp_zindex',
          [
              'label'     => __( 'Z-Index', 'element-ready-pro' ),
              'type'      => Controls_Manager::NUMBER,
              'min'       => -99,
              'max'       => 99,
              'step'      => 1,
              'selectors' => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'z-index: {{SIZE}};',
              ],
          ]
      );

      // Margin
      $this->add_responsive_control(
          'slider_nav_warp_margin',
          [
              'label'      => __( 'Margin', 'element-ready-pro' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors'  => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
          ]
      );

      // Padding
      $this->add_responsive_control(
          'slider_nav_warp_padding',
          [
              'label'      => __( 'Margin', 'element-ready-pro' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors'  => [
                  '{{WRAPPER}} .sldier-content-area .owl-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
          ]
      );

      $this->end_controls_section();
      /*----------------------------
          SLIDER NAV WARP END
      -----------------------------*/

      /*------------------------
           ARROW STYLE
      --------------------------*/
      $this->start_controls_section(
          'slider_arrow_style',
          [
              'label'     => __( 'Arrow', 'element-ready-pro' ),
              'tab'       => Controls_Manager::TAB_STYLE,
              'condition' => [
                  'slider_on' => 'yes',
                  'slarrows'  => 'yes',
              ],
          ]
      );
      
          $this->start_controls_tabs( 'slider_arrow_style_tabs' );

              // Normal tab Start
              $this->start_controls_tab(
                  'slider_arrow_style_normal_tab',
                  [
                      'label' => __( 'Normal', 'element-ready-pro' ),
                  ]
              );

                  $this->add_control(
                      'slider_arrow_color',
                      [
                          'label'  => __( 'Color', 'element-ready-pro' ),
                          'type'   => Controls_Manager::COLOR,
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-arrow' => 'color: {{VALUE}};',
                          ],
                      ]
                  );

                  $this->add_responsive_control(
                      'slider_arrow_fontsize',
                      [
                          'label'      => __( 'Font Size', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => 0,
                                  'max'  => 100,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => 0,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                              'size' => 20,
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-arrow' => 'font-size: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Background:: get_type(),
                      [
                          'name'     => 'slider_arrow_background',
                          'label'    => __( 'Background', 'element-ready-pro' ),
                          'types'    => [ 'classic', 'gradient' ],
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-arrow',
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Border:: get_type(),
                      [
                          'name'     => 'slider_arrow_border',
                          'label'    => __( 'Border', 'element-ready-pro' ),
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-arrow',
                      ]
                  );

                  $this->add_responsive_control(
                      'slider_border_radius',
                      [
                          'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                          'type'      => Controls_Manager::DIMENSIONS,
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-arrow' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                          ],
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Box_Shadow:: get_type(),
                      [
                          'name'     => 'slider_arrow_shadow',
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-arrow',
                      ]
                  );

                  $this->add_responsive_control(
                      'slider_arrow_height',
                      [
                          'label'      => __( 'Height', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => 0,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => 0,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                              'size' => 40,
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-arrow' => 'height: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  $this->add_responsive_control(
                      'slider_arrow_width',
                      [
                          'label'      => __( 'Width', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => 0,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => 0,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                              'size' => 46,
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-arrow' => 'width: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  $this->add_responsive_control(
                      'slider_arrow_padding',
                      [
                          'label'      => __( 'Padding', 'element-ready-pro' ),
                          'type'       => Controls_Manager::DIMENSIONS,
                          'size_units' => [ 'px', '%', 'em' ],
                          'selectors'  => [
                              '{{WRAPPER}} .sldier-content-area .slick-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                          ],
                          'separator' => 'before',
                      ]
                  );

                  // Postion From Left
                  $this->add_responsive_control(
                      'slide_button_position_from_left',
                      [
                          'label'      => __( 'Left Arrow Position From Left', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => -1000,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => -100,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .owl-nav > div.owl-prev' => 'left: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  // Postion Bottom Top
                  $this->add_responsive_control(
                      'slide_button_position_from_bottom',
                      [
                          'label'      => __( 'Left Arrow Position From Top', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => -1000,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => -100,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .owl-nav > div.owl-prev' => 'top: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );


                  // Postion From Left
                  $this->add_responsive_control(
                      'slide_button_position_from_right',
                      [
                          'label'      => __( 'Right Arrow Position From Right', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => -1000,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => -100,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .owl-nav > div.owl-next' => 'right: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  // Postion Bottom Top
                  $this->add_responsive_control(
                      'slide_button_position_from_top',
                      [
                          'label'      => __( 'Right Arrow Position From Top', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => -1000,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => -100,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .owl-nav > div.owl-next' => 'top: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

              $this->end_controls_tab(); // Normal tab end

              // Hover tab Start
              $this->start_controls_tab(
                  'slider_arrow_style_hover_tab',
                  [
                      'label' => __( 'Hover', 'element-ready-pro' ),
                  ]
              );

                  $this->add_control(
                      'slider_arrow_hover_color',
                      [
                          'label'  => __( 'Color', 'element-ready-pro' ),
                          'type'   => Controls_Manager::COLOR,
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-arrow:hover' => 'color: {{VALUE}};',
                          ],
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Background:: get_type(),
                      [
                          'name'     => 'slider_arrow_hover_background',
                          'label'    => __( 'Background', 'element-ready-pro' ),
                          'types'    => [ 'classic', 'gradient' ],
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-arrow:hover',
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Border:: get_type(),
                      [
                          'name'     => 'slider_arrow_hover_border',
                          'label'    => __( 'Border', 'element-ready-pro' ),
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-arrow:hover',
                      ]
                  );

                  $this->add_responsive_control(
                      'slider_arrow_hover_border_radius',
                      [
                          'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                          'type'      => Controls_Manager::DIMENSIONS,
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-arrow:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                          ],
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Box_Shadow:: get_type(),
                      [
                          'name'     => 'slider_arrow_hover_shadow',
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-arrow:hover',
                      ]
                  );

                  // Postion From Left
                  $this->add_responsive_control(
                      'slide_button_hover_position_from_left',
                      [
                          'label'      => __( 'Left Arrow Position From Left', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => -1000,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => -100,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area:hover .owl-nav > div.owl-prev' => 'left: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  // Postion Bottom Top
                  $this->add_responsive_control(
                      'slide_button_hover_position_from_bottom',
                      [
                          'label'      => __( 'Left Arrow Position From Top', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => -1000,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => -100,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area:hover .owl-nav > div.owl-prev' => 'top: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );


                  // Postion From Left
                  $this->add_responsive_control(
                      'slide_button_hover_position_from_right',
                      [
                          'label'      => __( 'Right Arrow Position From Right', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => -1000,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => -100,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area:hover .owl-nav > div.owl-next' => 'right: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  // Postion Bottom Top
                  $this->add_responsive_control(
                      'slide_button_hover_position_from_top',
                      [
                          'label'      => __( 'Right Arrow Position From Top', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => -1000,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => -100,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area:hover .owl-nav > div.owl-next' => 'top: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

              $this->end_controls_tab(); // Hover tab end

          $this->end_controls_tabs();

      $this->end_controls_section(); // Style Slider arrow style end
      /*------------------------
           ARROW STYLE END
      --------------------------*/

      /*------------------------
           DOTS STYLE
      --------------------------*/
      $this->start_controls_section(
          'post_slider_pagination_style_section',
          [
              'label'     => __( 'Pagination', 'element-ready-pro' ),
              'tab'       => Controls_Manager::TAB_STYLE,
              'condition' => [
                  'slider_on' => 'yes',
                  'sldots'  => 'yes',
              ],
          ]
      );
          
          $this->start_controls_tabs('pagination_style_tabs');

              $this->start_controls_tab(
                  'pagination_style_normal_tab',
                  [
                      'label' => __( 'Normal', 'element-ready-pro' ),
                  ]
              );

                  $this->add_responsive_control(
                      'slider_pagination_height',
                      [
                          'label'      => __( 'Height', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => 0,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => 0,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                              'size' => 15,
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-dots li' => 'height: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  $this->add_responsive_control(
                      'slider_pagination_width',
                      [
                          'label'      => __( 'Width', 'element-ready-pro' ),
                          'type'       => Controls_Manager::SLIDER,
                          'size_units' => [ 'px', '%' ],
                          'range'      => [
                              'px' => [
                                  'min'  => 0,
                                  'max'  => 1000,
                                  'step' => 1,
                              ],
                              '%' => [
                                  'min' => 0,
                                  'max' => 100,
                              ],
                          ],
                          'default' => [
                              'unit' => 'px',
                              'size' => 15,
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-dots li' => 'width: {{SIZE}}{{UNIT}};',
                          ],
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Background:: get_type(),
                      [
                          'name'     => 'pagination_background',
                          'label'    => __( 'Background', 'element-ready-pro' ),
                          'types'    => [ 'classic', 'gradient' ],
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-dots li',
                      ]
                  );

                  $this->add_responsive_control(
                      'pagination_margin',
                      [
                          'label'      => __( 'Margin', 'element-ready-pro' ),
                          'type'       => Controls_Manager::DIMENSIONS,
                          'size_units' => [ 'px', '%', 'em' ],
                          'selectors'  => [
                              '{{WRAPPER}} .sldier-content-area .slick-dots li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                          ],
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Border:: get_type(),
                      [
                          'name'     => 'pagination_border',
                          'label'    => __( 'Border', 'element-ready-pro' ),
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-dots li',
                      ]
                  );

                  $this->add_responsive_control(
                      'pagination_border_radius',
                      [
                          'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                          'type'      => Controls_Manager::DIMENSIONS,
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-dots li' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                          ],
                      ]
                  );

                  $this->add_responsive_control(
                      'pagination_warp_margin',
                      [
                          'label'      => __( 'Pagination Warp Margin', 'element-ready-pro' ),
                          'type'       => Controls_Manager::DIMENSIONS,
                          'size_units' => [ 'px', '%', 'em' ],
                          'selectors'  => [
                              '{{WRAPPER}} .sldier-content-area .slick-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                          ],
                      ]
                  );

                  $this->add_responsive_control(
                      'pagi_war_align',
                      [
                          'label'   => __( 'Pagination Warp Alignment', 'element-ready-pro' ),
                          'type'    => Controls_Manager::CHOOSE,
                          'options' => [
                              'left' => [
                                  'title' => __( 'Left', 'element-ready-pro' ),
                                  'icon'  => 'fa fa-align-left',
                              ],
                              'center' => [
                                  'title' => __( 'Center', 'element-ready-pro' ),
                                  'icon'  => 'fa fa-align-center',
                              ],
                              'right' => [
                                  'title' => __( 'Right', 'element-ready-pro' ),
                                  'icon'  => 'fa fa-align-right',
                              ],
                              'justify' => [
                                  'title' => __( 'Justified', 'element-ready-pro' ),
                                  'icon'  => 'fa fa-align-justify',
                              ],
                          ],
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-dots' => 'text-align: {{VALUE}};',
                          ],
                      ]
                  );

              $this->end_controls_tab(); // Normal Tab end

              $this->start_controls_tab(
                  'pagination_style_active_tab',
                  [
                      'label' => __( 'Active', 'element-ready-pro' ),
                  ]
              );
                  
                  $this->add_group_control(
                      Group_Control_Background:: get_type(),
                      [
                          'name'     => 'pagination_hover_background',
                          'label'    => __( 'Background', 'element-ready-pro' ),
                          'types'    => [ 'classic', 'gradient' ],
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-dots li:hover, {{WRAPPER}} .sldier-content-area .slick-dots li.slick-active',
                      ]
                  );

                  $this->add_group_control(
                      Group_Control_Border::get_type(),
                      [
                          'name'     => 'pagination_hover_border',
                          'label'    => __( 'Border', 'element-ready-pro' ),
                          'selector' => '{{WRAPPER}} .sldier-content-area .slick-dots li:hover, {{WRAPPER}} .sldier-content-area .slick-dots li.slick-active',
                      ]
                  );

                  $this->add_responsive_control(
                      'pagination_hover_border_radius',
                      [
                          'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                          'type'      => Controls_Manager::DIMENSIONS,
                          'selectors' => [
                              '{{WRAPPER}} .sldier-content-area .slick-dots li.slick-active' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                              '{{WRAPPER}} .sldier-content-area .slick-dots li:hover'        => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                          ],
                      ]
                  );

              $this->end_controls_tab(); // Hover Tab end

          $this->end_controls_tabs();

      $this->end_controls_section();
      /*------------------------
           DOTS STYLE END
      --------------------------*/
 
     
    }    
    protected function render() {
   
      $settings   = $this->get_settings();
     
      $course_settings = array(
       
        'order'             => $settings['order'],
        'cat_id'            => $settings['cat_id'],
        'course_list'       => $settings['course_list'],
        'layout'            => $settings['layout'],
        'limit'             => $settings['limit'],
        'featured'          => $settings['featured'],
        'all_category' => $this->course_category()
      );

      $category_groups = []; 

      if(defined('LP_COURSE_CPT')){

         global $post, $wpdb;
         $random    = rand( 1, 99 );
        
         $cat_id    = $course_settings['cat_id'] ? $course_settings['cat_id'] : array();
         $limit     = $course_settings['limit'];
         $featured  = ! empty( $course_settings['featured'] ) ? true : false;
         $sort      = $course_settings['order'];
         $thumb_w   = ( ! empty( $course_settings['thumbnail_width'] ) && '' != $course_settings['thumbnail_width'] ) ? $course_settings['thumbnail_width'] : apply_filters( 'thim_course_thumbnail_width', 450 );
         $thumb_h   = ( ! empty( $course_settings['thumbnail_height'] ) && '' != $course_settings['thumbnail_height'] ) ? $course_settings['thumbnail_height'] : apply_filters( 'thim_course_thumbnail_height', 400 );
       
         $condition = array(
            'post_type'           => 'lp_course',
            'posts_per_page'      => $limit,
            
         );

         if ( is_array($cat_id) && count($cat_id) ) {

               $condition['tax_query'] = array(
                  array(
                     'taxonomy' => 'course_category',
                     'field'    => 'term_id',
                     'terms'    => $cat_id
                  ),
               );
            
         }

         if ( $sort == 'popular' ) {
            global $wpdb;
            $query = $wpdb->prepare( "
            SELECT ID, a+IF(b IS NULL, 0, b) AS students FROM(
               SELECT p.ID as ID, IF(pm.meta_value, pm.meta_value, 0) as a, (
                     SELECT COUNT(*)
                  FROM (SELECT COUNT(item_id), item_id, user_id FROM {$wpdb->prefix}learnpress_user_items GROUP BY item_id, user_id) AS Y
                  GROUP BY item_id
                  HAVING item_id = p.ID
                  ) AS b
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} AS pm ON p.ID = pm.post_id  AND pm.meta_key = %s
                  WHERE p.post_type = %s AND p.post_status = %s
                  GROUP BY ID
                  ) AS Z
                  ORDER BY students DESC
                     LIMIT 0, $limit
                  ", '_lp_students', 'lp_course', 'publish' );

            $post_in = $wpdb->get_col( $query );

            $condition['post__in'] = $post_in;
            $condition['orderby']  = 'post__in';
         }

         if( $featured ) {
            $condition['meta_query'] = array(
               array(
                  'key' => '_lp_featured',
                  'value' =>  'yes',
               )
            );
         }

         $the_query = new \WP_Query( $condition );
        // Slider options
        if( $settings['slider_on'] == 'yes' ){

          $this->add_render_attribute( 'element_ready_post_slider_attr', 'class', 'element-ready-carousel-activation ' );
          $this->add_render_attribute( 'element_ready_post_carousel', 'class', 'sldier-content-area '.$settings['nav_position'] );


          $slideid = rand(2564,1245);

          $slider_settings = [
              'slideid'          => $slideid,
              'arrows'          => ('yes' === $settings['slarrows']),
              'arrow_prev_txt'  => $settings['slprevicon'],
              'arrow_next_txt'  => $settings['slnexticon'],
              'dots'            => ('yes' === $settings['sldots']),
              'autoplay'        => ('yes' === $settings['slautolay']),
              'autoplay_speed'  => absint($settings['slautoplay_speed']),
              'animation_speed' => absint($settings['slanimation_speed']),
              'pause_on_hover'  => ('yes' === $settings['slpause_on_hover']),
              'center_mode'     => ( 'yes' === $settings['slcentermode']),
              'center_padding'  => absint($settings['slcenterpadding']),
              'rows'            => absint($settings['slrows']),
              'fade'            => ( 'yes' === $settings['slfade']),
              'focusonselect'   => ( 'yes' === $settings['slfocusonselect']),
              'vertical'        => ( 'yes' === $settings['slvertical']),
              'rtl'             => ( 'yes' === $settings['slrtl']),
              'infinite'        => ( 'yes' === $settings['slinfinite']),
          ];

          $slider_responsive_settings = [
              'display_columns'        => $settings['slitems'],
              'scroll_columns'         => $settings['slscroll_columns'],
              'tablet_width'           => $settings['sltablet_width'],
              'tablet_display_columns' => $settings['sltablet_display_columns'],
              'tablet_scroll_columns'  => $settings['sltablet_scroll_columns'],
              'mobile_width'           => $settings['slmobile_width'],
              'mobile_display_columns' => $settings['slmobile_display_columns'],
              'mobile_scroll_columns'  => $settings['slmobile_scroll_columns'],

          ];

          $slider_settings = array_merge( $slider_settings, $slider_responsive_settings );

          $this->add_render_attribute( 'element_ready_post_slider_attr', 'data-settings', wp_json_encode( $slider_settings ) );
      }

       ?>
        <?php if ( $the_query->have_posts() ) : ?>

            <?php if($settings['layout'] =='style1'): ?>  
                <div <?php echo $this->get_render_attribute_string( 'element_ready_post_carousel' ); ?> >
                  <div class="element-ready-course-slider" >
                      <div <?php echo $this->get_render_attribute_string( 'element_ready_post_slider_attr' ); ?>>
                            <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                              <?php

                                    $terms         = get_the_terms( $post->ID, 'course_category' );
                                    $cat           = '';
                                    $cat_with_link = '';
                                  
                                    if(is_array($terms)):
                    
                                      foreach($terms as $tkey=>$term):
                                          
                                      $cat.= $term->slug.' ';
                                      
                    
                                      endforeach;
                    
                                    endif; 
                                    
                                    $cat_with_link     = element_ready_lp_course_cageory_by_id($post->ID);
                                    $course            = learn_press_get_course( $post->ID );
                                    $lessons           = $course->get_items( 'lp_lesson' )?count( $course->get_items( 'lp_lesson' ) ) : 0;
                                    $students_enrolled = $course->get_users_enrolled();
                                    $instructor        = $course->get_instructor();
                                    $instructor_link   = $course->get_instructor_html();
                                    $instructor_id     = $course->get_id();
                                    $meta              = get_post_meta( $post->ID );
                                                
                                    $featured = isset($meta['_lp_featured'][0]) ? $meta['_lp_featured'][0] : '';
                                    $banner_image = 'style="background-image:url('.esc_url( get_the_post_thumbnail_url(get_the_id(),'full') ).');"';
                              ?>
                          
                              <div class="course-item-3 element__ready__single__post">
                                  <?php if( has_post_thumbnail() ): ?>
                                      <div class="ci-thumb">
                                           <div <?php echo $banner_image; ?> class="course-item-3-bg-image"> </div>
                                           <?php 
                                            echo wp_kses_post($cat_with_link);
                                           ?>
                                      </div>
                                  <?php endif; ?>
                                  <div class="course-details">
                                      <?php if($settings['background_shape']['url'] ==''): ?>
                                         <img class="line-bg" src="<?php echo esc_url(ELEMENT_READY_ROOT_IMG); ?>/line.jpg" alt="<?php echo esc_attr(get_the_title()); ?>">
                                      <?php else: ?>
                                        <img class="line-bg" src="<?php echo esc_url($settings['background_shape']['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                      <?php endif; ?>
                                      <div class="fcf-bottom">
                                          <a class="element-ready-lesson" href="<?php echo esc_url($course->get_permalink()); ?>"> <?php \Elementor\Icons_Manager::render_icon( $settings['lesson_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo esc_html($lessons); ?> <?php echo esc_html__('Lessons','element-ready-pro'); ?></a>
                                          <a class="element-ready-students" href="<?php echo esc_url($course->get_permalink()); ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['student_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo esc_html($students_enrolled); ?> </a>
                                      </div>
                                      <h4 class="title"><a href="<?php echo esc_url($course->get_permalink()); ?>"><?php echo esc_html(get_the_title()); ?></a></h4>
                                      <?php if($settings['show_content'] == 'yes'): ?>
                                        <p class="content">
                                            <?php echo esc_html(wp_trim_words( get_the_excerpt(), $settings['content_limit'], '') ); ?>
                                        </p>
                                      <?php endif; ?>
                                      <?php 
                                          $dir          = learn_press_user_profile_picture_upload_dir();
                                          $user         = get_user_by( 'id', $instructor->get_id());
                                          $pro_link     = get_user_meta($user->ID,'_lp_profile_picture',true);
                                          $base_url     = isset($dir['baseurl'])?$dir['baseurl']:'';
                                          $profile_link = $base_url.'/'.$pro_link;
            
                                      ?>
                                      <?php if($settings['show_author'] == 'yes'): ?>
                                          <div class="author">
                                                <img src="<?php echo esc_url( get_avatar_url( $instructor->get_id() ) ); ?>">
                                                <?php  echo wp_kses_post($instructor_link) ?>
                                          </div>
                                      <?php endif; ?>
                                      <div class="price-rate">
                                          <div class="course-price">
                                              
                                              <?php if($course->is_free()): ?>
                                                  <?php echo esc_html__('free','element-ready-pro'); ?>
                                              <?php else: ?>
                                                  
                                                  <?php if( $course->has_sale_price() ): ?> 
                                                    <?php echo $course->get_price_html(); ?> 
                                                  <?php endif; ?>
                                                  <span> <?php echo $course->get_origin_price_html(); ?> </span>   

                                              <?php endif; ?>
                                              
                                          </div>
                                          <?php if( function_exists( 'learn_press_get_course_rate' ) && $settings['course_rating_show'] =='yes' ): ?>
                                                <?php
                                                    $course_rate_res = learn_press_get_course_rate( $post->ID, false );
                                                    $course_rate     = $course_rate_res['rated'];
                                                    $total           = $course_rate_res['total'];
        
                                                ?>
                                                <div class="ratings">
                                                     <?php foreach (range(1, 5) as $hnumber): ?>
                                                        <i class="fa fa-star <?php echo esc_attr($hnumber<=$course_rate?'active':'inactive'); ?>"></i>
                                                      <?php endforeach; ?>
                                                <span><?php echo esc_html($total); ?> (<?php echo sprintf( __( '%s Reviews', 'element-ready-pro' ), $course_rate ); ?>)</span>
                                                
                                                </div>
                                          <?php endif; ?>
                                      </div>
                                  </div>
                              </div>
                            <?php endwhile; wp_reset_postdata(); ?>
                         
                      </div>
                    </div>
                    <?php if( $settings['slarrows'] == 'yes' || $settings['sldots'] == 'yes' ) : ?>

                        <div class="owl-controls">
                            <?php if( $settings['slarrows'] == 'yes' ) : ?>
                              <div class="element-ready-carousel-nav<?php echo esc_attr( $slideid ); ?> owl-nav"></div>
                            <?php endif; ?>

                            <?php if( $settings['sldots'] == 'yes' ) : ?>
                              <div class="element-ready-carousel-dots<?php echo esc_attr( $slideid ); ?> owl-dots"></div>
                            <?php endif; ?>
                        </div>

                    <?php endif; ?>
                  </div>
            <?php endif; ?>
          
         <?php
          endif;
         ?>
       <?php

         
      }
  
      
    }
   
    public function course_list(){
      if(!defined('LP_COURSE_CPT')){
        return [];
      }
      $args = array(

        'post_type'   => 'lp_course',
        'orderby' => 'post_date', 
        'order' => 'DESC',
        'post_status'  => 'publish',
        'posts_per_page' => -1
                  
        );  

        $lp_course = get_posts( $args ); 
        $course_list = [];
       
        foreach ($lp_course as $postdata) {
            setup_postdata( $postdata );
            $course_list[$postdata->ID] = [$postdata->post_title];
         
        }
      
        return $course_list;
    }

 

}