<?php
namespace Element_Ready_Pro\Widgets\protected_content;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );
if ( ! defined( 'ABSPATH' ) ) exit;

class WP_protected_content extends Widget_Base {

    public $base;
    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_Ready_Box_Style;
    public function get_name() {
        return 'element-ready-pro-protected-content';
    }

    public function get_keywords() {
		return ['element ready','pro','protected content','password'];
	}

    public function get_title() {
        return esc_html__( 'ER Protected Content', 'element-ready-pro' );
    }

    public function get_icon() { 
        return 'eicon-tags';
    }

    public function get_script_depends() {
        return [
            'element-ready-core',
        ];
    }

    public function get_style_depends() {
        return [
            
        ];
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }
    public function layout(){
        return[
            
            'style1'   => esc_html__( 'style1', 'element-ready-pro' ),
            
        ];
    }

    protected function register_controls() {

     
        
        $this->start_controls_section(
			'header_element_ready_protected_section',
			[
                'label' => esc_html__( 'Content', 'element-ready-pro' ),
                
			]
        );

        $this->add_control(
            'custom_template',
            [
                'label' => esc_html__( 'Custom template', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'element-ready-pro' ),
                'label_off' => esc_html__( 'Hide', 'element-ready-pro' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'password',
            [
                'label'   => esc_html__( 'Password', 'element-ready-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( '12345', 'element-ready-pro' ),
               
            ]
        ); 

        $this->add_control(
            'enable_session',
            [
                'label' => esc_html__( 'Store password in user browser', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'element-ready-pro' ),
                'label_off' => esc_html__( 'Hide', 'element-ready-pro' ),
                'return_value' => 'yes',
                'default' => '',
                'description' => esc_html__( 'Password will be store in user agent browser when will be provided valid secrate key', 'element-ready-pro' )
            ]
        );
        
        $this->add_control(
            'submit_text',
            [
                'label'   => esc_html__( 'Submit Text', 'element-ready-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Submit', 'element-ready-pro' ),
               
            ]
        );

        $this->add_control(
            'template_id',
            [
                'label'     => esc_html__( 'Select Content Template', 'element-ready-pro' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => '0',
                'options'   => element_ready_elementor_template(),
                'condition' => [
                    'custom_template' => ['yes']
                ],
                'description' => esc_html__( 'Please select elementor templete from here, if not create elementor template from menu', 'element-ready-pro' )
               
            ]
        );

        $this->add_control(
            'title',
            [
                'label'   => esc_html__( 'Title', 'element-ready-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Heading', 'element-ready-pro' ),
                'condition' => [
                    'custom_template!' => ['yes']
                ],
            ]
        );

        
        $this->add_control(
            'content',
            [
                'label'   => esc_html__( 'Content', 'element-ready-pro' ),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Content here', 'element-ready-pro' ),
                'condition' => [
                    'custom_template!' => ['yes']
                ],
            ]
        );
   
      
    $this->end_controls_section();
 
    $this->text_wrapper_css(
        array(
           'title' => esc_html__('Title','element-ready-pro'),
           'slug' => 'post_title_style',
           'element_name' => 'post_title_element_ready_',
           'selector' => '{{WRAPPER}} .element-ready-pro-title',
           'hover_selector' => '{{WRAPPER}} .element-ready-pro-title:hover',
           'condition' => [
            'custom_template!' => ['yes']
        ],
          
        )
    );

    $this->text_wrapper_css(
            array(
            'title' => esc_html__('Content','element-ready-pro'),
            'slug' => 'post_content_style',
            'element_name' => 'post_content_element_ready_',
            'selector' => '{{WRAPPER}} .element-ready-pro-protected-content',
            'hover_selector' => '{{WRAPPER}} .element-ready-pro-protected-content:hover',
            'condition' => [
                'custom_template!' => ['yes']
            ],
         )
    );

    $this->box_css(
        array(
           'title' => esc_html__('Wrapper','element-ready-pro'),
           'slug' => 'item_wrapper__box_style',
           'element_name' => 'item_wrapper_element_ready_',
           'selector' => '{{WRAPPER}} .element-ready-pro-widget-protection',
           'condition' => [
            'custom_template!' => ['yes']
        ],
        )
    );

    $this->start_controls_section(
        'element_ready_pro_widget_protected_content_style_section',
        [
       
            'label' => esc_html__( 'Style', 'element-ready-pro' ),
        ]
      );

      $this->start_controls_tabs(
        'element_ready_pro_protected_w_style_tabs'
        
    );

        $this->start_controls_tab(
            'element_ready_pro_protected_w_style_button_tab',
            [
                'label' => esc_html__( 'Button', 'element-ready-pro' ),
                
            ]
        );

                $this->add_control(
                    'element_ready_pro_protected_w_button_text_color',
                    [
                        'label' => esc_html__( 'Color', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-submit-btn' => 'color: {{VALUE}}',
                        ],
                    ]
                );

                
                $this->add_group_control(
                    \Elementor\Group_Control_Typography::get_type(),
                    [
                        'name' => 'element_ready_button_w_bg_color_nt_typography',
                        'label' => __( 'Typography', 'element-ready-pro' ),
                        'selector' => '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-submit-btn',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'element_ready_pro_w_protected_button_bg_color',
                        'label' => __( 'Background', 'element-ready-pro' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-submit-btn',
                    ]
                );

                $this->add_control(
                    'element_ready_pro_protected_w_button_border_radious',
                    [
                        'label' => __( 'Border Radious', 'element-ready-pro' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 200,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        'default' => [
                            'unit' => '%',
                            'size' => 10,
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-submit-btn' => 'border-radius: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_control(
                    'element_ready_pro_protected_w_button_margin',
                    [
                        'label' => __( 'Margin', 'element-ready-pro' ),
                        'type' => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors' => [
                            '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-submit-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_control(
                    'element_ready_pro_protected_w_button_padding',
                    [
                        'label' => __( 'Padding', 'element-ready-pro' ),
                        'type' => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors' => [
                            '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-submit-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'element_ready_pro_w_protectedbutton_border',
                        'label' => __( 'Border', 'element-ready-pr' ),
                        'selector' => '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-submit-btn',
                    ]
                );

                   
            $this->add_responsive_control(
                'main_section_element_ready_w_protected_content_custom_css',
                [
                    'label'     => esc_html__( 'Custom CSS', 'element-ready-pro' ),
                    'type'      => \Elementor\Controls_Manager::CODE,
                    'rows'      => 20,
                    'language'  => 'css',
                    'selectors' => [
                        '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-submit-btn' => '{{VALUE}};',
                      
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'element_ready_pro_w_protected_input_style_tab',
            [
                'label' => esc_html__( 'Input', 'element-ready-pro' ),
              ]
        );

            $this->add_control(
                'element_ready_pro_protected_w_input_text_color',
                [
                    'label' => esc_html__( 'Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-pro-password-fl' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'element_ready_input_w_bg_color_nt_typography',
                    'label' => __( 'Typography', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-pro-password-fl',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'element_ready_pro_w_protected_input_bg_color',
                    'label' => __( 'Background', 'element-ready-pro' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-pro-password-fl',
                ]
            );

            $this->add_control(
                'element_ready_pro_w_protected_input_border_radious',
                [
                    'label' => __( 'Border Radious', 'element-ready-pro' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 200,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'default' => [
                        'unit' => '%',
                        'size' => 10,
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-pro-password-fl' => 'border-radius: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'element_ready_pro_w_protected_input_margin',
                [
                    'label' => __( 'Margin', 'element-ready-pro' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-pro-password-fl' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'element_ready_pro_w_protected_input_padding',
                [
                    'label' => __( 'Padding', 'element-ready-pro' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-pro-password-fl' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'element__wready_pro_protected_input_border',
                    'label' => __( 'Border', 'element-ready-pr' ),
                    'selector' => '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt .element-ready-pro-password-fl',
                ]
            );

            $this->add_responsive_control(
                '_section_element_w_ready_protected_content_inp_custom_css',
                [
                    'label'     => esc_html__( 'Custom CSS', 'element-ready-pro' ),
                    'type'      => \Elementor\Controls_Manager::CODE,
                    'rows'      => 20,
                    'language'  => 'css',
                    'selectors' => [
                        '{{WRAPPER}} .element_ready_pro_protected_content_button_cnt element-ready-pro-password-fl' => '{{VALUE}};',
                      
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_tab();

    $this->end_controls_tabs();

    $this->end_controls_section();
   
    } //Register control end

  
     
    protected function render( ) { 

        $settings       = $this->get_settings();
        $widget_id    = 'element-ready-'.$this->get_id().'-';
        $submit_text = $settings['submit_text'];
    ?>    
         
    <!--====== Header START ======-->
     

    <?php include('layout/style1.php'); ?>   

       

    <!--====== PART ENDS ======-->
    
    <?php  

    }
    
    protected function content_template() { }

    public function is_active($settings,$id=''){
     
        if( $settings['enable_session'] =='yes' && !\Elementor\Plugin::$instance->editor->is_edit_mode()){

            if( isset( $_SESSION['element_ready_pro_protected_content_'.$id])){
                return true;
            }
        }
        
        $password = $settings['password'];
        if( isset($_REQUEST['element-ready-protected-widget-number']) && isset($_REQUEST['element-ready-protected-widget-id']) ){
            
            $provider_pass = $_REQUEST['element-ready-protected-widget-number'];
            $provider_id = $_REQUEST['element-ready-protected-widget-id'];
           
            if($id==$provider_id && $password == $provider_pass ){
              
              $_SESSION['element_ready_pro_protected_content_'.$provider_id] = true;
                
              return true;
            }
        }

        return false;
    }

}