<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base;
use Element_Ready\Base\BaseController;
use Elementor\Widget_Base;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Shortcode_Base as Shortcode_Base;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\File_Maker;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\Common as BuilderCommon;
Class Shortcode_Register {

    use File_Maker;
    use BuilderCommon;
    public $widget_list = [];
    public function register() {
      
     // add_action( 'elementor/init', array( $this, 'elementor_init' ) );
      add_action( 'elementor/widgets/register', [ $this, 'init_widgets' ] );
    }
    public function init_widgets(){
       
      $this->widget_list = $this->get_posts();
    
      $widget_path = ELEMENT_READY_PRO_BUILDER_PATH."Widgets";
      $widgets     = element_ready_widgets_class_list($widget_path);
   
      if( is_array($widgets) ){
       
        // Register Widgets
        foreach($widgets as $widget_cls){
          
          $cls = 'Element_Ready_Pro\Modules\ShortCodeBuilder\Widgets'.'\\'.$widget_cls;
          if( class_exists( $cls ) ):
            \Elementor\Plugin::instance()->widgets_manager->register( new $cls() );
          endif;	
          
        }
      }

     
    

    } 

    public function elementor_init(){
       $s = new \Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Shortcode_Generate();
       $s->recreate();
    }

   
}