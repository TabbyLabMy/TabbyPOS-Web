<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits;

if ( ! defined( 'ABSPATH' ) ) exit;

trait File_Maker
{
    public function save_content($content,$file_name){

        global $wp_filesystem;
        // Initialize the WP filesystem, no more using 'file-put-contents' function
        if (empty($wp_filesystem)) {
            require_once (ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }
        $path = ELEMENT_READY_PRO_BUILDER_PATH.'widgets/'.$file_name.'.php'; 
        if(!$wp_filesystem->put_contents( $path, $content, 0644) ) {
            return __('Failed to create widget file');
        }
    }
 
    public function remove_widget_from_dir($file_name){
   
        $widget_path = ELEMENT_READY_PRO_BUILDER_PATH.'widgets/'.$file_name.'.php'; 
        if( file_exists($widget_path) ){

            $css_path =  ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/css/'.$file_name.'.css';
            if(file_exists($css_path)){
               wp_delete_file( $css_path );
            } 

            $js_path =  ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/js/'.$file_name.'.js';
            if(file_exists($js_path)){
               wp_delete_file( $js_path );
            } 

            wp_delete_file( $widget_path );
            return $widget_path;
        }
        
        return false;
    }


    /*
      $content  = css
      $widget = $post id
    */ 
    public function save_css($id,$file_name){

        global $wp_filesystem;
        // Initialize the WP filesystem, no more using 'file-put-contents' function
        if (empty($wp_filesystem)) {
            require_once (ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }

        $post_meta = get_post_meta($id,ELEMENT_READY_PRO_BUILDER_WIDGET_KEY,true);  
        $content = isset($post_meta['content_css'])?$post_meta['content_css']:false;
        if(!file_exists(ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/css')){
            wp_mkdir_p(ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/css');
        } 
        if($content !=''){

            $path = ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/css/'.$file_name.'.css'; 
           
            if(!$wp_filesystem->put_contents( $path, $content, 0644) ) {
                return __('Failed to create widget css file');
            }
        }
        
    }

    public function save_js($id,$file_name){

        global $wp_filesystem;
        // Initialize the WP filesystem, no more using 'file-put-contents' function
        if (empty($wp_filesystem)) {
            require_once (ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }

        $post_meta = get_post_meta($id,ELEMENT_READY_PRO_BUILDER_WIDGET_KEY,true);  
        $content = isset($post_meta['content_js'])?$post_meta['content_js']:false;
       
        if(!file_exists(ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/js')){
            wp_mkdir_p(ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/js');
        } 

        if( $content !='' ){
            
            $path = ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/js/'.$file_name.'.js'; 
           
            if(!$wp_filesystem->put_contents( $path, $content, 0644) ) {
                return __('Failed to create widget js file');
            }
        }
        
    }
}