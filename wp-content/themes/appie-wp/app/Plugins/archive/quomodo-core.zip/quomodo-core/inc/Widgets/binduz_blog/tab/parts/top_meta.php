<?php if($settings['top_meta_enable'] == 'yes'): ?>

    <div class="binduz-er-meta-item">
        <?php if( $settings['show_top_cat'] == 'yes' ): ?>
            <?php include('category4.php');  ?>
        <?php endif; ?>
        <?php if( $settings['show_top_author'] == 'yes' ): ?>
            <?php include('author4.php');  ?>
        <?php endif; ?>
        <?php if( $settings['show_top_date'] == 'yes' ): ?>
             <?php include('date.php');  ?>
        <?php endif; ?>
        <?php if( $settings['show_top_comment'] == 'yes' ): ?>
            <?php include('comment_meta.php'); ?>
        <?php endif; ?>
    </div>
<?php endif; ?>