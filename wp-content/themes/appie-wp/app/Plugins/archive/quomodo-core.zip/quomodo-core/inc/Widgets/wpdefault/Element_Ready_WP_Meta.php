<?php
namespace Element_Ready_Pro\Widgets\wpdefault;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;

require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

if ( ! defined( 'ABSPATH' ) ) exit;

class Element_Ready_WP_Meta extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;
    public function get_name() {
        return 'Element_Ready_Wp_Meta';
    }

    public function get_title() {
        return esc_html__( 'ER WP Meta', 'element-ready-pro' );
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_icon() { 
        return 'eicon-meta-data';
    }

    protected function register_controls() {

        /*---------------------------
            Wp-meta
        -----------------------------*/
         $this->content_text([
            'title' => esc_html__('Settings','element-ready-pro'),
            'slug' => '_settings_content',
            'condition' => '',
            'controls' => [

                'title_hide' =>   [
                    'label' => esc_html__( 'Hide title', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => '',
                    'options' => [
                        'none'  => esc_html__( 'Yes', 'element-ready-pro' ),
                        '' => esc_html__( 'No', 'element-ready-pro' ),
                    ],
                    'selectors' => [
                       '{{WRAPPER}} .widget-title' => 'display: {{VALUE}};',
                       '{{WRAPPER}} .widgettitle' => 'display: {{VALUE}};',
                    ],
                ],

                'icon_hide' =>   [
                    'label' => esc_html__( 'Hide Icon', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => '',
                    'options' => [
                        'none'  => esc_html__( 'Yes', 'element-ready-pro' ),
                        '' => esc_html__( 'No', 'element-ready-pro' ),
                    ],
                    'selectors' => [
                       '{{WRAPPER}} .widget_meta > ul > li a:before' => 'display: {{VALUE}};',
                    ],
                ],
               
                'widget_title'=> [
                    'label'   => esc_html__( 'Title', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                ],


            ]
         ]);
        /*---------------------------
            Nav END
        -----------------------------*/

        /*--------------------------
            TITLE STYLE
        ----------------------------*/
        $this->text_css(
            array(
                'title' => esc_html__('Title','element-ready-pro'),
                'slug' => '_title_style',
                'element_name' => 'title_element_ready_',
                'selector' => '{{WRAPPER}} .widget-title,{{WRAPPER}} .widgettitle',
                'hover_selector' => '{{WRAPPER}}.widget-title:hover,{{WRAPPER}} .widgettitle:hover',
                'condition' => [
                    'title_hide' => '',
                ],
            )
        );
        /*--------------------------
            TITLE STYLE END
        ----------------------------*/
       
        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Content','element-ready-pro'),
                'slug' => '_content_box_style',
                'element_name' => 'content_element_ready_',
                'selector' => '{{WRAPPER}} .widget_meta ul li a',
            )
        ); 
        
        $this->text_css(
            array(
                'title' => esc_html__('Icon','element-ready-pro'),
                'slug' => 'icon_box_style',
                'element_name' => 'icon_element_ready_',
                'selector' => '{{WRAPPER}} .widget_meta ul li a:before',
                'hover_selector' => '{{WRAPPER}} .widget_meta ul li:hover a:before',
            )
        );

        $this->box_css(
            array(
                'title' => esc_html__('Wrapper','element-ready-pro'),
                'slug' => 'wrapper_body_box_style',
                'element_name' => 'wrapper_body_element_ready_',
                'selector' => '{{WRAPPER}} .widget_meta ul',
            )
        );
      
    
    }

    protected function render() {

       $settings         = $this->get_settings();
       $widget_args      = [];

       $widget_args['title'] = $settings['widget_title']==''?'':$settings['widget_title']; 
    
       ?>

        <div class="element-ready-wp-widget-meta">
            <?php the_widget( 'WP_Widget_Meta' ,$widget_args); ?>
        </div>
    <?php
    }
    protected function content_template() {}
}
