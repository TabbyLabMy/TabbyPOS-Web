<?php
namespace Element_Ready_Pro\Widgets\wpdefault;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );

if ( ! defined( 'ABSPATH' ) ) exit;

class Element_Ready_WP_Recent_Post extends Widget_Base {
    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;
    public function get_name() {
        return 'Element_Ready_Wp_Recent_Post';
    }

    public function get_title() {
        return esc_html__( 'ER WP Recent Post', 'element-ready-pro' );
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_icon() { 
        return 'eicon-post-list';
    }

    protected function register_controls() {

        /*---------------------------
           Content Setting
        -----------------------------*/
         $this->content_text([
            'title' => esc_html__('Settings','element-ready-pro'),
            'slug' => '_heading_content',
            'condition' => '',
            'controls' => [


                'advanced_settings' => [
                    'label' => esc_html__( 'Advanced Settings', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Yes', 'element-ready-pro' ),
                    'label_off' => esc_html__( 'No', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default' => '',
                ],

                'title_hide' =>   [
                    'label' => esc_html__( 'Show title', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => '',
                    'options' => [
                        ''  => esc_html__( 'Yes', 'element-ready-pro' ),
                        'none' => esc_html__( 'No', 'element-ready-pro' ),
                    ],
                    'selectors' => [
                       '{{WRAPPER}} .widget-title' => 'display: {{VALUE}};',
                       '{{WRAPPER}} .widgettitle' => 'display: {{VALUE}};',
                    ],
                ],
               
                'widget_title'=> [
                    'label'   => esc_html__( 'Heading Title', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                ],

                'number'=> [
                    'label'   => esc_html__( 'number', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'default' => 6,
                ],
                
                'show_date' => [
                    'label' => esc_html__( 'Show date', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Yes', 'element-ready-pro' ),
                    'label_off' => esc_html__( 'No', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default' => '',
                ],

                'ignore_sticky_posts' => [
                    'label' => esc_html__( 'Ignore Sticky', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Yes', 'element-ready-pro' ),
                    'label_off' => esc_html__( 'No', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default' => '',
                    'condition' => [
                        'advanced_settings' => 'yes'
                    ]
                ],

             

            ]
         ]);
        /*---------------------------
           Content Setting END
        -----------------------------*/

        /*--------------------------
            TITLE STYLE
        ----------------------------*/
        $this->text_css(
            array(
                'title' => esc_html__('Title','element-ready-pro'),
                'slug' => '_title_style',
                'element_name' => 'title_element_ready_',
                'selector' => '{{WRAPPER}} .widget-title,{{WRAPPER}} .widgettitle',
                'hover_selector' => '{{WRAPPER}}.widget-title:hover,{{WRAPPER}} .widgettitle:hover',
                'condition' => [
                    'title_hide' => '',
                ],
            )
        );
        /*--------------------------
            TITLE STYLE END
        ----------------------------*/
       
      
      
        $this->text_css(
            array(
                'title' => esc_html__('Post Title','element-ready-pro'),
                'slug' => 'count_select_style',
                'element_name' => 'count_select_element_ready_',
                'selector' => '{{WRAPPER}} .widget_recent_entries li a',
                'hover_selector' => '{{WRAPPER}} .widget_recent_entries li:hover a',
               
            )
        );

        
        $this->text_css(
            array(
                'title' => esc_html__('Date','element-ready-pro'),
                'slug' => 'date_select_style',
                'element_name' => 'date_select_element_ready_',
                'selector' => '{{WRAPPER}} .widget_recent_entries li .post-date',
                'hover_selector' => '{{WRAPPER}} .widget_recent_entries li .post-date:hover',
            )
        );

        $this->box_css(
            array(
                'title' => esc_html__('Item','element-ready-pro'),
                'slug' => 'item_body_box_style',
                'element_name' => 'item_body_element_ready_',
                'selector' => '{{WRAPPER}} .widget_recent_entries li',
            )
        );
        
        $this->box_css(
            array(
                'title' => esc_html__('Wrapper','element-ready-pro'),
                'slug' => 'wrapper_body_box_style',
                'element_name' => 'wrapper_body_element_ready_',
                'selector' => '{{WRAPPER}} ul',
            )
        );

    
    }

    protected function render() {

       $settings         = $this->get_settings();
       $widget_args = [];
       $widget_args['title'] = $settings['widget_title']==''?'':$settings['widget_title']; 
     
       $widget_args['number'] = $settings['number']; 
       $widget_args['show_date'] = $settings['show_date']=='yes'?1:0; 
       if($settings['advanced_settings'] =='yes'){
        add_filter( 'widget_posts_args', [$this,'filter_post'] );
       }
       ?>

        <div class="element-ready-wp-recent-post">
            <?php the_widget( 'WP_Widget_Recent_Posts' ,$widget_args); ?>
        </div>
    <?php
    }

    public function filter_post(){

        $settings   = $this->get_settings();

        $args = array(
            'posts_per_page'      => $settings['number'],
            'no_found_rows'       => true,
            'post_status'         => 'publish',
          
        );

        if($settings['ignore_sticky_posts'] =='yes'){
            $args['ignore_sticky_posts'] = 1;
        }else{
            $args['ignore_sticky_posts'] = 0; 
        }
        return $args;
    }
    protected function content_template() {}
}
