
<div class="element-ready-dash-cpt-scb-header">
    <?php foreach($this->links as $menu): ?>
        <?php if($menu['url'] == '#'): ?>
        <button class="element-ready-scb-view-item js-er-button-random <?php echo isset($menu['class_attr'])?$menu['class_attr']:''; ?>" > <?php echo esc_html( $menu['label'] ) ?> </button>
        <?php else: ?>
            <a class="element-ready-scb-view-item <?php echo isset($menu['class_attr'])?$menu['class_attr']:''; ?>" href="<?php echo esc_url(admin_url( $menu['url'] )); ?>"> <?php echo esc_html( $menu['label'] ) ?> </a>
        <?php endif ?>
   <?php endforeach; ?>
</div>