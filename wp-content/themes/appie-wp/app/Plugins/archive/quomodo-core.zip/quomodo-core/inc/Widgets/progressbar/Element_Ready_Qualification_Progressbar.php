<?php

namespace Element_Ready_Pro\Widgets\progressbar;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;
use Elementor\Plugin;
use Elementor\Repeater;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Element_Ready_Qualification_Progressbar extends Widget_Base
{

    public function get_name()
    {
        return 'Element_Ready_Qualification_Progressbar';
    }

    public function get_title()
    {
        return __('ER Qualification Bar', 'element-ready-pro');
    }

    public function get_icon()
    {
        return "eicon-hypster";
    }

    public function get_style_depends()
    {

        wp_register_style('eready-qualification-progressbar', ELEMENT_READY_PRO_ROOT_CSS . 'widgets/growth-qualification-bar.css');
        return [
            'eready-qualification-progressbar', 'slick'
        ];
    }

    public function get_script_depends()
    {

        return [
            'slick',
            'er_qualificationBar',

        ];
    }

    public function get_categories()
    {
        return ['element-ready-pro'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Qualification Content', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new Repeater();
        $repeater->add_control(
            'qualifi_title',
            [
                'label' => __('Title', 'element-ready-pro'),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('Enter the qualification title', 'element-ready-pro'),
                'default' => __('Diploma In Computer', 'element-ready-pro'),
                'title' => __('Qualification title', 'element-ready-pro'),
            ]
        );
        $repeater->add_control(
            'qualifi_content',
            [
                'label' => __('Description', 'element-ready-pro'),
                'type' => Controls_Manager::TEXTAREA,
                'placeholder' => __('Enter your qualification description.', 'element-ready-pro'),
                'default' => __('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.', 'element-ready-pro'),
                'title' => __('Qualification Description', 'element-ready-pro'),
            ]
        );
        $repeater->add_control(
            'session_year',
            [
                'label' => __('Session year', 'element-ready-pro'),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('Enter your session year.', 'element-ready-pro'),
                'default' => __('(2010-2014)', 'element-ready-pro'),
                'title' => __('Session year', 'element-ready-pro'),
            ]
        );
        $repeater->add_control(
            'session_color',
            [
                'label' => __('Session Color', 'element-ready-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffc576',
            ]
        );
        $repeater->add_control(
            'institute_name',
            [
                'label' => __('Institute Name', 'element-ready-pro'),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('Enter your institute name.', 'element-ready-pro'),
                'default' => __('BM College', 'element-ready-pro'),
                'title' => __('Institute Name', 'element-ready-pro'),
            ]
        );

        $this->add_control(
            'item_list',
            [
                'label' => __('Repeater List', 'element-ready-pro'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'qualifi_title' => __('Diploma In Computer', 'element-ready-pro'),
                        'qualifi_content' => __('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.', 'element-ready-pro'),
                        'institute_name' => __('BM College', 'element-ready-pro'),
                    ],
                ],
                'title_field' => '{{{ qualifi_title }}}',
            ]
        );

        $this->add_control(
            'slider_on',
            [
                'label'         => __('Slider', 'element-ready-pro'),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'      => __('On', 'element-ready-pro'),
                'label_off'     => __('Off', 'element-ready-pro'),
                'return_value'  => 'yes',
                'default'       => 'yes',
            ]
        );

        $this->add_control(
            'load_more',
            [
                'label'         => __('Load More Button', 'element-ready-pro'),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'      => __('On', 'element-ready-pro'),
                'label_off'     => __('Off', 'element-ready-pro'),
                'return_value'  => 'yes',
                'default'       => 'no',
                'condition' => [
                    'slider_on!' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'loaded_item',
            [
                'label' => __('Default Load', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 30,
                'step' => 1,
                'default' => 6,
                'condition' => [
                    'load_more' => 'yes',
                    'slider_on!' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'load_slice',
            [
                'label' => __('Slice Item', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 30,
                'step' => 1,
                'default' => 3,
                'condition' => [
                    'load_more' => 'yes',
                    'slider_on!' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'load_button_text',
            [
                'label' => __('Button Text', 'element-ready-pro'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Load More +', 'element-ready-pro'),
                'placeholder' => __('Enter button text...', 'element-ready-pro'),
                'condition' => [
                    'load_more' => 'yes',
                    'slider_on!' => 'yes',
                ]

            ]
        );

        $this->end_controls_section();
        // Slider setting
        $this->start_controls_section(
            'carosul_slider_option',
            [
                'label' => __('Slider Option', 'element-ready-pro'),
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slitems',
            [
                'label' => __('Slider Items', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 20,
                'step' => 1,
                'default' => 3,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'slarrows',
            [
                'label' => __('Slider Arrow', 'element-ready-pro'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'slprevicon',
            [
                'label' => __('Previous icon', 'element-ready-pro'),
                'type' => Controls_Manager::ICON,
                'default' => 'fa fa-angle-left',
                'condition' => [
                    'slider_on' => 'yes',
                    'slarrows' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slnexticon',
            [
                'label' => __('Next icon', 'element-ready-pro'),
                'type' => Controls_Manager::ICON,
                'default' => 'fa fa-angle-right',
                'condition' => [
                    'slider_on' => 'yes',
                    'slarrows' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'sldots',
            [
                'label' => __('Slider dots', 'element-ready-pro'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slpause_on_hover',
            [
                'type' => Controls_Manager::SWITCHER,
                'label_off' => __('No', 'element-ready-pro'),
                'label_on' => __('Yes', 'element-ready-pro'),
                'return_value' => 'yes',
                'default' => 'yes',
                'label' => __('Pause on Hover?', 'element-ready-pro'),
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slcentermode',
            [
                'label' => __('Center Mode', 'element-ready-pro'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slcenterpadding',
            [
                'label' => __('Center padding', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 500,
                'step' => 1,
                'default' => 50,
                'condition' => [
                    'slider_on' => 'yes',
                    'slcentermode' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slverticalmode',
            [
                'label' => __('Vertical Mode', 'element-ready-pro'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slautolay',
            [
                'label' => __('Slider auto play', 'element-ready-pro'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'separator' => 'before',
                'default' => 'no',
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slautoplay_speed',
            [
                'label' => __('Autoplay speed', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3000,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );


        $this->add_control(
            'slanimation_speed',
            [
                'label' => __('Autoplay animation speed', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'default' => 300,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slscroll_columns',
            [
                'label' => __('Slider item to scroll', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'step' => 1,
                'default' => 1,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'heading_tablet',
            [
                'label' => __('Tablet', 'element-ready-pro'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'sltablet_display_columns',
            [
                'label' => __('Slider Items', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 8,
                'step' => 1,
                'default' => 2,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'sltablet_scroll_columns',
            [
                'label' => __('Slider item to scroll', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 8,
                'step' => 1,
                'default' => 1,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'sltablet_width',
            [
                'label' => __('Tablet Resolution', 'element-ready-pro'),
                'description' => __('The resolution to tablet.', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'default' => 778,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'heading_mobile',
            [
                'label' => __('Mobile Phone', 'element-ready-pro'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slmobile_display_columns',
            [
                'label' => __('Slider Items', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 4,
                'step' => 1,
                'default' => 1,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slmobile_scroll_columns',
            [
                'label' => __('Slider item to scroll', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 4,
                'step' => 1,
                'default' => 1,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'slmobile_width',
            [
                'label' => __('Mobile Resolution', 'element-ready-pro'),
                'description' => __('The resolution to mobile.', 'element-ready-pro'),
                'type' => Controls_Manager::NUMBER,
                'default' => 480,
                'condition' => [
                    'slider_on' => 'yes',
                ]
            ]
        );
        $this->end_controls_section(); // Slider Option end        

        // post Style tab section
        $this->start_controls_section(
            'qualifi_area_style_section',
            [
                'label' => __('Area Style', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'qualifi_area__background',
                'label' => __('Background', 'element-ready-pro'),
                'types' => ['classic', 'gradient', 'video'],
                'selector' => '{{WRAPPER}} .qualifi-box-area',



            ]
        );

        $this->add_responsive_control(
            'qualifi_area_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'qualifi_area_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'qualifi_area_width',
            [
                'label' => __('Width', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section(); // post section style end

        // Service Style tab section
        $this->start_controls_section(
            'qualifi_column_style_section',
            [
                'label' => __('Column Style', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'slider_on!' => 'yes',
                ]
            ]
        );
        $this->add_responsive_control(
            'qualifi_column_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area.qualifi-grid .qualifi-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'qualifi_column_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area.qualifi-grid .qualifi-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'qualifi_column_width',
            [
                'label' => __('Width', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ]
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area .qualifi-item' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();




        // post Style tab section
        $this->start_controls_section(
            'qualifi_box_style_section',
            [
                'label' => __('Box Style', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'qualifi_info_dot_width',
            [
                'label' => __('Dot Size', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 6,
                ],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info .session:after' => 'border-width: calc({{SIZE}}{{UNIT}} / 2);',
                ],
            ]
        );

        $this->add_responsive_control(
            'qualifi_box_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area .qualifi-item .qualifi-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'qualifi_box_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area .qualifi-item .qualifi-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]

        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'qualifi_box_border',
                'label' => __('Border', 'core'),
                'selector' => '{{WRAPPER}} .qualifi-box-area .qualifi-item .qualifi-box',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'qualifi_box_border_radius',
            [
                'label' => esc_html__('Border Radius', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box-area .qualifi-item .qualifi-box' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'qualifi_box_shadow',
                'label' => __('Box Shadow', ''),
                'selector' => '{{WRAPPER}} .qualifi-box-area .qualifi-item .qualifi-box',
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'qualifi_box_background',
                'label' => __('Background', 'element-ready-pro'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .qualifi-box-area .qualifi-item .qualifi-box',
                'separator' => 'before',
            ]
        );

        $this->end_controls_section(); // post section style end


        // post Style tab section
        $this->start_controls_section(
            'qualifi_info_box_style_section',
            [
                'label' => __('Info Box', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'qualifi_info_box_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'qualifi_info_box_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'qualifi_info_box_width',
            [
                'label' => __('Width', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 150,
                ],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info' => 'min-width: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'qualifi_info_box_border',
                'label' => __('Border', 'core'),
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-info',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'qualifi_info_box_border_radius',
            [
                'label' => esc_html__('Border Radius', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'qualifi_info_box_shadow',
                'label' => __('Box Shadow', 'element-ready-pro'),
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-info',
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'qualifi_info_box_background',
                'label' => __('Background', 'element-ready-pro'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-info',
                'separator' => 'before',
            ]
        );

        $this->end_controls_section(); // post section style end


        //milon code start
        $this->start_controls_section(
            'content_box_style',
            [
                'label'     => __('Content Box', 'growthcore'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'slider_on' => 'yes',
                    'slarrows'  => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('content_box_style_tabs');

        // Normal tab Start
        $this->start_controls_tab(
            'content_box_style_normal_tab',
            [
                'label' => __('Normal', 'element-ready-pro'),
            ]
        );

        $this->add_responsive_control(
            'qualifi_content_box_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'qualifi_content_box_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]

        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'qualifi_content_box_border',
                'label' => __('Border', 'core'),
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-content',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'qualifi_content_box_border_radius',
            [
                'label' => esc_html__('Border Radius', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'qualifi_content_box_shadow',
                'label' => __('Box Shadow', 'element-ready-pro'),
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-content',
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'qualifi_content_box_background',
                'label' => __('Background', 'element-ready-pro'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-content',

            ]
        );

        $this->end_controls_tab();


        $this->start_controls_tab(
            'content_box_style_hover_tab',
            [
                'label' => __('Hover', 'element-ready-pro'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'qualifi_content_box_hover_background',
                'label' => __('Hover Background', 'element-ready-pro'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-content:hover',

            ]
        );
        $this->end_controls_tab();

        $this->end_controls_tabs();
        $this->end_controls_section();


        //milon code end post section style end

        // Qualification Style tab section
        $this->start_controls_section(
            'box_session_section',
            [
                'label' => __('Session Year', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'qualifi_session_typography',
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-info .session',
            ]
        );

        $this->add_responsive_control(
            'session_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '10',
                    'left' => '0',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info .session' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'session_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'isLinked' => false
                ],
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info .session' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();


        // Qualification Style tab section
        $this->start_controls_section(
            'box_college_section',
            [
                'label' => __('Institute Name', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'qualifi_college_color',
            [
                'label' => __('Color', 'element-ready-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info .collage' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'qualifi_college_typography',
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-info .collage',
            ]
        );

        $this->add_responsive_control(
            'college_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '10',
                    'left' => '0',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info .collage' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'college_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'isLinked' => false
                ],
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-info .collage' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        // Qualification Style tab section
        $this->start_controls_section(
            'box_title_section',
            [
                'label' => __('Title Style', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'qualifi_title_typography',
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-content .title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'element-ready-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content .title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '20',
                    'left' => '0',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'isLinked' => false
                ],
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();


        // qualification Style tab section
        $this->start_controls_section(
            'box_content_section',
            [
                'label' => __('Content Style', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'qualifi_content_typography',
                'selector' => '{{WRAPPER}} .qualifi-box .qualifi-content .desc',
            ]
        );
        $this->add_control(
            'content_color',
            [
                'label' => __('Color', 'element-ready-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content .desc' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'isLinked' => false
                ],
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .qualifi-box .qualifi-content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();


        $this->start_controls_section(
            'slider_arrow_style',
            [
                'label'     => __('Arrow', 'element-ready-pro'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'slider_on' => 'yes',
                    'slarrows'  => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('slider_arrow_style_tabs');

        // Normal tab Start
        $this->start_controls_tab(
            'slider_arrow_style_normal_tab',
            [
                'label' => __('Normal', 'element-ready-pro'),
            ]
        );

        $this->add_control(
            'slider_arrow_color',
            [
                'label' => __('Color', 'element-ready-pro'),
                'type' => Controls_Manager::COLOR,

                'default' => '#FFC576',
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_fontsize',
            [
                'label' => __('Font Size', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'slider_arrow_background',
                'label' => __('Background', 'element-ready-pro'),
                'default' => '#ffffff',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow',
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_height',
            [
                'label' => __('Height', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'slider_arrow_line_height',
            [
                'label' => __('Line Height', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 46,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow' => 'line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_width',
            [
                'label' => __('Width', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_padding',
            [
                'label' => __('Padding', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'slider_arrow_border',
                'label' => __('Border', 'element-ready-pro'),
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow',
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_border_radius',
            [
                'label' => esc_html__('Border Radius', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'slider_arrow_box_shadow',
                'label' => __('Box Shadow', 'element-ready-pro'),
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow',
            ]
        );


        $this->end_controls_tab(); // Normal tab end

        // Hover tab Start
        $this->start_controls_tab(
            'slider_arrow_style_hover_tab',
            [
                'label' => __('Hover', 'element-ready-pro'),
            ]
        );

        $this->add_control(
            'slider_arrow_hover_color',
            [
                'label' => __('Color', 'element-ready-pro'),
                'type' => Controls_Manager::COLOR,

                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'slider_arrow_hover_background',
                'label' => __('Background', 'element-ready-pro'),
                'types' => ['classic', 'gradient'],
                'default' => '#ffc576',
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow:before',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'slider_arrow_hover_border',
                'label' => __('Border', 'element-ready-pro'),
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow:hover',
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_hover_border_radius',
            [
                'label' => esc_html__('Border Radius', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'slider_arrow_box_shadow_hover',
                'label' => __('Box Shadow', 'element-ready-pro'),
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow:hover',
            ]
        );


        $this->end_controls_tab(); // Hover tab end

        $this->end_controls_tabs();

        $this->add_control(
            'slider_arrow_position_title',
            [
                'label'     => __('Arrow Position', 'element-ready-pro'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs('slider_arrow_position_tabs');
        // Normal tab Start
        $this->start_controls_tab(
            'slider_arrow_prev_tab',
            [
                'label' => __('Prev', 'element-ready-pro'),
            ]
        );
        $this->add_control(
            'prev_arrow_x_dir',
            [
                'label' => __('Direction X', 'element-ready-pro'),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left'  => __('Left', 'element-ready-pro'),
                    'right' => __('Right', 'element-ready-pro'),
                ],
            ]
        );
        $this->add_responsive_control(
            'slider_arrow_prev_gap_x',
            [
                'label' => __('Position X', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw'],
                'range' => [
                    'px' => [
                        'min' => -9999,
                        'max' => 9999,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vh' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 125,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow.slick-prev' => 'position: absolute; {{prev_arrow_x_dir.VALUE}}: {{SIZE}}{{UNIT}};'
                ],
            ]
        );

        $this->add_control(
            'prev_arrow_y_dir',
            [
                'label' => __('Direction Y', 'element-ready-pro'),
                'type' => Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top'  => __('Top', 'element-ready-pro'),
                    'bottom' => __('Bottom', 'element-ready-pro'),
                ],
            ]
        );
        $this->add_responsive_control(
            'slider_arrow_prev_gap_y',
            [
                'label' => __('Position Y', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vh'],
                'range' => [
                    'px' => [
                        'min' => -9999,
                        'max' => 9999,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vh' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => -50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow.slick-prev' => 'position: absolute; {{prev_arrow_y_dir.VALUE}}: {{SIZE}}{{UNIT}};'
                ],
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_prev_border_radius',
            [
                'label' => __('Border Radius', 'eforestcore'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'isLinked' => true
                ],
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow.slick-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );
        $this->add_responsive_control(
            'slider_arrow_prev_display',
            [
                'label' => __('Show/Hide', 'element-ready-pro'),
                'description' => __('To Show/Hide in the responsive devices.', 'element-ready-pro'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'block' => [
                        'title' => __('Show', 'element-ready-pro'),
                        'icon' => 'fa fa-eye',
                    ],
                    'none' => [
                        'title' => __('Hide', 'element-ready-pro'),
                        'icon' => 'fa fa-eye-slash',
                    ],
                ],
                'separator' => 'before',
                'default' => 'block',
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow.slick-prev' => 'display: {{VALUE}} !important;',
                ],
            ]
        );
        $this->end_controls_tab(); // Left Arrow tab end

        // Hover tab Start
        $this->start_controls_tab(
            'slider_arrow_next_tab',
            [
                'label' => __('Next', 'element-ready-pro'),
            ]
        );
        $this->add_control(
            'next_arrow_x_dir',
            [
                'label' => __('Direction X', 'element-ready-pro'),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left'  => __('Left', 'element-ready-pro'),
                    'right' => __('Right', 'element-ready-pro'),
                ],
            ]
        );
        $this->add_responsive_control(
            'slider_arrow_next_gap_x',
            [
                'label' => __('Position X', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw'],
                'range' => [
                    'px' => [
                        'min' => -9999,
                        'max' => 9999,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vh' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 125,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow.slick-next' => 'position: absolute; {{next_arrow_x_dir.VALUE}}: {{SIZE}}{{UNIT}};'
                ],
            ]
        );
        $this->add_control(
            'next_arrow_y_dir',
            [
                'label' => __('Direction Y', 'element-ready-pro'),
                'type' => Controls_Manager::SELECT,
                'default' => 'bottom',
                'options' => [
                    'top'  => __('Top', 'element-ready-pro'),
                    'bottom' => __('Bottom', 'element-ready-pro'),
                ],
            ]
        );
        $this->add_responsive_control(
            'slider_arrow_next_gap_y',
            [
                'label' => __('Position Y', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vh'],
                'range' => [
                    'px' => [
                        'min' => -9999,
                        'max' => 9999,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vh' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => -25,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow.slick-next' => 'position: absolute; {{next_arrow_y_dir.VALUE}}: {{SIZE}}{{UNIT}};'
                ],
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_next_border_radius',
            [
                'label' => __('Border Radius', 'eforestcore'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'isLinked' => true
                ],
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow.slick-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_responsive_control(
            'slider_arrow_next_display',
            [
                'label' => __('Show/Hide', 'element-ready-pro'),
                'description' => __('To Show/Hide in the responsive devices.', 'element-ready-pro'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'block' => [
                        'title' => __('Show', 'element-ready-pro'),
                        'icon' => 'fa fa-eye',
                    ],
                    'none' => [
                        'title' => __('Hide', 'element-ready-pro'),
                        'icon' => 'fa fa-eye-slash',
                    ],
                ],
                'separator' => 'before',
                'default' => 'block',
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-arrow.slick-next' => 'display: {{VALUE}} !important;',
                ],
            ]
        );
        $this->end_controls_tab(); // Right Arrow tab end
        $this->end_controls_tabs();
        $this->end_controls_section(); // Style Slider arrow style end


        // Style Pagination button tab section
        $this->start_controls_section(
            'post_slider_pagination_style_section',
            [
                'label' => __('Pagination', 'element-ready-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'slider_on' => 'yes',
                    'sldots' => 'yes',
                ]
            ]
        );
        $this->add_responsive_control(
            'growth_portfolio_dots_alignment',
            [
                'label' => __('Alignment', 'element-ready-pro'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'element-ready-pro'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'element-ready-pro'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'element-ready-pro'),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => __('Justified', 'element-ready-pro'),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .slick-dots' => 'text-align: {{VALUE}};'
                ],
                'default' => 'left',
                'separator' => 'before',
            ]
        );
        $this->start_controls_tabs('pagination_style_tabs');

        $this->start_controls_tab(
            'pagination_style_normal_tab',
            [
                'label' => __('Normal', 'element-ready-pro'),
            ]
        );

        $this->add_responsive_control(
            'slider_pagination_height',
            [
                'label' => __('Height', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-dots li button' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'slider_pagination_width',
            [
                'label' => __('Width', 'element-ready-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-dots li button' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'pagination_background',
                'label' => __('Background', 'element-ready-pro'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-dots li button',
            ]
        );

        $this->add_responsive_control(
            'pagination_margin',
            [
                'label' => __('Margin', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-dots li button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'pagination_border',
                'label' => __('Border', 'element-ready-pro'),
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-dots li button',
            ]
        );

        $this->add_responsive_control(
            'pagination_border_radius',
            [
                'label' => esc_html__('Border Radius', 'element-ready-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .growthcore-carousel-activation .slick-dots li button' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );

        $this->end_controls_tab(); // Normal Tab end

        $this->start_controls_tab(
            'pagination_style_active_tab',
            [
                'label' => __('Active', 'element-ready-pro'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'pagination_hover_background',
                'label' => __('Background', 'element-ready-pro'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .growthcore-carousel-activation .slick-dots li button:hover, {{WRAPPER}} .growthcore-carousel-activation .slick-dots li.slick-active button',
            ]
        );

        $this->end_controls_tab(); // Hover Tab end

        $this->end_controls_tabs();

        $this->end_controls_section();
    }
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $html = '';


        $this->add_render_attribute('elements_qs_qualifi_attr', 'class', 'qualifi-box-area');


        if ($settings['load_more'] == 'yes') {
            $load_settings = [
                'loaded_item' => $settings['loaded_item'],
                'load_slice' => $settings['load_slice']
            ];

            $this->add_render_attribute('elements_qs_qualifi_attr', 'class', 'load-more-content');
            $this->add_render_attribute('elements_qs_qualifi_attr', 'data-load', wp_json_encode($load_settings));
        }


        if ($settings['slider_on'] == 'yes') {
            $slider_settings = [
                'arrows' => ('yes' === $settings['slarrows']),
                'arrow_prev_txt' => $settings['slprevicon'],
                'arrow_next_txt' => $settings['slnexticon'],
                'dots' => ('yes' === $settings['sldots']),
                'autoplay' => ('yes' === $settings['slautolay']),
                'autoplay_speed' => absint($settings['slautoplay_speed']),
                'animation_speed' => absint($settings['slanimation_speed']),
                'pause_on_hover' => ('yes' === $settings['slpause_on_hover']),
                'center_mode' => ('yes' === $settings['slcentermode']),
                'vertical_mode' => ('yes' === $settings['slverticalmode']),
                'center_padding' => $settings['slcenterpadding'] . 'px',
            ];

            $slider_responsive_settings = [
                'display_columns' => $settings['slitems'],
                'scroll_columns' => $settings['slscroll_columns'],
                'tablet_width' => $settings['sltablet_width'],
                'tablet_display_columns' => $settings['sltablet_display_columns'],
                'tablet_scroll_columns' => $settings['sltablet_scroll_columns'],
                'mobile_width' => $settings['slmobile_width'],
                'mobile_display_columns' => $settings['slmobile_display_columns'],
                'mobile_scroll_columns' => $settings['slmobile_scroll_columns'],

            ];

            $this->add_render_attribute('elements_qs_qualifi_attr', 'class', 'growthcore-carousel-activation');
            $slider_settings = array_merge($slider_settings, $slider_responsive_settings);
            $this->add_render_attribute('elements_qs_qualifi_attr', 'data-settings', wp_json_encode($slider_settings));
        } else {
            $this->add_render_attribute('elements_qs_qualifi_attr', 'class', 'qualifi-grid');
        }

        if ($settings['item_list']) {
            $html .= '<div ' . $this->get_render_attribute_string("elements_qs_qualifi_attr") . ' >';
            foreach ($settings['item_list'] as $item) {
                $html .= '<div class="qualifi-item">';
                $html .= '<div class="qualifi-box">';
                $html .= '<div class="qualifi-info">';
                if (!empty($item['session_year'])) {
                    $html .= '<div class="session" style="color:' . $item['session_color'] . ';" >' . esc_html($item['session_year']) . '</div>';
                }
                if (!empty($item['institute_name'])) {
                    $html .= '<div class="collage">' . esc_html($item['institute_name']) . '</div>';
                }
                $html .= '</div>';
                $html .= '<div class="qualifi-content">';
                if (!empty($item['qualifi_title'])) {
                    $html .= '<h4 class="title">' . esc_html($item['qualifi_title']) . '</h4>';
                }
                if (!empty($item['qualifi_content'])) {
                    $html .= '<div class="desc">' . wp_kses_post($item['qualifi_content']) . '</div>';
                }
                $html .= '</div>';
                $html .= '</div>';
                $html .= '</div>';
            }
            if (empty($settings['load_button_text'])) {
                $settings['load_button_text'] = esc_html__('Load More', 'element-ready-pro');
            }
            if ($settings['load_more'] == 'yes') {
                $html .= '<div class="load-button" >';
                $html .= '<button type="button" class="load-more" >' . wp_kses_post($settings['load_button_text']) . '</button>';
                $html .= '</div>';
            }
            $html .= '</div>';
        }


        echo $html;
    } // End Rendar


} // End Class
