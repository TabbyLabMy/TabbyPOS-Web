<?php
namespace Element_Ready_Pro\Widgets\blog;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

/**
 * Portfolio details
 * @author quomodosoft.com
 */
class Element_Ready_PortFolio_Details extends Widget_Base {

    public function get_name() {
        return 'element-ready-pro-portfolio-details-option';
    }
    public function get_keywords() {
		return ['portfolio option','Portfolio meta'];
	}
    public function get_title() {
        return esc_html__( 'ER PortFolio Meta', 'element-ready-pro' );
    }

    public function get_icon() { 
        return ' eicon-meta-data';
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'layout_contents_section',
            [
                'label' => esc_html__( 'Layout Options', 'element-ready-pro' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'style',
            [
                'label'   => esc_html__( 'Layout', 'element-ready-pro' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'style1',
                'options' => [
                    'style1' => esc_html__( 'Style1', 'element-ready-pro' ),
                    'style2' => esc_html__( 'No Label', 'element-ready-pro' )
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'wready_content_cart_section',
            [
                'label' => esc_html__( 'Settings', 'element-ready-pro' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label'       => esc_html__( 'Lebel', 'element-ready-pro' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'List Lebel' , 'element-ready-pro' ),
				'label_block' => true,
			]
		);

        $repeater->add_control(
			'list_meta_key',
			[
				'label' => esc_html__( 'Meta Option', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => $this->get_meta(),
			]
		);

		$repeater->add_control(
			'list_color',
			[
				'label' => esc_html__( 'Label Color', 'element-ready-proe' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}.er-portfolio-item-label' => 'color: {{VALUE}}'
				],
			]
		);

        
		$repeater->add_control(
			'list_content_color',
			[
				'label' => esc_html__( 'Content Color', 'element-ready-proe' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}.er-portfolio-item-data' => 'color: {{VALUE}}'
				],
			]
		);

		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Meta List', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					
				],
				'title_field' => '{{{ list_title }}}',
			]
		);


        $this->add_control(
			'display_flex',
			[
				'label' => esc_html__( 'Display', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'flex',
				'options' => [
					'flex'         => esc_html__( 'Flex', 'element-ready-pro' ),
					'inline-flex'  => esc_html__( 'Inline Flex', 'element-ready-pro' ),
					
				],
                'selectors' => [
                    '{{WRAPPER}} .er-portfolio-detail-meta-items' => 'display: {{VALUE}};',
               ],
			]
		);

        $this->add_control(
			'direction_flex',
			[
				'label' => esc_html__( 'Direction', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'column',
				'options' => [

					'column' => esc_html__( 'Column', 'element-ready-pro' ),
					'row'    => esc_html__( 'Row', 'element-ready-pro' ),
					
				],
                'selectors' => [
                    '{{WRAPPER}} .er-portfolio-detail-meta-items' => 'flex-direction: {{VALUE}};',
               ],
			]
		);

        $this->add_control(
			'oitem_gap',
			[
				'label' => esc_html__( 'Gap', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .er-portfolio-detail-meta-items' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
   
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'element-ready-pro' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'element-ready-pro' ),
                  'icon'  => 'eicon-text-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'element-ready-pro' ),
                  'icon'  => 'eicon-text-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'element-ready-pro' ),
						'icon'  => 'eicon-text-align-right',
                  
					],
				'space-between'	 => [

						'title' => esc_html__( 'Spacebetween', 'element-ready-pro' ),
						'icon'  => 'eicon-justify-space-between-h',
                  
					],
				],
               'default' => 'left',
            
                'selectors' => [
                     '{{WRAPPER}} .er-portfolio-detail-meta-items' => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .er-portfolio-detail-meta-items' => 'justify-content: {{VALUE}};',
				],
			]
        );//Responsive control end

        $this->add_responsive_control(
			'title_item_align', [
				'label'   => esc_html__( 'Item Alignment', 'element-ready-pro' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'flex-start'		 => [
                  
                  'title' => esc_html__( 'Left', 'element-ready-pro' ),
                  'icon'  => 'eicon-text-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'element-ready-pro' ),
                  'icon'  => 'eicon-text-align-center',
               
               ],
			   'flex-end'	 => [
            		'title' => esc_html__( 'Right', 'element-ready-pro' ),
					'icon'  => 'eicon-text-align-right',
            	],
				'baseline'	 => [
            		'title' => esc_html__( 'Baseline', 'element-ready-pro' ),
					'icon'  => 'eicon-justify-space-between-h',
              	],
				],
               'default' => 'left',
            
                'selectors' => [
                    '{{WRAPPER}} .er-portfolio-detail-meta-items' => 'align-items: {{VALUE}};',
				],
			]
        );//Responsive control end

        $this->end_controls_section();
   
        
         /*---------------------------
            INPUT STYLE START
        ----------------------------*/
        $this->start_controls_section(
            'element_ready_form_input_style_section',
            [
                'label' => __( 'Lebel', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs( 'input_box_tabs' );

          
                $this->start_controls_tab(
                    'input_box_normal_tab',
                    [
                        'label' => __( 'Normal', 'element-ready-pro' ),
                    ]
                );
                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_box_typography',
                            'selector' => '
                                {{WRAPPER}} .er-portfolio-item-label
                              
                            ',
                        ]
                    );
                    $this->add_control(
                        'input_box_text_color',
                        [
                            'label'     => __( 'Text Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .er-portfolio-item-label'   => 'color:{{VALUE}};',
                            
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'input_box_background',
                            'label'    => __( 'Background', 'element-ready-pro' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '
                                {{WRAPPER}} .er-portfolio-item-label
                            
                            ',
                        ]
                    );
  
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_box_shadow',
                            'selector' => '
                                {{WRAPPER}} .er-portfolio-item-label

                            ',
                        ]
                    );

                    $this->add_control(
                        'item_label_padding',
                        [
                            'label' => esc_html__( 'Padding', 'element-ready-pro' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors' => [
                                '{{WRAPPER}} .er-portfolio-item-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        \Elementor\Group_Control_Border::get_type(),
                        [
                            'name' => 'item_sl_aborder',
                            'label' => esc_html__( 'Border', 'element-ready-pro' ),
                            'selector' => '{{WRAPPER}} .er-portfolio-item-label',
                        ]
                    );

                    $this->add_control(
                        'input_box_transition',
                        [
                            'label'      => __( 'Transition', 'element-ready-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0.1,
                                    'max'  => 3,
                                    'step' => 0.1,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => 0.3,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .er-portfolio-item-label'   => 'transition: {{SIZE}}s;',
                               
                            ],
                        ]
                    );

                $this->end_controls_tab();
    
                $this->start_controls_tab(
                    'input_box_hover_tabs',
                    [
                        'label' => __( 'Hover', 'element-ready-pro' ),
                    ]
                );

                    $this->add_control(
                        'input_box_hover_color',
                        [
                            'label'     => __( 'Text Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .er-portfolio-item-label:hover'   => 'color:{{VALUE}};',
                            
                            ],
                        ]
                    );
             
                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section(
            'element_ready_form_content_style_section',
            [
                'label' => __( 'Content', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'content_box_typography',
                    'selector' => '
                        {{WRAPPER}} .er-portfolio-item-data
                    ',
                ]
            );

            $this->add_control(
                'content_box_text_color',
                [
                    'label'     => __( 'Text Color', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-portfolio-item-data'   => 'color:{{VALUE}};',
                    
                    ],
                ]
            );
        
            $this->add_control(
                'content_box_hover_color',
                [
                    'label'     => __( 'Hover Color', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-portfolio-item-data:hover'   => 'color:{{VALUE}};',
                    
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Background:: get_type(),
                [
                    'name'     => 'content_box_background',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '
                        {{WRAPPER}} .er-portfolio-item-data
                    
                    ',
                ]
            );

            $this->add_control(
                'content_sl_padding',
                [
                    'label' => esc_html__( 'Padding', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .er-portfolio-item-data' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'content_sl_aborder',
                    'label' => esc_html__( 'Border', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} .er-portfolio-item-data',
                ]
            );

        $this->end_controls_section();
        $this->start_controls_section(
            'element_ready_item_style_section',
            [
                'label' => __( 'Item', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'item_display_flex',
            [
                'label' => esc_html__( 'Display', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'flex',
                'options' => [
                    'flex'         => esc_html__( 'Flex', 'element-ready-pro' ),
                    'inline-flex'  => esc_html__( 'Inline Flex', 'element-ready-pro' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .er-portfolio-detail-meta-items > div' => 'display: {{VALUE}};',
               ],
            ]
        );

        $this->add_control(
            'item_direction_flex',
            [
                'label' => esc_html__( 'Direction', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [

                    'column' => esc_html__( 'Column', 'element-ready-pro' ),
                    'row'    => esc_html__( 'Row', 'element-ready-pro' ),
                    
                ],
                'selectors' => [
                    '{{WRAPPER}} .er-portfolio-detail-meta-items > div' => 'flex-direction: {{VALUE}};',
               ],
            ]
        );

        $this->add_control(
            'content_item_gap',
            [
                'label' => esc_html__( 'Gap', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .er-portfolio-detail-meta-items > div' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
   
        $this->add_responsive_control(
            'item_align', [
                'label'   => esc_html__( 'Alignment', 'element-ready-pro' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'element-ready-pro' ),
                  'icon'  => 'eicon-text-align-left',
               
               ],
                'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'element-ready-pro' ),
                  'icon'  => 'eicon-text-align-center',
               
               ],
               'right'	 => [

                        'title' => esc_html__( 'Right', 'element-ready-pro' ),
                        'icon'  => 'eicon-text-align-right',
                  
                    ],
                'space-between'	 => [

                        'title' => esc_html__( 'Justified', 'element-ready-pro' ),
                        'icon'  => 'eicon-text-align-justify',
                  
                    ],
                ],
               'default' => 'left',
            
                'selectors' => [
                    
                     '{{WRAPPER}} .er-portfolio-detail-meta-items > div' => 'justify-content: {{VALUE}};',
                ],
            ]
        );//Responsive control end

        $this->add_responsive_control(
            'item_item_align', [
                'label'   => esc_html__( 'Item Alignment', 'element-ready-pro' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [

               'flex-start'		 => [
                  
                  'title' => esc_html__( 'Left', 'element-ready-pro' ),
                  'icon'  => 'eicon-text-align-left',
               
               ],
                'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'element-ready-pro' ),
                  'icon'  => 'eicon-text-align-center',
               
               ],
               'flex-end'	 => [
                    'title' => esc_html__( 'Right', 'element-ready-pro' ),
                    'icon'  => 'eicon-text-align-right',
                ],
                'baseline'	 => [
                    'title' => esc_html__( 'Baseline', 'element-ready-pro' ),
                    'icon'  => 'eicon-text-align-justify',
                  ],
                ],
               'default' => 'left',
            
                'selectors' => [
                    '{{WRAPPER}} .er-portfolio-detail-meta-items > div' => 'align-items: {{VALUE}};',
                ],
            ]
        );//Responsive control end

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'itemss_sl_aborder',
                'label' => esc_html__( 'Border', 'element-ready-pro' ),
                'selector' => '{{WRAPPER}} .er-portfolio-detail-meta-items > div',
            ]
        );

        $this->add_control(
			'items_sl_paddingss',
			[
				'label' => esc_html__( 'Padding', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .er-portfolio-detail-meta-items > div' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        /*-----------------------------
            INPUT STYLE END
        -------------------------------*/

    }

    public function get_meta(){

        return apply_filters(
            'er_portfolio_meta_options',
            [
                'er_portfolio_advanced_options_start-date' => 'Start Date',
                'er_portfolio_advanced_options_end-date'   => 'End Date',
                'er_portfolio_advanced_options_location'   => 'Location',
                'er_portfolio_advanced_options_client'     => 'Client',
                'er_portfolio_advanced_options_budget'     => 'Budget',
                'er_portfolio_advanced_options_website'    => 'Website',
                'er_portfolio_advanced_options_type'       => 'Type'
            ]
        );

    }

    protected function render() {
 
        $settings  = $this->get_settings();

        $args = array(
            'post_type' => 'portfolio',
            'orderby' => 'date',
            'order' => 'DESC',
            'posts_per_page' => 1
             );
        $query = wp_get_recent_posts( $args );
        
        if(!isset($query[0]['ID'])){
          echo 'no portfolio found';
          return;
        }

        if(\Elementor\Plugin::$instance->editor->is_edit_mode()){
            $GLOBALS['post'] = get_post($query[0]['ID']);
        }

        if($settings['style'] == 'style1'): 
         if ( $settings['list'] ) {
		 	echo '<dl class="er-portfolio-detail-meta-items">';
		 	foreach (  $settings['list'] as $item ) {
                echo '<div>';
		 		echo '<dt class="er-portfolio-item-label elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">' . $item['list_title'] . '</dt>';
		 		echo '<dd class="er-portfolio-item-data elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">' . get_post_meta(get_the_id(),$item['list_meta_key'],true) . '</dd>';
                echo '</div>';
		 	}
		 	echo '</dl>';
	     }
        endif;    
        if($settings['style'] == 'style2'): 

            if ( $settings['list'] ) {
                echo '<dl class="er-portfolio-detail-meta-items">';
                foreach (  $settings['list'] as $item ) {
                   echo '<div>';
                    echo '<dd class="er-portfolio-item-data elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">' . get_post_meta(get_the_id(),$item['list_meta_key'],true) . '</dd>';
                   echo '</div>';
                }
                echo '</dl>';
            }
        endif;    
       
    }


}