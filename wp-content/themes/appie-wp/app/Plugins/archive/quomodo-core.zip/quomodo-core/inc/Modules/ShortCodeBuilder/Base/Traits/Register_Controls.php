<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Db_Controls;
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 
 */
trait Register_Controls
{
  
    use \Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\Er_Content_Control;
    use \Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\Er_Style_Control;
    protected function register_controls() {

        // Content Control start
		$this->_er_init_content();
        //Style Control start
		$this->_er_init_style();
	}


	
}
  