<?php
namespace Element_Ready_Pro\Widgets\general;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Element_Ready\Controls\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Element_Ready_ThreeSixty_Rotation extends Widget_Base {

    public function get_name() {
        return 'Element_Ready_ThreeSixty_Rotation';
    }
    
    public function get_title() {
        return __( 'ER 360 Rotation', 'element-ready-pro' );
    }

    public function get_icon() {
        return 'eicon-image-rollover';
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_script_depends() {
     
        return [
          
       ];
    }
  
	public function get_keywords() {
        return [ '360','rotation', 'er image rotation' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'images_content_section',
            [
                'label' => __( 'Images', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
                'list_title', [
                    'label' => esc_html__( 'Title', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'List Title' , 'element-ready-pro' ),
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'list_image',
                [
                    'label' => esc_html__( 'Choose Image', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'list',
                [
                    'label' => esc_html__( 'Image List', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'list_title' => esc_html__( 'Title #1', 'element-ready-pro' ),
                            'list_image' => [
                                'url' => ELEMENT_READY_PRO_ROOT_IMG .'watch.jpg',
                            ],
                        ],
                       
                    ],
                    'title_field' => '{{{ list_title }}}',
                ]
            );

           

        $this->end_controls_section();
        $this->start_controls_section(
            'bg_content_section',
            [
                'label' => __( 'Background Size', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
                'custom_bg_dimension',
                [
                    'label' => esc_html__( 'Background Size', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::IMAGE_DIMENSIONS,
                    'description' => esc_html__( 'Crop the original image size to any custom size. Set custom width or height to keep the original size ratio.', 'plugin-name' ),
                    'default' => [
                        'width' => '',
                        'height' => '',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .er-rotate-image' => 'background-size: {{width}}% {{height}}% !important;',
                    ],
                ]
            );

        $this->end_controls_section();
        $this->start_controls_section(
            '_content_section',
            [
                'label' => __( 'Controls & Style', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

            $this->add_control(
                'height',
                [
                    'label' => esc_html__( 'Height', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'default' => [
                        'unit' => 'px',
                        'size' => 300,
                    ],
                   
                ]
            );

            $this->add_control(
                'width',
                [
                    'label' => esc_html__( 'Width', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'default' => [
                        'unit' => 'px',
                        'size' => 300,
                    ],
                  
                ]
            );

            $this->add_control(
                'perrow',
                [
                    'label'   => esc_html__( 'perRow', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 1,
                    'max'     => 400,
                    'step'    => 1,
                    'default' => 4,
                ]
            );

            $this->add_control(
                'count',
                [
                    'label'   => esc_html__( 'Count', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 1,
                    'max'     => 400,
                    'step'    => 1,
                    'default' => 20,
                ]
            );

            $this->add_control(
                'speed',
                [
                    'label'   => esc_html__( 'Speed', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 1,
                    'max'     => 400,
                    'step'    => 1,
                    'default' => 100,
                ]
            );
            $this->add_control(
                'autoplay',
                [
                    'label'        => esc_html__( 'Default Play?', 'element-ready-pro' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'no',
                   
                ]
            );
           

            $this->add_control(
                'controls',
                [
                    'label'        => esc_html__( 'Control?', 'element-ready-pro' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'no',
                ]
            );
  

            $this->add_control(
                'toggle_play',
                [
                    'label'        => esc_html__( 'Toggle Play Button?', 'element-ready-pro' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'no',
                    'condition' => ['controls' => ['yes']]
                ]
            );

            $this->add_control(
                'toggle_play_text',
                [
                    'label'     => esc_html__( 'Toggle Play Text', 'element-ready-pro' ),
                    'type'      => \Elementor\Controls_Manager::TEXT,
                    'default'   => esc_html__( 'Play', 'element-ready-pro' ),
                    'condition' => ['controls' => ['yes']]
                ]
            );

            $this->add_control(
                'prev_icon',
                [
                    'label' => esc_html__( 'Prev Icon', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'condition' => ['controls' => ['yes']]
                ]
            );
          
            $this->add_control(
                'prev_text',
                [
                    'label'     => esc_html__( 'Previous Text', 'element-ready-pro' ),
                    'type'      => \Elementor\Controls_Manager::TEXT,
                    'default'   => esc_html__( 'Prev', 'element-ready-pro' ),
                    'condition' => ['controls' => ['yes']]
                ]
            );

            $this->add_control(
                'next_icon',
                [
                    'label' => esc_html__( 'Next Icon', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'condition' => ['controls' => ['yes']]
                ]
            );

            $this->add_control(
                'next_text',
                [
                    'label'     => esc_html__( 'Next Text', 'element-ready-pro' ),
                    'type'      => \Elementor\Controls_Manager::TEXT,
                    'default'   => esc_html__( 'Next', 'element-ready-pro' ),
                    'condition' => ['controls' => ['yes']]
                ]
            );

        $this->end_controls_section();
        // TABLE STYLE
        $this->start_controls_section(
            '_table_style_section',
            [
                'label' => __( 'Control Wrapper', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
               
            ]
        );

        $this->add_control(
            'flex_button_position',
            [
                'label' => esc_html__( 'Position?', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    'relative' => esc_html__( 'Yes', 'element-ready-pro' ),
                    '' => esc_html__( 'No', 'element-ready-pro' ),
               ],
               'selectors' => [
                    '{{WRAPPER}} .er-three-sixty' => 'position: {{VALUE}};',
                    '{{WRAPPER}} .er-buttons-wrapper' => 'position: absolute;',
               ]
            ]
        );

        $this->add_control(
            'button_position_bottom',
            [
                'label' => esc_html__( 'Bottom', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'flex_button_position' => [
                        'relative'
                    ]
                ], 
                'selectors' => [
                    '{{WRAPPER}} .er-buttons-wrapper' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_position_top',
            [
                'label' => esc_html__( 'Top', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'flex_button_position' => [
                        'relative'
                    ]
                ], 
                'selectors' => [
                    '{{WRAPPER}} .er-buttons-wrapper' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_control(
            'button_position_left',
            [
                'label' => esc_html__( 'Left', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'flex_button_position' => [
                        'relative'
                    ]
                ], 
                'selectors' => [
                    '{{WRAPPER}} .er-buttons-wrapper' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_position_right',
            [
                'label' => esc_html__( 'Right', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'flex_button_position' => [
                        'relative'
                    ]
                ], 
                'selectors' => [
                    '{{WRAPPER}} .er-buttons-wrapper' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


           
            $this->add_control(
                'text_align',
                [
                    'label' => esc_html__( 'Alignment', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => esc_html__( 'Left', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__( 'Center', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => esc_html__( 'Right', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'default' => 'left',
                    'toggle' => true,
                    'condition' => [
                        'flex_button_position!' => [
                            'relative'
                        ]
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .er-buttons-wrapper' => 'text-align: {{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'button_display',
                [
                    'label' => esc_html__( 'Display', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'inline-block',
                    'options' => [
                        'flex' => esc_html__( 'Flex', 'element-ready-pro' ),
                        'block' => esc_html__( 'Block', 'element-ready-pro' ),
                        'inline-block' => esc_html__( 'Inline Block', 'element-ready-pro' ),
                   ],
                    'selectors' => [
                        '{{WRAPPER}} .er-buttons-wrapper' => 'display: {{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'element_gap_width',
                [
                    'label' => esc_html__( 'Gap', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 300,
                            'step' => 2,
                        ],
                      
                    ],
                    'default' => [
                        'unit' => 'px',
                        'size' => 5,
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .er-buttons-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'flex_direction',
                [
                    'label' => esc_html__( 'Flex Direction', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'inline-block',
                    'options' => [
                        'column' => esc_html__( 'Column', 'element-ready-pro' ),
                        'row' => esc_html__( 'Row', 'element-ready-pro' ),
                   ],
                    'selectors' => [
                        '{{WRAPPER}} .er-buttons-wrapper' => 'flex-direction: {{VALUE}};',
                    ],
                    'condition' => [
                        'button_display' => [
                            'flex'
                        ]
                    ]
                ]
            );

            $this->add_control(
                'vertical_direction',
                [
                    'label' => esc_html__( 'Vertical Content ', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'left',
                    'options' => [
                        '' => esc_html__( 'Default', 'element-ready-pro' ),
                        'left' => esc_html__( 'left', 'element-ready-pro' ),
                        'right' => esc_html__( 'Right', 'element-ready-pro' ),
                        'center' => esc_html__( 'Center', 'element-ready-pro' ),
                        'space-between' => esc_html__( 'Space Between', 'element-ready-pro' ),
                   ],
                    'selectors' => [
                        '{{WRAPPER}} .er-buttons-wrapper' => 'justify-content: {{VALUE}};',
                        '{{WRAPPER}} .er-buttons-wrapper button' => 'align-items: center;display:flex;gap:3px;',
                    ],
                    'condition' => [
                        'button_display' => [
                            'flex'
                        ]
                    ]
                ]
            );
 
     
        $this->end_controls_section();
        $this->start_controls_section(
            '_button_icon_style_section',
            [
                'label' => __( 'Button Icon', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
               
            ]
        );

        $this->add_control(
            'button_icon_color',
            [
                'label' => esc_html__( 'Color', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .er-buttons-wrapper button i' => 'color: {{VALUE}}',
                '{{WRAPPER}} .er-buttons-wrapper button svg' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_icon_typography',
                'selector' => '{{WRAPPER}} .er-buttons-wrapper button i',
            ]
        );

        $this->add_responsive_control(
            'button_icon_padding',
            [
                'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .er-buttons-wrapper button i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .er-buttons-wrapper button svg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            '_button_style_section',
            [
                'label' => __( 'Button', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
               
            ]
        );

            $this->add_control(
                'button__color',
                [
                    'label' => esc_html__( 'Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .er-buttons-wrapper button' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'button_hover_color',
                [
                    'label' => esc_html__( 'Hover Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .er-buttons-wrapper button:hover' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'button__typography',
                    'selector' => '{{WRAPPER}} .er-buttons-wrapper button',
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name'     => 'button_able_background',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .er-buttons-wrapper button',
                ]
            );

            $this->add_group_control(
                Group_Control_Border:: get_type(),
                    [
                        'name'     => 'button_ble_border',
                        'label'    => esc_html__( 'Border', 'element-ready-pro' ),
                        'selector' => '{{WRAPPER}} .er-buttons-wrapper button',
                        'separator' => 'before',
                    ]
            );

            $this->add_responsive_control(
                'button_able_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .er-buttons-wrapper button' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'button_ble_padding',
                [
                    'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'default' => [
                        'top' => 10,
                        'bottom' => 10,
                        'left' => 10,
                        'right' => 10,
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .er-buttons-wrapper button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'button_ble_margin',
                [
                    'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                
                    'selectors'  => [
                        '{{WRAPPER}} .er-buttons-wrapper button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

           
        $this->end_controls_section();

     
    }

    protected function render( $instance = [] ) {

        $settings = $this->get_settings_for_display();

        $this->add_render_attribute( 'er__content_wrap_attr', 'class', 'er-three-sixty' );
        $this->add_render_attribute( 'er__content_wrap_attr', 'id', 'er-rotate-'. $this->get_id());
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-height', $settings['height']['size']);
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-width', $settings['width']['size']);
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-perrow', $settings['perrow']);
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-count', $settings['count']);
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-speed', $settings['speed']);
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-controls', $settings['controls']);
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-autoplay', $settings['autoplay']);
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-toggle_play', $settings['toggle_play']);
        $this->add_render_attribute( 'er__content_wrap_attr', 'data-prev_text', $settings['prev_text']);
        
        $image_lists = [];
        if ( $settings['list'] ) {

           if(is_array($settings['list'])){

             foreach (  $settings['list'] as $item ) {
                if(isset($item['list_image']['url'])){
                    $image_lists[] = $item['list_image']['url'];
                }
             }
             $this->add_render_attribute( 'er__content_wrap_attr', 'data-urls', join('||',$image_lists));
           }
           
        }


       
        // settings js data
        ?> 
       	<div <?php echo $this->get_render_attribute_string( 'er__content_wrap_attr' ); ?> >
           <div class="er-rotate-image">
           </div>
           <?php if($settings['controls'] == 'yes'): ?>
                <div class="er-buttons-wrapper">
                    <button class="er-rotate-prev"><?php echo element_ready_render_icons($settings['prev_icon']).' '.$settings['prev_text']; ?> </button>
                    <button class="er-rotate-next"><?php echo $settings['next_text'] .' ' .element_ready_render_icons($settings['next_icon']); ?> </button>
                    <?php if($settings['toggle_play'] =='yes'): ?>
                        <button class="er-rotate-play"><?php echo $settings['toggle_play_text']; ?></button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

<script>


</script>

        <?php
    }
}