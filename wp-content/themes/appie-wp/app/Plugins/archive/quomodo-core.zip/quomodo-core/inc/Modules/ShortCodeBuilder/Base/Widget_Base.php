<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base;
use Elementor\Widget_Base as  Elementor_Widget_Base;

class Widget_Base extends Elementor_Widget_Base
{
    use \Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\Register_Controls;
    use \Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\Basic_Render;
    public function get_name()
	{
		return "_scb_Custom_builder_widget_changeable_name";
	}

    public function er_get_db_seetings(){

        $data_settings = get_post_meta($this->widget_post_id(),ELEMENT_READY_PRO_BUILDER_WIDGET_KEY,true);
        return $data_settings;  
    }

    public function get_style_depends(){

        
        $settings_cdn = $this->er_get_db_seetings();
        $cdn_list = [];
        if(isset($settings_cdn['active_cdn']) && is_array($settings_cdn['active_cdn'])){

            $cdn_list = $this->er_get_cdn_type($settings_cdn['active_cdn'],'css');
        }

        $path = ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/css/'.$this->get_widget_name().'.css';
        $url = ELEMENT_READY_PRO_WP_UPLOAD_URL.'/css/'.$this->get_widget_name().'.css';

        if(file_exists($path)){

            wp_register_style( $this->get_widget_name(),$url,[] );
            $cdn_list[] = $this->get_widget_name();
            return $cdn_list;
        }
        
        return $cdn_list;
    }

    public function get_script_depends(){
       

        $settings_cdn = $this->er_get_db_seetings();
        $cdn_list = [];
        if(isset($settings_cdn['active_cdn']) && is_array($settings_cdn['active_cdn'])){

            $cdn_list = $this->er_get_cdn_type($settings_cdn['active_cdn']);
        }

        $path = ELEMENT_READY_PRO_WP_UPLOAD_DIR_PATH.'/js/'.$this->get_widget_name().'.js';
        $url = ELEMENT_READY_PRO_WP_UPLOAD_URL.'/js/'.$this->get_widget_name().'.js';

        if(file_exists($path)){
           
            wp_register_script( $this->get_widget_name(),$url, ['elementor-frontend'],  time() , true);
            $cdn_list[] = $this->get_widget_name();
           
            return $cdn_list;
        }
        
        return $cdn_list;
    }

    public function er_get_cdn_type( $active_cdn,$type='js' ){

        $register_asset = [];
        $all_cdn = get_option( 'element_ready_scb_builder_cdn_list' );

        if(is_array( $all_cdn )){

            foreach($all_cdn as $item){
                 
                 if( in_array( $item[ 'name' ] , $active_cdn ) ){

                    if( isset( $item[ 'type' ] ) && $item[ 'type' ] == $type ){

                        if( $type == 'css' ){
                            wp_register_style( $item[ 'name' ] ,$item[ 'url' ] ,[] );
                        }elseif( $type == 'js' ){
                            wp_register_script( $item[ 'name' ] ,$item[ 'url' ], [],  time() , true); 
                        }
                       
                        $register_asset[] = $item[ 'name' ];
                    }
                 } 
               
            }
        }
       
        return $register_asset;
    }

}