jQuery(document).ready(function ($) {

          
        
        var er_scb_json_global_obj = {};
        var er_edit_id = null;
        var er_html_selected_mouse_pos_left = null;
        var scb_widget_js_content        = $('#er-scb-builder-widget-js-content');
        var scb_widget_css_content       = $('#er-scb-builder-widget-css-content');
        var scb_widget_html_content      = $('#er-scb-builder-widget-html-content');
        var scb_widget_html_loop_content = $('#er-scb-builder-widget-html-loop-content');
        var scb_widget_html_loop_content_two = $('#er-scb-builder-widget-html-loop-content2');
        var scb_widget_html_loop_key_one = $('#er-scb-controls-html-repeater-list-options');
        var scb_widget_html_loop_key_two = $('#er-scb-controls-html-repeater-list-options2');
        var scb_widget_name              = $('#er-scb-widget-title');
        var scb_widget_slug              = $('#er-scb-widget-name');
        var scb_widget_control_repeater  = $('#er-scb-cont-builder-repeater-value');
      
        scb_widget_control_repeater.hide();
        // html css js content insert
        
       
        scb_widget_html_content.val(shortcode_builder_obj.widget_settings_data.content_html);
        scb_widget_css_content.val(shortcode_builder_obj.widget_settings_data.content_css);
        scb_widget_js_content.val(shortcode_builder_obj.widget_settings_data.content_js);
        scb_widget_html_loop_content.val(shortcode_builder_obj.widget_settings_data.content_loop_html);
        scb_widget_html_loop_content_two.val(shortcode_builder_obj.widget_settings_data.content_loop_html_two);
        
        scb_widget_slug.val(shortcode_builder_obj.widget_settings_data.widget_slug);

        scb_widget_name.val(shortcode_builder_obj.er_post.post_name);
        if (typeof shortcode_builder_obj.widget_settings_data.widget_name !== "undefined") {
            scb_widget_name.val(shortcode_builder_obj.widget_settings_data.widget_name);
        }

        if (typeof shortcode_builder_obj.widget_settings_data.widget_slug !== "undefined" && shortcode_builder_obj.widget_settings_data.widget_slug.length > 2 ) {
            scb_widget_slug.val(shortcode_builder_obj.widget_settings_data.widget_slug);
        }else{
            scb_widget_slug.val(shortcode_builder_obj.er_post.post_name); 
        }
       
        
        var cdn_template_data = {
            'cdn_type' : ['js','css'],
            'listItems': [

                {
                    id: 1,
                    type: "js",
                    name: "Jquery",
                    url: '#'
                },
            
                
            ]
        };
       
        var er_controls_data = {
    
            'controls_list': [
   
                
            ]
        };

  

        if (typeof shortcode_builder_obj.widget_settings_data.control_list !== "undefined") {
            er_controls_data.controls_list = shortcode_builder_obj.widget_settings_data.control_list;
        }
       
        var control_arguments_list = $('.er-scb-builder-arguments-list input[name=er-scb-builder-argument-single]');
        
        var er_choose_data = {
    
            'choose_items': [

                // {
                //     value: '',
                //     name: '',
                // },
                
            ],
            'repeater_items': [
                
            ]
        };

        var er_repeater_keys = {
            'general': [
                'title', 
            ],
            'socialrepeater': [
             'title','icon','link' 
            ],
            'repeater': [
                
            ],
            'post': [
                'title',
                'url',
                'image_full_url',
                'image_thumbnail_url',
                'content',
                'excerpt',
                'author_name',
                'modified_date',
                'author_url',
                'date',
                'name',
                'comment_count',
                'category_name',
                'category_url',
                'tag_name',
                'tag_url'
            ],
            'control_list': er_controls_data.controls_list
         };
  
        
         er_controls_data.controls_list.forEach(function(item) {
             console.log();
             if(item.control_f_type == 'repeater' && item.control_type =='content'){
                 er_repeater_keys.repeater[item.control_name] =  item.control_args;  
             }
            
         });
        
        // get all cdn
        jQuery.ajax({
            url: shortcode_builder_obj.ajax_url, // This is globally available, it resolves to the admin ajax url
            method: 'POST',
            data: {
                // The action must be the same as the name of your php class
                action: 'element_ready_pro_scb_fatch_cdn',
                // For security reason, you must specify the nonce created for your php class
                // You can get it by suffixing "Nonce" to your php class, like so
                nonce: shortcode_builder_obj.scb_nonce,
                // Then send whatever data you like
                
            },
            success: function (response) {
                
                cdn_template_data.listItems = response.data.cdn_template_data==false?[]:response.data.cdn_template_data;
                
                let find_item = _.findWhere(cdn_template_data.listItems, {name:'jquery'});
                if(!find_item){

                    cdn_template_data.listItems.push({
                        id: 1000,
                        type: "js",
                        'name': "jquery",
                        url: '#'
                    }); 
                }
               
                cdn_template_data['active_cdn'] = typeof shortcode_builder_obj.widget_settings_data.active_cdn !== "undefined"?shortcode_builder_obj.widget_settings_data.active_cdn:[];
               
                let _item_content =  template( cdn_template_data );
                $( ".er-scb-dependent-lib" ).html(_item_content);
            },
        });

    // Tabs

   
        $( "#element-ready-scb-tabs" ).tabs(
            {
                active: 0,
                classes: {
                    "ui-tabs": "element-ready-tab-highlight"
                },
                collapsible: true,
                
            }
        ); 
        
        $( "#element-ready-scb-tabs-header" ).tabs(
            {
                active: 0,
                classes: {
                    "ui-tabs": "element-ready-tab-header-highlight",
                    
                    "ui-tabs-nav": "ui-corner-all element-ready-nav-header",
                    "ui-tabs-tab": "ui-corner-top element-ready-nav-corner-top",
                    "ui-tabs-panel": "ui-corner-bottom"
                },
                collapsible: true,
                
            }
        );
        // widgets settings start
      
        

        $("#erp-scb-builder-style-control-type").hide();
        $("#er-scb-cont-builder-default-value").hide();
        $('#er-scb-cont-builder-choose-value').hide();

        var template                                 = wp.template( 'er-scb-dynamic-cdn-includes' );
        var choose_template                          = wp.template( 'er-scb-builder-choose-controls-container' );
        var controls_lists_template                  = wp.template( 'er-scb-builder-controls-data-table-lists' );
        var controls_html_sidebar_template           = wp.template( 'er-scb-builder-html-controls-lists-sidebar' );
        var controls_repeater_sidebar_template       = wp.template( 'er-scb-builder-html-item-controls-lists-sidebar' );
        var controls_repeater_sidebar_template_two   = wp.template( 'er-scb-builder-html-item-controls-lists-sidebar2' );
        var controls_repeater_sidebar_template_keys  = wp.template( 'er-scb-builder-html-controls-lists-sidebar-keys' );
        var controls_repeater_sidebar_template_keys2 = wp.template( 'er-scb-builder-html-controls-lists-sidebar-keys2' );
        var scb_widget_control_repeater_tpl          = wp.template( 'er-scb-builder-repeater-controls-container' );
        var item_content                             = template( cdn_template_data );
        var er_choose_content                        = choose_template( er_choose_data );
        var er_repeater_content                      = scb_widget_control_repeater_tpl( er_choose_data );
        var er_control_table_content                 = controls_lists_template( er_controls_data );
        
       
        $( ".er-scb-dependent-lib" ).html(item_content);
        $( "#er-scb-builder-choose-controls-item" ).html( er_choose_content );
        $( "#er-scb-item-attr-container-table" ).html( er_control_table_content );

        var er_control_html_sidebar_content = controls_html_sidebar_template( er_controls_data );
        $( "#er-scb-controls-html-list-options" ).html( er_control_html_sidebar_content );
        // repeater html
        var er_control_repeater_sidebar_content = controls_repeater_sidebar_template( er_controls_data );
        $( "#er-scb-controls-html-repeater-list-options" ).html( er_control_repeater_sidebar_content );

        var er_control_repeater_sidebar_content2 = controls_repeater_sidebar_template_two( er_controls_data );
        $( "#er-scb-controls-html-repeater-list-options2" ).html( er_control_repeater_sidebar_content2 );
     
  
  
         //scb_widget_html_loop_key_one
        //content_loop_field
    
        if (typeof shortcode_builder_obj.widget_settings_data.content_loop_field !== "undefined" && shortcode_builder_obj.widget_settings_data.content_loop_field.length > 0 ) {
            
            er_controls_data.er_repeater_control_one = {
                'title':shortcode_builder_obj.widget_settings_data.content_loop_field
            }
            setTimeout(function(){ 
 
                scb_widget_html_loop_key_one.val(shortcode_builder_obj.widget_settings_data.content_loop_field).trigger('change');
               
            }, 500);
          
        }

        if (typeof shortcode_builder_obj.widget_settings_data.content_loop_field_two !== "undefined" && shortcode_builder_obj.widget_settings_data.content_loop_field_two.length > 0 ) {
            er_controls_data.er_repeater_control_two = {
                'title':shortcode_builder_obj.widget_settings_data.content_loop_field_two
            }
            setTimeout(function(){ 
 
            scb_widget_html_loop_key_two.val(shortcode_builder_obj.widget_settings_data.content_loop_field_two).trigger('change');
            }, 500);
           
        }

        // repeater keys 
        er_repeater_keys.f_type = shortcode_builder_obj.widget_settings_data.content_loop_field=='undefined'?'general':shortcode_builder_obj.widget_settings_data.content_loop_field;
      
        var er_control_repeater_keys_sidebar_content = controls_repeater_sidebar_template_keys( er_repeater_keys );
        $( "#er-scb-controls-repeater-html-list-options-keys" ).html( er_control_repeater_keys_sidebar_content );
    
        // repeater keys 2
        er_repeater_keys.f_type_two = shortcode_builder_obj.widget_settings_data.content_loop_field_two=='undefined'?'general':shortcode_builder_obj.widget_settings_data.content_loop_field_two;
        var er_control_repeater_keys_sidebar_content2 = controls_repeater_sidebar_template_keys2( er_repeater_keys );
        $( "#er-scb-controls-repeater-html-list-options-keys2" ).html( er_control_repeater_keys_sidebar_content2 );
     
        // repeater_keys obj
      
        

        $('.element-ready-scb-add-new').on( 'click' , function() {
             
            var er_cdn_asset_type = $('#er-scb-cdn-assets');
            var er_cdn_asset_name = $('#er-scb-cdn-assets-name');
            var er_cdn_asset_url  = $('#er-scb-cdn-assets-url');
            
            if( er_cdn_asset_name.val() == '' ){
                er_cdn_asset_name.css({'border-color':'red'});
                return false;
            }
            if( er_cdn_asset_url.val() == '' ){
                er_cdn_asset_url.css({'border-color':'red'});
                return false;
            }

            cdn_template_data.listItems.push({'name':er_cdn_asset_name.val().replace(/\s+/g, '_').toLowerCase(),'url':er_cdn_asset_url.val(),'type':er_cdn_asset_type.val()});
            item_content =  template( cdn_template_data );
            $( ".er-scb-dependent-lib" ).html(item_content);
           
            jQuery.ajax({
                url: shortcode_builder_obj.ajax_url, // This is globally available, it resolves to the admin ajax url
                method: 'POST',
                data: {
                    // The action must be the same as the name of your php class
                    action: 'element_ready_pro_scb_store_cdn',
                    // For security reason, you must specify the nonce created for your php class
                    // You can get it by suffixing "Nonce" to your php class, like so
                    nonce: shortcode_builder_obj.scb_nonce,
                    // Then send whatever data you like
                    cdn_template_data: cdn_template_data.listItems,
                },
                success: function (response) {
                
                },
            });
            
        });

        // sort cdn 
         $('.er-scb-dependent-lib').sortable(
             {
                
                update: function( event, ui ) {

                   
                    let er_cdn_new_sort = [];
                     $(this).find('.er-libs-scb-item input').each(function( index,item ) {
                         let cdn_that_ = $(item).val(); 
                         let cdn_found_item = _.findWhere(cdn_template_data.listItems, {name:cdn_that_});
                  
                        er_cdn_new_sort.push(cdn_found_item);
                     });
                     
                     setTimeout(function(){ 
                            cdn_template_data.listItems = er_cdn_new_sort;
                            $('.er-scb-dependent-lib').html(template( cdn_template_data ));

                            jQuery.ajax({
                                url: shortcode_builder_obj.ajax_url, // This is globally available, it resolves to the admin ajax url
                                method: 'POST',
                                data: {
                                    // The action must be the same as the name of your php class
                                    action: 'element_ready_pro_scb_store_cdn',
                                    // For security reason, you must specify the nonce created for your php class
                                    // You can get it by suffixing "Nonce" to your php class, like so
                                    nonce: shortcode_builder_obj.scb_nonce,
                                    // Then send whatever data you like
                                    cdn_template_data: cdn_template_data.listItems,
                                },
                                success: function (response) {
                                
                                },
                            });
                           
                        },
                     1000);
                   
                }
             }
         );

         $(document).on('click','.er-libs-scb-item .er-scb-remove', function() {

            var cdn_index = $(this).data('id');
            var reject_er_js = $(this).siblings().val();
            
            if(reject_er_js == 'jquery'){
                return;
            }

            if( cdn_index > -1){
                cdn_template_data.listItems.splice(cdn_index, 1);
                item_content =  template( cdn_template_data );
                $( ".er-scb-dependent-lib" ).html(item_content);
            }
   
         
         });
        

         // Controls
    

         $("#er-scb-attr-control-type").on('change',function(){

             var er_scb_control_type = $(this).val();
        
             if(er_scb_control_type =='style'){
                $("#erp-scb-builder-style-control-type").show();
                $(".erp-scb-content-control-type").hide();
                $("#er-scb-cont-builder-default-value").hide();
                $(".er-scb-cont-builder-choose-value").hide();
                
             }else if(er_scb_control_type =='content'){

                $("#er-scb-cont-builder-default-value").show();
                $(".erp-scb-content-control-type").show();
                $("#erp-scb-builder-style-control-type").hide();
               
                var er_control_types = element_ready_scb_cont($(".er-scb-control-type").val()); 
                if( er_control_types ){
                   $(".er-scb-cont-default-value").show();
                }

             }

            
       
         });

         $("#er-scb-control-type").on('change',function(){

           var er_content_control_type = $(this).val();
          
           var er_return_result = element_ready_scb_cont(er_content_control_type); 
            
           //

           if(er_content_control_type == 'repeater'){
              scb_widget_control_repeater.show();
           }else{
            scb_widget_control_repeater.hide();  
           }

           if( er_return_result ){
                $("#er-scb-cont-builder-default-value").show();
            }else{
                $("#er-scb-cont-builder-default-value").hide();
            }

            var choose_type_result = element_ready_scb_cont2(er_content_control_type);
          
            if( choose_type_result ){
                $('#er-scb-cont-builder-choose-value').show();
               
            }else{
                $('#er-scb-cont-builder-choose-value').hide();
            }
          
         });

         // choose items  
         $('.er-scb-builder-control-chosse-add').on('click',function(){
          
            var _scb_builder_choose_ = $('.er-scb-builder-control-choose-value');
            var _scb_builder_choose = _scb_builder_choose_.val();
           
            if(_scb_builder_choose.length > 1){
               
                er_choose_data.choose_items.push({'value':_scb_builder_choose.replace(/\s+/g, '_').toLowerCase(),'name':_scb_builder_choose});
                 er_choose_content = choose_template( er_choose_data );
                $( "#er-scb-builder-choose-controls-item" ).html(er_choose_content);
                _scb_builder_choose_.val(''); 
            }
           
        });

          // choose 
          $(document).on('click','.er-libs-scb-item .er-scb-choose-option-remove', function() {

            var cdn_index = $(this).data('id');

            if(cdn_index > -1){
                er_choose_data.choose_items.splice(cdn_index, 1);
                er_choose_content = choose_template( er_choose_data );
                $( "#er-scb-builder-choose-controls-item" ).html(er_choose_content);
            }
         
         });

        $('.er-scb-builder-control-repeater-add').on( 'click',function(){

            let __control__type         = $('.er-scb-attr-control-title');
            let repeater__control__type = $('#er-scb-builder-control-repeater-control-type').val();
            let repeater_default_val    = $('#er-scb-widget-repeater-default-value-add');
            let repeater_title          = $('#er-scb-widget-repeater-title-value-add');
            let repeater_name           = repeater_title.val().replace(/\s+/g, '_').toLowerCase();
         
            if(__control__type.val().length < 1 ){
               
                __control__type.css({background:'#e0c8c8',color:'#fff'});
              return;   
            }else{
                __control__type.css({background:'#fff','color':'#000'});  
            }
            
            if(repeater_title.val().length < 1 ){
               
                repeater_title.css({background:'#e0c8c8',color:'#fff'});
              return;   
            }else{
                repeater_title.css({background:'#fff','color':'#000'});  
            }
            
            let find_re_name = _.findWhere(er_choose_data.repeater_items, {name:repeater_name});

            if( _.isObject(find_re_name)){
                repeater_name = repeater_name+'_'+Math.floor(Math.random() * 9);
                alert('Duplicate title . Please change title');
            }
            let er_new_content_obj = {
                type:'content',
                default:repeater_default_val.val(),
                title: repeater_title.val(),
                name: repeater_name,
                control_type: repeater__control__type
            };
         
            if(_.isObject(er_choose_data.repeater_items)){
                er_choose_data.repeater_items.push(er_new_content_obj);
            }else{
                er_choose_data.repeater_items = [];
                er_choose_data.repeater_items.push(er_new_content_obj);
            }
           
            $( "#er-scb-builder-repeater-controls-item" ).html(scb_widget_control_repeater_tpl( er_choose_data ));

            er_repeater_keys.repeater[__control__type.val()] =  er_choose_data.repeater_items;
           
            
            
        }); 

        $('#er-scb-widget-repeater-title-value-add').on('input',function(){
            let repeater_title          = $(this);
            if(repeater_title.val().length < 1 ){
                repeater_title.css({background:'#e0c8c8',color:'#fff'});
            }else{
                repeater_title.css({background:'#fff','color':'#000'});  
            }
        });
        
        $('.er-scb-attr-control-title').on('input',function(){
            let repeater_title          = $(this);
            if(repeater_title.val().length < 1 ){
                repeater_title.css({background:'#e0c8c8',color:'#fff'});
            }else{
                repeater_title.css({background:'#fff','color':'#000'});  
            }
        });

           // repeater 
        $(document).on('click','.er-libs-scb-item .er-scb-repeater-option-remove', function() {

            var r_index = $(this).data('id');

            if(r_index > -1){
                er_choose_data.repeater_items.splice(r_index, 1);
               
                $( "#er-scb-builder-repeater-controls-item" ).html(scb_widget_control_repeater_tpl( er_choose_data ));
            }
         
         });
      
         $('.er-scb-style-control-type').on('change',function(){
            $("#er-scb-cont-builder-default-value").hide();
            $('#er-scb-cont-builder-choose-value').hide();
         });

         // submit new control 
         $('#er-scb-control-submit-to-table').on('click',function(){
             
             
             var er_button_action_id = $(this).attr("data-id");
             let er_control_type        = $('#er-scb-attr-control-type');
             let er_control_option_list = [ ];
             
             let er_control_title          = $('.er-scb-attr-control-title');
             let er_control_f_type         = $('#er-scb-control-type');
             let er_control_value          = $('.er-scb-attr-control-default-value');
             let er_control_selector_value = $('.er-scb-attr-control-css-selector-value');
             let er_store_value            = {};
             var f_type_result             = element_ready_scb_cont2(er_control_f_type.val());
             
            
             if(er_control_title.val().length < 1){
                  er_control_title.css({background:'#e0c8c8',color:'#fff'});
                 return;
             }else{
                er_control_title.css({background:'#fff',color:'#000'});
             }

            

             if(f_type_result){

                var control_arguments_list = $('.er-scb-builder-arguments-list input[name=er-scb-builder-argument-single]');
                $.each(control_arguments_list, function( index, item ) {
                  
                    er_control_option_list.push({id:$(item).val().replace(/\s+/g, '_').toLowerCase(),name: $(item).val()});
                });
                
             }else if(er_control_type.val() == 'content' && er_control_f_type.val() == 'repeater'){
                er_control_option_list = er_choose_data.repeater_items;
             }
            
             // style 
             let er_style_control = $('.er-scb-style-control-type');
          
            if($(this).data('id')) {
              
                er_controls_data.controls_list.map(function(obj) {

                    if(obj.id === er_button_action_id) {
               
                        obj.control_type    = er_control_type.val();
                        obj.control_selector   = er_control_selector_value.val();
                        obj.control_Title   = er_control_title.val();
                        if(obj.control_f_type == 'post'){
                            obj.control_name    = 'post';
                        }else{
                            obj.control_name    = er_control_title.val().replace(/\s+/g, '_').toLowerCase();
                        }
                       
                        if(er_control_type.val() == 'style'){
                            obj.control_f_type  = er_style_control.val();
                            obj.control_default = '';
                        }else{
                            obj.control_f_type  = er_control_f_type.val();
                            obj.control_default = er_control_value.val();
                        }    
                        obj.control_args   = er_control_option_list;
                    }
                    return obj;
                });

               

            }else{

                let ealready_exist = _.findWhere(er_controls_data.controls_list, {control_name:er_control_title.val().replace(/\s+/g, '_').toLowerCase()});
            
                if(_.isObject(ealready_exist)){
                   er_control_title.css({background:'#e0c8c8',color:'#fff'});
                   er_control_title.after('<p> Name Already Exist . give another name </p>');
                   return;
                }else{
                   er_control_title.css({background:'#fff',color:'#000'});
                   er_control_title.siblings('p').remove();
                }
              
                var er_control_id = "id-"+Math.floor(Math.random() * 11) + Math.floor(Date.now() / 1000);
                er_store_value =  {
                    id             : er_control_id,
                    control_type   : er_control_type.val(),
                    control_f_type : er_control_f_type.val(),
                    control_default: er_control_value.val(),
                    control_name   : er_control_title.val().replace(/\s+/g, '_').toLowerCase(),
                    control_Title  : er_control_title.val(),
                    control_selector  : er_control_selector_value.val(),
                    control_args   : er_control_option_list,
                    control_actions: [],
                };
                  
                if(er_control_f_type.val() == 'post'){
                    er_store_value.control_name = 'post'; 
                }
                if(er_control_type.val() == 'style'){
               
                    er_store_value.control_f_type = er_style_control.val(); 
                    er_store_value.control_default = ''; 
                }

                er_controls_data.controls_list.push( er_store_value );
                element_ready_clear_form_control_fields();
            }
         
             er_control_table_content = controls_lists_template( er_controls_data );
             $( "#er-scb-item-attr-container-table" ).html(er_control_table_content);
            // repeater item 

             let er_store_control_repeater_html_obj_one    = $('select#er-scb-controls-html-repeater-list-options');
             let er_store_control_repeater_html_obj_two    = $('select#er-scb-controls-html-repeater-list-options2');
            
             er_store_control_repeater_html_obj_one.html( controls_repeater_sidebar_template( er_controls_data ) );
             er_store_control_repeater_html_obj_two.html( controls_repeater_sidebar_template_two( er_controls_data ) );
             
            if(er_repeater_keys.f_type == 'undefined'){
                er_repeater_keys.f_type = er_store_control_repeater_html_obj_one.val(); 
             }


             $( "#er-scb-controls-repeater-html-list-options-keys" ).html( controls_repeater_sidebar_template_keys( er_repeater_keys ) );

             if(er_repeater_keys.f_type == 'undefined'){
                er_repeater_keys.f_type = er_store_control_repeater_html_obj_two.val(); 
             }
       
            
             $( "#er-scb-controls-repeater-html-list-options-keys2" ).html( controls_repeater_sidebar_template_keys2( er_repeater_keys ) );

             $(this).removeAttr('data-id');
             tb_remove();
             element_ready_option_control_update();
             er_choose_data.repeater_items = [];
             //$('#er-scb-control-submit-to-table').trigger('click');

         });
        
         // remove control
         $('.er-remove-list-control').on('click',function(){

            let _index = $( this ).data('id');

            if( _index > -1 ){
                er_controls_data.controls_list.splice(_index, 1);
                er_control_table_content = controls_lists_template( er_controls_data );
                $( "#er-scb-item-attr-container-table" ).html(er_control_table_content);
            }
            element_ready_option_control_update();
            
         });
          // remove virtual control
         $(document).on('click','.er-remove-list-control',function(){
            
            let _index = $( this ).data('id');

            if( _index > -1 ){
                er_controls_data.controls_list.splice(_index, 1);
                er_control_table_content = controls_lists_template( er_controls_data );
                $( "#er-scb-item-attr-container-table" ).html(er_control_table_content);
            }

            element_ready_option_control_update();
           
         });

         //edit
         $('.er-edit-list-control').on( 'click',function(){
               let e_index = $( this ).data('id');
               er_edit_id = e_index;
            
               tb_show("HAI","#TB_inline?&width=800&height=800&inlineId=er-scb-content-control-modal",null);
              
               let edit_item = _.findWhere(er_controls_data.controls_list, {id:e_index});
               $('#er-scb-control-submit-to-table').attr('data-id',e_index);
               
               $('.er-scb-attr-control-title').val(edit_item.control_Title);
               $('#er-scb-attr-control-type').val(edit_item.control_type).change();
               $('#er-scb-control-type').val(edit_item.control_f_type).change();
               $('.er-scb-attr-control-default-value').val(edit_item.control_default);
               $('.er-scb-attr-control-css-selector-value').val(edit_item.control_selector);

               if(edit_item.control_f_type == 'repeater'){

                    er_choose_data.repeater_items = edit_item.control_args;
                    $( "#er-scb-builder-repeater-controls-item" ).html(scb_widget_control_repeater_tpl( er_choose_data ));
                    
                 
               
               }else if(element_ready_scb_cont2(edit_item.control_f_type)){
                
                 edit_item.control_args.forEach(function(item) {
                    er_choose_data.choose_items.push({value:item.name,'name':item.name})
                });
                
                $( "#er-scb-builder-choose-controls-item" ).html(choose_template( er_choose_data ));
                er_choose_data.repeater_items = [];
               }else{
                er_choose_data.repeater_items = [];
               }
               element_ready_option_control_update();
         });
  
    
         //edit virtual 

         $(document).on( 'click' ,'.er-edit-list-control',function(){
            let e_index = $( this ).data('id');
            er_edit_id = e_index;
         
            tb_show("Edit","#TB_inline?&width=800&height=800&inlineId=er-scb-content-control-modal",null);
           
            let edit_item = _.findWhere(er_controls_data.controls_list, {id:e_index});
            $('#er-scb-control-submit-to-table').attr('data-id',e_index);
            
            $('.er-scb-attr-control-title').val(edit_item.control_Title);
            $('#er-scb-attr-control-type').val(edit_item.control_type).change();
            $('#er-scb-control-type').val(edit_item.control_f_type).change();
            $('.er-scb-attr-control-default-value').val(edit_item.control_default);
            $('.er-scb-attr-control-css-selector-value').val(edit_item.control_selector);

            if(edit_item.control_f_type == 'repeater'){
                    er_choose_data.repeater_items = edit_item.control_args;
                    $( "#er-scb-builder-repeater-controls-item" ).html(scb_widget_control_repeater_tpl( er_choose_data ));
            
            }else if(element_ready_scb_cont2(edit_item.control_f_type)){
                
                edit_item.control_args.forEach(function(item) {
                    er_choose_data.choose_items.push({value:item.name,'name':item.name})
                });
                
                $( "#er-scb-builder-choose-controls-item" ).html(choose_template( er_choose_data ));
            }

            element_ready_option_control_update();
      });

      // codemirror activate 

      var er_codemirror_html_content = CodeMirror.fromTextArea(document.getElementById("er-scb-builder-widget-html-content"), {
            lineNumbers: true,
            mode: 'htmlmixed',
            theme: 'dracula',
      });
      
      var er_codemirror_html_loop_content = CodeMirror.fromTextArea(document.getElementById("er-scb-builder-widget-html-loop-content"), {
            lineNumbers: true,
            mode: 'htmlmixed',
            theme: 'dracula',
      });
      
      var er_codemirror_html_loop_content_two = CodeMirror.fromTextArea(document.getElementById("er-scb-builder-widget-html-loop-content2"), {
            lineNumbers: true,
            mode: 'htmlmixed',
            theme: 'dracula',
      });
      
      
      var er_codemirror_css_content = CodeMirror.fromTextArea(document.getElementById("er-scb-builder-widget-css-content"), {
            lineNumbers: true,
            mode: 'htmlmixed',
            theme: 'dracula',
      });
      
      var er_codemirror_js_content = CodeMirror.fromTextArea(document.getElementById("er-scb-builder-widget-js-content"), {
            lineNumbers: true,
            mode: 'htmlmixed',
            theme: 'dracula',
            styleActiveLine: true,
      });

      er_codemirror_js_content.setCursor({line: 1, ch: 5})

      $('.er-scb-save-widget-settings').on('click',function(){

        $(this).css({'background':'red'});
       
        $('#er_scb_builder_overlayWrapper').css({'display':'block'});

         let cdn_list_arr                       = [];
         let er_store_control_repeater_html_one = $('select#er-scb-controls-html-repeater-list-options').val();
         let er_store_control_repeater_html_two = $('select#er-scb-controls-html-repeater-list-options2').val();
         let er_store_control_enable            = $('input[name=er-scb-dep-libs]:checked').val();
         let er_store_cdn_list                  = $('input[name=er-scb-widget-cdns]:checked');
         let er_store_content_html              = er_codemirror_html_content.getValue();
         let er_store_content_loop_html         = er_codemirror_html_loop_content.getValue();
         let er_store_content_loop_html2        = er_codemirror_html_loop_content_two.getValue();
         let er_store_content_css               = er_codemirror_css_content.getValue();
         let er_store_content_js                = er_codemirror_js_content.getValue();
         let er_store_widget_slug               = $('#er-scb-widget-name').val().replace(/-/g, '_');
         let er_store_widget_title              = $('#er-scb-widget-title').val();
         let er_store_widget_keyword            = $('#er-scb-widget-keyword').val();
         let er_store_control_list              = er_controls_data.controls_list;
         
         er_scb_json_global_obj.widget_slug            = er_store_widget_slug;
         er_scb_json_global_obj.widget_name            = er_store_widget_title;
         er_scb_json_global_obj.widget_keyword         = er_store_widget_keyword;
         er_scb_json_global_obj.content_js             = er_store_content_js;
         er_scb_json_global_obj.content_css            = er_store_content_css;
         er_scb_json_global_obj.content_html           = er_store_content_html;
         er_scb_json_global_obj.content_loop_html      = er_store_content_loop_html;
         er_scb_json_global_obj.content_loop_html_two  = er_store_content_loop_html2;
         er_scb_json_global_obj.content_loop_field     = er_store_control_repeater_html_one;
         er_scb_json_global_obj.content_loop_field_two = er_store_control_repeater_html_two;
         er_scb_json_global_obj.control_list           = er_store_control_list;
         er_scb_json_global_obj.control_enable         = typeof(er_store_control_enable) == "undefined" ?'no':er_store_control_enable;
         
        
       
         $.each(er_store_cdn_list, function( index, item ) {
             cdn_list_arr.push($(item).val());
         });

         er_scb_json_global_obj.active_cdn = cdn_list_arr;
         
         jQuery.ajax({
             url: shortcode_builder_obj.ajax_url, // This is globally available, it resolves to the admin ajax url
             method: 'POST',
             headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            
             data: {
                 // The action must be the same as the name of your php class
                 action: 'element_ready_pro_scb_set_widget_settings_',
                 // For security reason, you must specify the nonce created for your php class
                 // You can get it by suffixing "Nonce" to your php class, like so
                 nonce: shortcode_builder_obj.scb_nonce,
                 // Then send whatever data you like
                 settings : er_scb_json_global_obj,
                 post_id : shortcode_builder_obj.post_id ,
             },
             success: function (response) {
             
             },
         });

         setTimeout(function(){ 

            $(this).css({'background':'#3467ff'});
            $('#er_scb_builder_overlayWrapper').css({'display':'none'});
            location.reload(true);
        }, 500);
        

       
      });
        
         function element_ready_scb_cont( er_content_control_type ){

            var text_type_control =  [ 'text', 'textarea','number','editor','url','media','date-time' ];
            var flag = false;

            text_type_control.forEach(function(item) {
               
                if( item == er_content_control_type ){

                     if(er_content_control_type == 'media'){
                       $('.er-scb-attr-control-default-value').attr('placeholder','write down image url')  
                     }
                     if(er_content_control_type == 'date-time'){
                        $('.er-scb-attr-control-default-value').attr('placeholder','write date here')  
                     }
                     
                     if(er_content_control_type == 'number'){
                        $('.er-scb-attr-control-default-value').attr('placeholder','write number')  
                     } 
                     flag = true;
                }
             
            });

            return flag;
         }

        $(document).on('click','.er-scb-controls-html-item p',function(){
            element_ready_scb_copy_option($(this).text());
        });

        $(document).on('change','#er-scb-controls-html-repeater-list-options',function(){
             
            let select_er_keys                           = $(this).val();
                er_repeater_keys.f_type                  = select_er_keys;
        
            let er_control_repeater_keys_sidebar_content = controls_repeater_sidebar_template_keys( er_repeater_keys );
            $( "#er-scb-controls-repeater-html-list-options-keys" ).html( er_control_repeater_keys_sidebar_content );
           
            er_controls_data.er_repeater_control_one = { 'title' : select_er_keys };
           
            element_ready_option_control_update();
           
        });

        // repeeater html 2
        $(document).on('change','#er-scb-controls-html-repeater-list-options2',function(){

            let select_er_keys                           = $(this).val();
                er_repeater_keys.f_type                  = select_er_keys;
            let er_control_repeater_keys_sidebar_content = controls_repeater_sidebar_template_keys2( er_repeater_keys );
            $( "#er-scb-controls-repeater-html-list-options-keys2" ).html( er_control_repeater_keys_sidebar_content );
            er_controls_data.er_repeater_control_two = {'title':select_er_keys};
            
            element_ready_option_control_update(); 
        });
      

        $('#er-scb-builder-widget-html-content').on('click',function(){
            let parentOffset = $(this).parent().offset(); 
            let er_m_left_pos = parentOffset.left;
            let er_m_top_pos = parentOffset.top;
            er_html_selected_mouse_pos_left = er_m_left_pos; 
        
        })  
  

        function element_ready_scb_cont2( er_content_control_type ){

            var text_type_control =  [ 'choose','select','select2' ];
            var flag = false;

            text_type_control.forEach(function(item) {
               
                if( item == er_content_control_type ){
                     flag = true;
                }
             
            });

            return flag;
        }

        function element_ready_scb_copy_option(text) {

            navigator.clipboard.writeText(text).then(function() {
                
              }, function(err) {
               
            });
          
        }
        element_ready_option_control_update();
        function element_ready_option_control_update(type='content'){
         
            let er_control_html_sidebar_content = controls_html_sidebar_template( er_controls_data );
            $( "#er-scb-controls-html-list-options" ).html( er_control_html_sidebar_content );
        }

        function element_ready_clear_form_control_fields(){
            $('.er-scb-attr-control-title').val('');
            $('#er-scb-attr-control-type').val('content').trigger('change');
            $('.er-scb-attr-control-css-selector-value').val('');
            $('.er-scb-attr-control-default-value').val('');

            er_choose_data.choose_items = [];
            er_choose_content = choose_template( er_choose_data );
            $( "#er-scb-builder-choose-controls-item" ).html(er_choose_content);

        }

        $('.CodeMirror.cm-s-dracula').trigger('change');
    
});