<?php
namespace Element_Ready_Pro\Widgets\image_compare;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;
use Elementor\Plugin;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Element_Ready_Image_Compare_Widget extends Widget_Base {

	public function get_name() {
		return 'Element_Ready_Image_Compare_Widget';
	}

	public function get_title() {
		return __( 'ER Image Compare', 'element-ready-pro' );
	}

	public function get_icon() {
		return 'eicon-image-rollover';
	}

	public function get_categories() {
		return array('element-ready-pro');
	}

    public function get_keywords() {
        return [ 'image', 'compare', 'image compare' ];
    }

	public function get_script_depends() {
		return[
			'event-move',
			'twentytwenty',
			'element-ready-core',
		];
	}

	public function get_style_depends() {
		return[
			'twentytwenty',
		];
	}

	public static function content_layout_style(){
		return [
			'stiky__postion__left'   => 'Button Style 1',
			'stiky__postion__right'  => 'Button Style 2',
			'stiky__postion__custom' => 'Custom Style',
		];
	}

	protected function register_controls() {

		/******************************
		 * 	CONTENT SECTION
		 ******************************/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

			$this->add_control(
				'orientation',
				[
					'label'   => __( 'Orientation', 'element-ready-pro' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'horizontal',
					'options' => [
						'vertical'   => __('vertical', 'element-ready-pro'),
						'horizontal' => __('horizontal', 'element-ready-pro'),
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'before_image',
				[
					'label'   => __( 'Before Image', 'element-ready-pro' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'separator' => 'before',
				]
			);
			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name' => 'before_image_size',
					'exclude' => [ 'custom' ],
					'default' => 'full',
				]
			);
			$this->add_control(
				'after_image',
				[
					'label'   => __( 'After Image', 'element-ready-pro' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'separator' => 'before',
				]
			);
			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name' => 'after_image_size',
					'exclude' => [ 'custom' ],
					'default' => 'full',
				]
			);
			$this->add_control(
				'before_label',
				[
					'label'         => __( 'Before Label', 'element-ready-pro' ),
					'type'          => Controls_Manager::TEXT,
					'show_external' => true,
					'default'       => 'Before',
					'placeholder'   => 'January 2017',
					'separator' => 'before',
				]
			);
			$this->add_control(
				'after_label',
				[
					'label'         => __( 'After Label', 'element-ready-pro' ),
					'type'          => Controls_Manager::TEXT,
					'show_external' => true,
					'default'       => 'After',
					'placeholder'   => 'January 2010',
					'separator' => 'before',
				]
			);
			$this->add_control(
				'no_overlay',
				[
					'label'        => __( 'No Overlay', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'no',
					'separator' => 'before',
				]
			);
			$this->add_control(
				'move_slider_on_hover',
				[
					'label'        => __( 'Move Slider On Hover', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'no',
					'separator' => 'before',
				]
			);
			$this->add_control(
				'move_with_handle_only',
				[
					'label'        => __( 'Move With Handle Only', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'separator' => 'before',
				]
			);
			$this->add_control(
				'click_to_move',
				[
					'label'        => __( 'Click To Move', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'no',
					'separator'    => 'before',
				]
			);
			$this->add_control(
				'default_offset_pct',
				[
					'label'      => __( 'Image Offset', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1,
							'step' => 0.01,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0.5,
					],
					'separator' => 'before',
				]
			);
		$this->end_controls_section();
		/*******************************
		 * 	CONTENT SECTION END
		 *******************************/

		/*----------------------------
			BEFORE LABEL TITLE
		-----------------------------*/
		$this->start_controls_section(
			'label_button_style_section',
			[
				'label'     => __( 'Label Button', 'element-ready-pro' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'no_overlay!' => 'yes',
				],
			]
		);
			// Typgraphy
			$this->add_group_control(
				Group_Control_Typography:: get_type(),
				[
					'name'     => 'label_button_typography',
					'selector' => '{{WRAPPER}} .twentytwenty-before-label:before,{{WRAPPER}} .twentytwenty-after-label:before',
				]
			);

			// Icon Color
			$this->add_control(
				'label_button_color',
				[
					'label'     => __( 'Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .twentytwenty-before-label:before' => 'color: {{VALUE}};',
						'{{WRAPPER}} .twentytwenty-after-label:before' => 'color: {{VALUE}};',
					],
				]
			);

			// Background
			$this->add_group_control(
				Group_Control_Background:: get_type(),
				[
					'name'     => 'label_button_background',
					'label'    => __( 'Background', 'element-ready-pro' ),
					'types'    => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .twentytwenty-before-label:before,{{WRAPPER}} .twentytwenty-after-label:before',
				]
			);

			// Border
			$this->add_group_control(
				Group_Control_Border:: get_type(),
				[
					'name'      => 'label_button_border',
					'label'     => __( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .twentytwenty-before-label:before,{{WRAPPER}} .twentytwenty-after-label:before',
					'separator' => 'before',
				]
			);

			// Radius
			$this->add_responsive_control(
				'label_button_radius',
				[
					'label'      => __( 'Border Radius', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .twentytwenty-before-label:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} .twentytwenty-after-label:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			
			// Shadow
			$this->add_group_control(
				Group_Control_Box_Shadow:: get_type(),
				[
					'name'     => 'label_button_shadow',
					'selector' => '{{WRAPPER}} .twentytwenty-before-label:before,{{WRAPPER}} .twentytwenty-after-label:before',
				]
			);

			// Width
			$this->add_responsive_control(
				'label_button_width',
				[
					'label'      => __( 'Width', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .twentytwenty-before-label:before' => 'width: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .twentytwenty-after-label:before' => 'width: {{SIZE}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			// Height
			$this->add_responsive_control(
				'label_button_height',
				[
					'label'      => __( 'Height', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .twentytwenty-before-label:before' => 'height: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .twentytwenty-after-label:before' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			// Margin
			$this->add_responsive_control(
				'label_button_margin',
				[
					'label'      => __( 'Before Button Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .twentytwenty-before-label:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			// Margin
			$this->add_responsive_control(
				'after_label_button_margin',
				[
					'label'      => __( 'After Button Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .twentytwenty-after-label:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			// Padding
			$this->add_responsive_control(
				'label_button_padding',
				[
					'label'      => __( 'Padding', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .twentytwenty-before-label:before' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} .twentytwenty-after-label:before' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		/*----------------------------
			BEFORE LABEL TITLE END
		-----------------------------*/

		/*----------------------------
			BEFORE LABEL TITLE
		-----------------------------*/
		$this->start_controls_section(
			'overlay_handaler_style_section',
			[
				'label'     => __( 'Overlay & Handaler', 'element-ready-pro' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'no_overlay!' => 'yes',
				],
			]
		);		
			$this->add_control(
				'overlay_handaler_color',
				[
					'label'     => __( 'Bar Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .twentytwenty-handle:before' => 'background: {{VALUE}};',
						'{{WRAPPER}} .twentytwenty-handle:after' => 'background: {{VALUE}};',
					],
				]
			);		
			$this->add_control(
				'overlay_handaler_arrow_color',
				[
					'label'     => __( 'Arrow Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .twentytwenty-handle .twentytwenty-left-arrow' => 'border-right-color: {{VALUE}};',
						'{{WRAPPER}} .twentytwenty-handle .twentytwenty-right-arrow' => 'border-left-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Background:: get_type(),
				[
					'name'     => 'overlay_handaler_background',
					'label'    => __( 'Background', 'element-ready-pro' ),
					'types'    => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .twentytwenty-handle,{{WRAPPER}}',
				]
			);
			$this->add_group_control(
				Group_Control_Border:: get_type(),
				[
					'name'      => 'overlay_handaler_border',
					'label'     => __( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .twentytwenty-handle',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'overlay_handaler_radius',
				[
					'label'      => __( 'Border Radius', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .twentytwenty-handle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Box_Shadow:: get_type(),
				[
					'name'     => 'overlay_handaler_shadow',
					'selector' => '{{WRAPPER}} .twentytwenty-handle',
				]
			);
			$this->add_responsive_control(
				'overlay_handaler_width',
				[
					'label'      => __( 'Width', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .twentytwenty-handle' => 'width: {{SIZE}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			// Height
			$this->add_responsive_control(
				'overlay_handaler_height',
				[
					'label'      => __( 'Height', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .twentytwenty-handle' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			// Margin
			$this->add_responsive_control(
				'overlay_handaler_margin',
				[
					'label'      => __( 'Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .twentytwenty-handle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			// Padding
			$this->add_responsive_control(
				'overlay_handaler_padding',
				[
					'label'      => __( 'Padding', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .twentytwenty-handle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		/*----------------------------
			BEFORE LABEL TITLE END
		-----------------------------*/

	}
	
	protected function render() {

		$settings  = $this->get_settings_for_display();
		$random_id = $this->get_id();

		$options = array(
			'default_offset_pct'    => $settings['default_offset_pct']['size'] ? $settings['default_offset_pct']['size'] : 0.5,
			'orientation'           => $settings['orientation'] ? $settings['orientation'] : 'horizontal',
			'before_label'          => $settings['before_label'] ? $settings['before_label'] : 'before',
			'after_label'           => $settings['after_label'] ? $settings['after_label'] : 'after',
			'no_overlay'            => ( 'yes' === $settings['no_overlay'] ) ? true : false,
			'move_slider_on_hover'  => ( 'yes' === $settings['move_slider_on_hover'] ) ? true : false,
			'move_with_handle_only' => ( 'yes' === $settings['move_with_handle_only'] ) ? true : false,
			'click_to_move'         => ( 'yes' === $settings['click_to_move'] ) ? true : false,
		);
		$this->add_render_attribute( 'image_compare_wrap_attr', 'data-options', json_encode( $options ) );
		$this->add_render_attribute( 'image_compare_wrap_attr', 'class', 'element__ready__image__compare__wrap' );
		$this->add_render_attribute( 'image_compare_wrap_attr', 'class', 'twentytwenty-container' );
		$this->add_render_attribute( 'image_compare_wrap_attr', 'id', 'element__ready__image__compare__'.$random_id  );

		?>
			<div <?php echo $this->get_render_attribute_string( 'image_compare_wrap_attr' ); ?>>
				<div class="before__image"><?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'before_image_size', 'before_image' ); ?></div>
				<div class="after__image"><?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'after_image_size', 'after_image' ); ?></div>
			</div>
		<?php
	}
}