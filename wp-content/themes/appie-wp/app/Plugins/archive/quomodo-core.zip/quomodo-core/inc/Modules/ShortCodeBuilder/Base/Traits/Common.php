<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits;

if ( ! defined( 'ABSPATH' ) ) exit;

trait Common
{
    public function get_posts(){
        
       
        $erp_scb_builder = get_posts( array(
            'posts_per_page' => -1,
            'orderby'        => 'rand',
            'post_type'      => 'erp_scb_builder',
            'post_status'    => 'publish'
       ) );

       foreach($erp_scb_builder as $item){

           $widget_settings = [];
           $widget_settings['id']            = $item->ID;
           $widget_settings['title']         = $item->post_title;
           $widget_settings['slug']         = $item->post_name;
           $widget_settings['desc']          = $item->post_content;
           $widget_settings['settings']      = get_post_meta($item->ID,ELEMENT_READY_PRO_BUILDER_WIDGET_KEY,true);
           $this->widget_list[] = $widget_settings;

       }
     
       return $this->widget_list;
       
    }

    public function get_post($id){
        $item = get_post($id);
        $widget_settings = [];
        $widget_settings['id']            = $item->ID;
        $widget_settings['title']         = $item->post_title;
        $widget_settings['slug']         = $item->post_name;
        $widget_settings['desc']          = $item->post_content;
        $widget_settings['settings']      = get_post_meta($item->ID,ELEMENT_READY_PRO_BUILDER_WIDGET_KEY,true);
        
        return $widget_settings;
    }
}