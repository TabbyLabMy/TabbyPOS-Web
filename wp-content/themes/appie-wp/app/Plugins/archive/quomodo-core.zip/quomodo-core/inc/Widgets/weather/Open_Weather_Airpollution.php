<?php
namespace Element_Ready_Pro\Widgets\weather;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Border;
use Element_Ready\Api\Open_Weather_Api as Weather_Api;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

class Open_Weather_Airpollution extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public $base;

    public function get_name() {
        return 'element-ready-open-weather-airpollution';
    }

    public function get_title() {
        return esc_html__( 'ER Airpollution', 'element-ready-pro' );
    }

    public function get_icon() { 
        return "eicon-google-maps";
    }

   public function get_categories() {
      return [ 'element-ready-pro' ];
   }

   
   public function get_style_depends() {

    wp_register_style( 'eready-weather' , ELEMENT_READY_ROOT_CSS. 'widgets/weather.css' );
    return [ 'eready-weather' ];
  }

    protected function register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'element-ready-pro'),
            ]
        );

        $this->add_control(
			'layout',
			[
				'label' => esc_html__( 'Style', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'element-ready-pro' ),
					'style2' => esc_html__( 'Style 2', 'element-ready-pro' ),
				
				],
			]
		);

       $this->end_controls_section();
       
        $this->content_text([
            'title' => esc_html__('Settings','element-ready-pro'),
            'slug' => '_heading_content',
            'condition' => '',
            'controls' => [
                
                'coordinates_lat'=> [
                    'label'   => esc_html__( 'Coordinates latitude', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                   
                ], 
                
                'coordinates_lon'=> [
                    'label'   => esc_html__( 'coordinates Longitude', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                    
                ],
                  
                 'weather_cache_enable'=> [
                    'label'        => __( 'Cach ?', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => __( 'Show', 'element-ready-pro' ),
                    'label_off'    => __( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => '',
                 ],

         
            ]
         ]);

         $components = [
            'co'    => 'Carbon monoxide',
            'no'    => 'Nitrogen monoxide',
            'no2'   => 'Nitrogen dioxide',
            'o3'    => 'Ozone',
            'so2'   => 'Sulfur dioxide',
            'pm2_5' => 'Fine particles matter',
            'pm10'  => 'Coarse particulate matter',
            'nh3'   => 'Ammonia',
         ];
         $_comp = [];
         foreach($components as $key=> $comp){

            $_comp[$key] = [
                'label'        => $comp,
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ];


            $_comp[$key.'_text'] = [
                'label'   => esc_html__('Lebel','element-ready-pro'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => $comp,
                'condition' => [
                    $key => ['yes']
                ]
            ];

         }

         $_comp['show_date'] = [
            'label'        => esc_html__('Show Date','element-ready-pro'),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
            'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ];
        $_comp['default_date'] = [
            'label'        => esc_html__('Default Date Format','element-ready-pro'),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
            'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
            'return_value' => 'yes',
            'default'      => 'yes',
            'condition' => [
                'show_date' => ['yes']
            ]
        ];

         $_comp['date_format'] = [
            'label'   => esc_html__('Date Format','element-ready-pro'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'D m',
            'condition' => [
                'default_date!' => ['yes']
            ]
            
        ];
      
         $this->content_text([
            'title' => esc_html__('Content Settings','element-ready-pro'),
            'slug' => '_content',
            'condition' => '',
            'controls' => $_comp
         ]);

         $this->text_wrapper_css(
            array(
                'title' => esc_html__('Heading Date','element-ready-pro'),
                'slug' => 'heading_date_select_style',
                'element_name' => 'heading_date_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-air-pollution-date',
                'hover_selector' => false,
               
            )
        );

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Title - Even','element-ready-pro'),
                'slug' => 'post_select_style',
                'element_name' => 'post_select_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .item:nth-child(even) .title',
                'hover_selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .item:nth-child(even) .title:hover',
               
            )
        );

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Title - Odd','element-ready-pro'),
                'slug' => 'post_odd_select_style',
                'element_name' => 'post_odd_select_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .item:nth-child(odd) .title',
                'hover_selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .item:nth-child(odd) .title:hover',
               
            )
        );

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Number - even','element-ready-pro'),
                'slug' => 'post_number_style',
                'element_name' => 'post_number_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .item:nth-child(even) .content-value',
                'hover_selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .item:nth-child(even) .content-value:hover',
               
            )
        );

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Number - odd','element-ready-pro'),
                'slug' => 'post_odd_number_style',
                'element_name' => 'post_odd_number_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .item:nth-child(odd) .content-value',
                'hover_selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .item:nth-child(odd) .content-value:hover',
               
            )
        );

        $this->box_css(
            array(
                'title' => esc_html__('Item - Even','element-ready-pro'),
                'slug' => 'wrapper_item_box_style',
                'element_name' => 'wrapper_item_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .components .item:nth-child(even)',
               
               
            )
        );

        $this->box_css(
            array(
                'title' => esc_html__('Item - odd','element-ready-pro'),
                'slug' => 'wrapper_odd_item_box_style',
                'element_name' => 'wrapper_odd_item_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper .components .item:nth-child(odd)',
               
               
            )
        );
        
        $this->box_css(
            array(
                'title' => esc_html__('Main Wrapper','element-ready-pro'),
                'slug' => 'wrapper_body_box_style',
                'element_name' => 'wrapper_body_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-airpollution-wrapper',
               
               
            )
        );
       
    }


    protected function render( ) { 
      
        $settings = $this->get_settings();
        $api_key = element_ready_get_api_option( 'weather_api_key' );
        
        $options = [

           'api_key'              => $api_key,
           'coordinates_lat'      => $settings['coordinates_lat'],
           'coordinates_lon'      => $settings['coordinates_lon'],
           'weather_cache_enable' => $settings['weather_cache_enable'],
       
        ];
        
        $components = [
           'co'    => 'Carbon monoxide',
           'no'    => 'Nitrogen monoxide',
           'no2'   => 'Nitrogen dioxide',
           'o3'    => 'Ozone',
           'so2'   => 'Sulfur dioxide',
           'pm2_5' => 'Fine particles matter',
           'pm10'  => 'Coarse particulate matter',
           'nh3'   => 'Ammonia',
        ];
     
        $data = Weather_Api::airpollution($options);   
       
        if( !isset( $data->list[0]->components) ) {
           return;
        }

        $data_list = $data->list[0]->components;
        $_date = isset($data->list[0]->dt)?$data->list[0]->dt:'';
        $date_format = $settings['default_date'] =='yes'? get_option( 'date_format' ): $settings['date_format']; 
     ?>
       <?php if($settings['layout'] == 'style1'): ?>
        <div class="element-ready-airpollution-wrapper style1"> 
            <?php if($settings['show_date'] =='yes'): ?>
                <h3 class="element-ready-air-pollution-date"> 
                    <?php echo date($date_format,$_date); ?> 
                </h4>
             <?php endif; ?>
            <div class="components"> 
                <?php foreach($data_list as $key=> $item): ?>
                    <?php if($settings[$key] == 'yes'): ?>
                        <div class="item">
                            <h4 class="title"> 
                                <?php echo isset($settings[$key.'_text']) && $settings[$key.'_text'] !=''?$settings[$key.'_text']:$key; ?>
                             </h4>
                            <span class="content-value"> <?php echo esc_html($item); ?> </span>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>    
        </div>
      <?php endif; ?>
      <?php if($settings['layout'] == 'style2'): ?>
        <div class="element-ready-airpollution-wrapper style2"> 
            <?php if($settings['show_date'] =='yes'): ?>
                <h3 class="element-ready-air-pollution-date"> 
                    <?php echo date($date_format,$_date); ?> 
                </h4>
             <?php endif; ?>
            <div class="components"> 
                <?php foreach($data_list as $key=> $item): ?>
                    <?php if($settings[$key] == 'yes'): ?>
                        <div class="item">
                            <h4 class="title"> 
                                <?php echo isset($settings[$key.'_text']) && $settings[$key.'_text'] !=''?$settings[$key.'_text']:$key; ?>
                             </h4>
                            <span class="content-value"> <?php echo esc_html($item); ?> </span>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>    
        </div>
      <?php endif; ?>
      <?php  
    }
    

    
}