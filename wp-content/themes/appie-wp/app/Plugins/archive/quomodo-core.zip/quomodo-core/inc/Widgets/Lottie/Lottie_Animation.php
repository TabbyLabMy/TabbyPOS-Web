<?php
namespace Element_Ready_Pro\Widgets\Lottie;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Element_Ready\Controls\Custom_Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;
use Elementor\Plugin;



class Lottie_Animation extends Widget_Base {

	public function get_name() {
		return 'Element_Ready_Lottie_Animation';
	}

	public function get_title() {
		return esc_html__( 'ER Lottie Animation', 'element-ready-pro' );
	}

	public function get_icon() {
		return 'eicon-barcode';
	}

	public function get_categories() {
		return [ 'element-ready-pro' ];
	}

	public function get_keywords() {
		return [ 'Lottie', 'gif', 'file','Animation' ];
	}

    public function get_script_depends() {

        return ['lottie-player','lottie-interactivity'];
   }
  
	protected function register_controls() {

		$this->start_controls_section(
			'section_animation',
			[
				'label' => __( 'Settings', 'element-ready-pro' ),
			]
        );

        $this->add_control(
			'file_link',
			[
				'label' => esc_html__( 'Select File', 'element-ready-pro' ),
				'type'	=> Custom_Controls_Manager::MEDIAFILE,
			]
        );

        $this->add_control(
			'important_note',
			[
				'label' => __( 'Help:', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw' => __( 'Go to <a target="_blank" href="https://lottiefiles.com/44373-girl-cycling"> Lottie Site</a> and copy json file and paste above', 'element-ready-pro' ),
				
			]
		);

        $this->add_control(
			'control',
			[
				'label' => __( 'Controls', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'element-ready-pro' ),
				'label_off' => __( 'Hide', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
        );
        
        $this->add_control(
			'loop',
			[
				'label' => __( 'Enable Loop', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'element-ready-pro' ),
				'label_off' => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );
        
        $this->add_control(
			'autoplay',
			[
				'label' => __( 'Enable Autoplay', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'element-ready-pro' ),
				'label_off' => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );
        
        
        $this->add_control(
            'speed',
            [
                'label' => __( 'Speed', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => 1,
            ]
        );

        $this->add_control(
			'height',
			[
				'label' => __( 'Height', 'element-ready-pro' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 2600,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 300,
				],
				
			]
		);

        $this->add_control(
			'width',
			[
				'label' => __( 'Width', 'element-ready-pro' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 2600,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 300,
				],
				
			]
		);


        
        $this->add_control(
			'bg_color',
			[
				'label' => esc_html__( 'Background', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::COLOR,
			]
		);
     
		$this->end_controls_section();
	}

	protected function render() {

		$settings  = $this->get_settings_for_display();
		$random_id = $this->get_id();
		$bg_color  = $settings['bg_color'];
		$width     = $settings['width'];
		$height    = $settings['height'];
		$width     = $width['size'].$width['unit'];
		$height    = $height['size'].$height['unit'];
        
       ?>
      
        <lottie-player src="<?php echo esc_url($settings['file_link']); ?>" background="<?php echo esc_attr($bg_color); ?>"  speed="<?php echo esc_attr($settings['speed']); ?>"  style="width: <?php echo esc_attr($width); ?>; height: <?php echo esc_attr($height); ?>;" <?php echo esc_attr($settings['loop']=='yes'?'loop':'');?> <?php echo esc_attr($settings['autoplay']=='yes'?'autoplay':'');?>  <?php echo esc_attr($settings['control']=='yes'?'controls':''); ?>>
        </lottie-player>
       
       <?php 
	}
}



