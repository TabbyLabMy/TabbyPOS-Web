<?php
namespace Element_Ready_Pro\Widgets\edd;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( !class_exists('Easy_Digital_Downloads') ) {
    return;
}

class Element_Ready_EDD_Discount_Product_Widget extends Widget_Base {

    public function get_name() {
        return 'Element_Ready_EDD_Discount_Product_Widget';
    }
    
    public function get_title() {
        return __( 'ER Edd Discount Product', 'element-ready-pro' );
    }

    public function get_icon() {
        return 'eicon-file-download';
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

	public function get_keywords() {
        return [ 'EDD', 'Edd Discount', 'Discount', 'Discount List', 'Easy Digital Download' ];
    }

    static function content_layout_style(){
        return[
            '1'      => __( 'Layout One', 'element-ready-pro' ),
            'custom' => __( 'Custom Layout', 'element-ready-pro' ),
        ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'datatable_layout',
            [
                'label' => __( 'Table Layout', 'element-ready-pro' ),
            ]
        );

            $this->add_control(
                'edd_table_style',
                [
                    'label'   => __( 'Layout', 'element-ready-pro' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => '1',
                    'options' => $this::content_layout_style(),
                ]
            );
        $this->end_controls_section();

        // TABLE STYLE
        $this->start_controls_section(
            '_table_style_section',
            [
                'label' => __( 'Table', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'table_background',
                    'label' => __( 'Background', 'element-ready-pro' ),
                    'types' => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} #element__ready__edd__table__wrap table',
                ]
            );

            $this->add_group_control(
                Group_Control_Border:: get_type(),
                    [
                        'name'     => 'table_border',
                        'label'    => esc_html__( 'Border', 'element-ready-pro' ),
                        'selector' => '{{WRAPPER}} #element__ready__edd__table__wrap table',
                        'separator' => 'before',
                    ]
            );

            $this->add_responsive_control(
                'table_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap table' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'table_padding',
                [
                    'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors'  => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap table' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'table_margin',
                [
                    'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors'  => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap table' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
        $this->end_controls_section();

        // Table Header Style tab section
        $this->start_controls_section(
            '_table_header_style_section',
            [
                'label' => __( 'Table Header', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'table_header_text_color',
                [
                    'label'     => esc_html__( 'Color', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap thead tr th' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'table_header_typography',
                    'label'    => __( 'Typography', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} #element__ready__edd__table__wrap thead tr th',
                ]
            );
            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'table_header_bg_color',
                    'label' => __( 'Background', 'element-ready-pro' ),
                    'types' => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} #element__ready__edd__table__wrap thead tr th',
                ]
            );

            $this->add_group_control(
                Group_Control_Border:: get_type(),
                    [
                        'name'     => 'table_header_border',
                        'label'    => esc_html__( 'Border', 'element-ready-pro' ),
                        'selector' => '{{WRAPPER}} #element__ready__edd__table__wrap thead tr th',
                        'separator' => 'before',
                    ]
            );
            $this->add_responsive_control(
                'table_header_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap thead tr th' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );
            $this->add_responsive_control(
                'table_header_align',
                [
                    'label'   => __( 'Alignment', 'element-ready-pro' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-right',
                        ],
                        'justify' => [
                            'title' => __( 'Justified', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-justify',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap thead tr th' => 'text-align: {{VALUE}};',
                    ],
                    'default'   => '',
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'table_header_padding',
                [
                    'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors'  => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap thead tr th' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
        $this->end_controls_section();

        // Table Body Style tab section
        $this->start_controls_section(
            '_table_body_style_section',
            [
                'label' => __( 'Table Data', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'table_body_text_color',
                [
                    'label'     => esc_html__( 'Text Color', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr td' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'table_body_typography',
                    'label'    => __( 'Typography', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr td',
                ]
            );
            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'table_header_data_bg',
                    'label' => __( 'Background', 'element-ready-pro' ),
                    'types' => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'table_body_bg_color',
                [
                    'label'     => esc_html__( 'Background Color ( Event )', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr:nth-child(even)' => 'background-color: {{VALUE}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'table_body_odd_bg_color',
                [
                    'label'     => esc_html__( 'Background Color ( Odd )', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr' => 'background-color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Border:: get_type(),
                [
                    'name'     => 'datatable_body_border',
                    'label'    => esc_html__( 'Border', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr td',
                ]
            );
            $this->add_responsive_control(
                'datatable_body_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr td' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'datatable_body_align',
                [
                    'label'   => __( 'Alignment', 'element-ready-pro' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-right',
                        ],
                        'justify' => [
                            'title' => __( 'Justified', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-justify',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr td' => 'text-align: {{VALUE}};',
                    ],
                    'default'   => '',
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'table_body_padding',
                [
                    'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors'  => [
                        '{{WRAPPER}} #element__ready__edd__table__wrap tbody tr td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
        $this->end_controls_section();
    }

    protected function render( $instance = [] ) {

        $settings = $this->get_settings_for_display();
        $id       = $this->get_id();
        $this->add_render_attribute( 'edd_content_wrap_attr', 'id', 'element__ready__edd__table__wrap' );
        $this->add_render_attribute( 'edd_content_wrap_attr', 'class', 'element__ready__edd__table__wrap element__ready__edd__table__wrap__style__'.$settings['edd_table_style'] );
        ?>
        <div <?php echo $this->get_render_attribute_string( 'edd_content_wrap_attr' ); ?>>
            <?php echo do_shortcode(' [download_discounts]' ); ?>
        </div>
        <?php
    }
}