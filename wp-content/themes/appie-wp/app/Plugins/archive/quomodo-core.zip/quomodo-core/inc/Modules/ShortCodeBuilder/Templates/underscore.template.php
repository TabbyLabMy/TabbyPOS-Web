


<script type="text/html" id="tmpl-er-scb-dynamic-cdn-includes">
   
   <# _.each( data.listItems, function( item, key ){ #>

      <div class="er-libs-scb-item">  
           <# if(_.contains(data.active_cdn, item.name)){ #>
            <input type="checkbox" name="er-scb-widget-cdns" checked value="{{ item.name }}"/>
            <# }else{ #>
               <input type="checkbox" name="er-scb-widget-cdns" value="{{ item.name }}"/>
           <# } #>
         
         <label for="{{ item.name }}"> {{ item.name }} </label>
         <span data-id="{{ key }}" class="dashicons dashicons-table-col-delete er-scb-remove"></span>
      </div>
   <# }) #>
</script>

<script type="text/html" id="tmpl-er-scb-builder-choose-controls-container">

   <# _.each( data.choose_items, function( item, key ){ #>
      <div class="er-libs-scb-item er-scb-builder-arguments-list">  
         <input class="er-scb-builder-arguments-input" name="er-scb-builder-argument-single" type="text" value="{{ item.value }}"/>
         <span data-id="{{ key }}" class="dashicons dashicons-table-col-delete er-scb-choose-option-remove"></span>
      </div>
   <# }) #>
</script>

<script type="text/html" id="tmpl-er-scb-builder-repeater-controls-container">

   <# _.each( data.repeater_items, function( item, key ){ #>

      <div class="er-libs-scb-item er-scb-builder-arguments-list">  
      <input readonly placeholder="Title here" class="er-scb-builder-repeater-arguments-title" name="er-scb-builder-repeater-argument-repeater-value" type="text" value="{{ item.title }}"/>
      <input readonly placeholder="Default Value" class="er-scb-builder-repeater-value-input" name="er-scb-builder-repeater-argument-repeater-title" type="text" value="{{ item.default }}"/>
      <span data-id="{{ key }}" class="dashicons dashicons-table-col-delete er-scb-repeater-option-remove"></span>
      </div>

   <# }) #>

</script>

<script type="text/html" id="tmpl-er-scb-builder-controls-data-table-lists">
  
   <table class="er-scb-item-controls-table">
         <tr>
               <th>Title</th>
               <th>Name</th>
               <th>Field Type</th>
               <th>Panel </th>
               <th>Options </th>
               <th>Actions</th>
         </tr>
         <# _.each( data.controls_list, function( item, key ){ #>
         <tr>
               <td> {{ item.control_Title }} </td>
               <td> {{ item.control_name }} </td>
               <td> {{ item.control_f_type }} </td>
               <td> {{ item.control_type }} </td>
               <td> {{ JSON.stringify(item.control_args) }} </td>
               <td class="er-control-scb-table-action">
                  <a data-id="{{ key }}" class="element-ready-scb-add-new er-remove-list-control"> Delete </a>
                  <a data-id="{{ item.id }}" class="er-edit-list-control element-ready-scb-add-new">Edit</a>
               </td>
         </tr>
         <# }) #>
       
   </table>  
</script>

<script type="text/html" id="tmpl-er-scb-builder-html-controls-lists-sidebar">
        
         <# _.each( data.controls_list, function( item, key ){ #>
            <# if(item.control_type == 'content' && !_.contains(['select2','select','post','social-repeater'],item.control_f_type)){ #>
               <div class="er-scb-controls-html-item" >
                  <p> {% {{ item.control_Title.replace(/\s+/g, '_').toLowerCase() }} %} </p>
               </div>
            <# } #>
          <# }) #>
         <# if(data.er_repeater_control_one){ #>
            <div class="er-scb-controls-html-item" >
               <p> {% {{ data.er_repeater_control_one.title.toLowerCase() }} %} </p>
            </div>
         <# } #>
         <# if(data.er_repeater_control_two){ #>
            <div class="er-scb-controls-html-item" >
               <p> {% {{ data.er_repeater_control_two.title.toLowerCase() }} %} </p>
            </div>
         <# } #>
       
  
</script>

<script type="text/html" id="tmpl-er-scb-builder-html-item-controls-lists-sidebar">
        
         <# _.each( data.controls_list, function( item, key ){ #>
            
            <# if( item.control_type == 'content' && _.contains(['select2','select','post','social-repeater','repeater'],item.control_f_type) ){ #>

                  <# if( item.control_f_type == 'post' ){ #>
                     <option value="{{ item.control_f_type }}" class="er-scb-controls-html-option" >
                     
                        {% {{ item.control_f_type }} %}
                     
                     </option>
                  <# }else if( item.control_f_type == 'repeater' ){ #>  
                     <option value="{{ item.control_name }}" class="er-scb-controls-html-option" >
                        
                     {% {{ item.control_name.replace(/\s+/g, '_').toLowerCase() }} %}
                     
                     </option>
                 <# }else{ #>
                
                  <option value="{{ item.control_Title.replace(/\s+/g, '_').toLowerCase() }}" class="er-scb-controls-html-option" >
                     {% {{ item.control_Title.replace(/\s+/g, '_').toLowerCase() }} %}
                  </option>
                 <# } #>

            <# } #>
          <# }) #>
  
</script>

<script type="text/html" id="tmpl-er-scb-builder-html-controls-lists-sidebar-keys">
        
        
         <# if(data.f_type == 'general'){ #>

            <# _.each( data.general, function( item, key ){ #>
               <div class="er-scb-controls-html-item" >
                  <p> {% {{ item }} %} </p>
               </div>
            <# }) #>

          <# }else if(data.f_type == 'post'){ #>

               <# _.each( data.post, function( item, key ){ #>
                  <div class="er-scb-controls-html-item" >
                     <p> {% {{ data.f_type }}.{{ item }} %} </p>
                  </div>
               <# }) #>
          
          <# }else{ #> 
          
            <# var find_item = _.findWhere(data.control_list, { control_name:data.f_type });  #>
           
            <# if( _.isObject(find_item) && find_item.control_f_type == 'social-repeater' ){ #>
                  
                  <# _.each( data.socialrepeater, function( item, key ){ #>
                     <div class="er-scb-controls-html-item" >
                        <p> {% {{ data.f_type }}.{{ item }} %} </p>
                     </div>
                  <# }) #>
           <# }else if( _.isObject(find_item) && find_item.control_f_type == 'repeater' ){ #>

            <# var er_keys_item = data.repeater[find_item.control_name];  #>

                 <# _.each( er_keys_item, function( item, key ){ #>
                     <div class="er-scb-controls-html-item" >
                        <p> {% {{ find_item.control_name }}.{{  item.name }} %} </p>
                     </div>
                  <# }) #>

            <# }else{ #> 

                  <# _.each( data.general, function( item, key ){ #>
                     <div class="er-scb-controls-html-item" >
                        <p> {% {{ data.f_type }}.{{  item }} %} </p>
                     </div>
                  <# }) #>

            <# } #> 

          <# } #> 
  
</script>

<script type="text/html" id="tmpl-er-scb-builder-html-item-controls-lists-sidebar2">
        
        <# _.each( data.controls_list, function( item, key ){ #>
            
            <# if( item.control_type == 'content' && _.contains(['select2','select','post','social-repeater','repeater'],item.control_f_type) ){ #>

                  <# if( item.control_f_type == 'post' ){ #>
                     <option value="{{ item.control_f_type }}" class="er-scb-controls-html-option" >
                     
                        {% {{ item.control_f_type }} %}
                     
                     </option>
                  <# }else if( item.control_f_type == 'repeater' ){ #>  
                     <option value="{{ item.control_name }}" class="er-scb-controls-html-option" >
                        
                     {% {{ item.control_name.replace(/\s+/g, '_').toLowerCase() }} %}
                     
                     </option>
                 <# }else{ #>
                
                  <option value="{{ item.control_Title.replace(/\s+/g, '_').toLowerCase() }}" class="er-scb-controls-html-option" >
                     {% {{ item.control_Title.replace(/\s+/g, '_').toLowerCase() }} %}
                  </option>
                 <# } #>

            <# } #>
          <# }) #>
  
</script>

<script type="text/html" id="tmpl-er-scb-builder-html-controls-lists-sidebar-keys2">
        
         <# if(data.f_type == 'general'){ #>

         <# _.each( data.general, function( item, key ){ #>
            <div class="er-scb-controls-html-item" >
               <p> {% {{ item }} %} </p>
            </div>
         <# }) #>

         <# }else if(data.f_type == 'post'){ #>

            <# _.each( data.post, function( item, key ){ #>
               <div class="er-scb-controls-html-item" >
                  <p> {% {{ data.f_type }}.{{ item }} %} </p>
               </div>
            <# }) #>

         <# }else{ #> 

         <# var find_item = _.findWhere(data.control_list, { control_name:data.f_type });  #>

         <# if( _.isObject(find_item) && find_item.control_f_type == 'social-repeater' ){ #>
               
               <# _.each( data.socialrepeater, function( item, key ){ #>
                  <div class="er-scb-controls-html-item" >
                     <p> {% {{ data.f_type }}.{{ item }} %} </p>
                  </div>
               <# }) #>
         <# }else if( _.isObject(find_item) && find_item.control_f_type == 'repeater' ){ #>

         <# var er_keys_item = data.repeater[find_item.control_name];  #>

            <# _.each( er_keys_item, function( item, key ){ #>
                  <div class="er-scb-controls-html-item" >
                     <p> {% {{ find_item.control_name }}.{{  item.name }} %} </p>
                  </div>
               <# }) #>

         <# }else{ #> 

               <# _.each( data.general, function( item, key ){ #>
                  <div class="er-scb-controls-html-item" >
                     <p> {% {{ data.f_type }}.{{  item }} %} </p>
                  </div>
               <# }) #>

         <# } #> 

         <# } #> 
  
</script>

