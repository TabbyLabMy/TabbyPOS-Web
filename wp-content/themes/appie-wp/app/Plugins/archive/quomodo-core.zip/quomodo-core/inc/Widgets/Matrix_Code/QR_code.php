<?php
namespace Element_Ready_Pro\Widgets\Matrix_Code;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;
use Elementor\Plugin;
use Elementor\Repeater;
use Element_Ready_Pro\Base\Matrix\QRCode;

class QR_code extends Widget_Base {

	public function get_name() {
		return 'Element_Ready_Matrix_QR_Code_';
	}

	public function get_title() {
		return __( 'ER QR Code', 'element-ready-pro' );
	}

	public function get_icon() {
		return 'eicon-barcode';
	}

	public function get_categories() {
		return [ 'element-ready-pro' ];
	}

	public function get_keywords() {
		return [ 'qrcode', 'qr', 'qr-code', 'matrix','barcode' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_map',
			[
				'label' => __( 'Settings', 'element-ready-pro' ),
			]
        );

            $this->add_control(
                'source',
                [
                    'label' => __( 'Source', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => false,
                    'options' => [
                        'google' => __( 'Google', 'element-ready-pro' ),
                        'qrserver' => __( 'goqr.me', 'element-ready-pro' ),
           
                    ],
                    'default' =>  'google'
                ]
            );
        
            $this->add_control(
                'encoding',
                [
                    'label' => __( 'Encoding', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => false,
                    'options' => [
                        'Shift_JIS' => __( 'Shift JIS', 'element-ready-pro' ),
                        'UTF-8' => __( 'UTF-8', 'element-ready-pro' ),
                        'ISO-8859-1'  => __( 'ISO-8859-1', 'element-ready-pro' ),
                        'ISO-8859-2' => __( 'ISO-8859-2', 'element-ready-pro' ),
                        'ISO-8859-3' => __( 'ISO-8859-3', 'element-ready-pro' ),
                        'ISO-8859-4' => __( 'IISO-8859-4', 'element-ready-pro' ),
                        'ISO-8859-5' => __( 'IISO-8859-5', 'element-ready-pro' ),
                        'ISO-8859-6' => __( 'IISO-8859-6', 'element-ready-pro' ),
                        'ISO-8859-7' => __( 'IISO-8859-7', 'element-ready-pro' ),
                        'ISO-8859-8' => __( 'IISO-8859-8', 'element-ready-pro' ),
                        'ISO-8859-9' => __( 'IISO-8859-9', 'element-ready-pro' ),
                        'ISO-8859-10' => __( 'IISO-8859-10', 'element-ready-pro' ),
                        'ISO-8859-11' => __( 'IISO-8859-11', 'element-ready-pro' ),
                        'ISO-8859-12' => __( 'IISO-8859-12', 'element-ready-pro' ),
                        'ISO-8859-13' => __( 'IISO-8859-13', 'element-ready-pro' ),
                        'ISO-8859-14' => __( 'IISO-8859-14', 'element-ready-pro' ),
                        'ISO-8859-15' => __( 'IISO-8859-15', 'element-ready-pro' ),
                        'ISO-8859-16' => __( 'IISO-8859-16', 'element-ready-pro' ),
                    ],
                    'condition' => [
                         'source' => 'google'   
                    ],
                    'default' =>  'UTF-8'
                ]
            );

            $this->add_control(
                'encoding_2',
                [
                    'label' => __( 'Encoding', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => false,
                    'options' => [
                     
                        'UTF-8' => __( 'UTF-8', 'element-ready-pro' ),
                        'ISO-8859-1'  => __( 'ISO-8859-1', 'element-ready-pro' ),
           
                    ],
                    'condition' => [
                        'source' => 'qrserver'   
                   ],
                    'default' =>  'UTF-8'
                ]
            );
     
            $this->add_control(
                'size',
                [
                    'label' => __( 'Size', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'min' => 80,
                    'max' => 1000,
                    'step' => 5,
                    'default' => 150,
                ]
            );

            $this->add_control(
                'bg_color',
                [
                    'label' => __( 'BgColor', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                ]
            );

            $this->add_control(
                'color',
                [
                    'label' => __( 'Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'condition' => [
                        'source' => 'qrserver'   
                   ],
                ]
            );

            $this->add_control(
                'margin',
                [
                    'label'   => __( 'Margin', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 0,
                    'max'     => 500,
                    'step'    => 1,
                    'condition' => [
                        'source' => 'google'   
                    ],
                    'default' => 1
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Choose Image', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'condition' => [
                        'source' => 'google'   
                    ],
                ]
            );

            $this->add_control(
                'content_2', [
                    'label'       => __( 'Content', 'element-ready-pro' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'List Title' , 'element-ready-pro' ),
                    'label_block' => true,
                    'condition' => [
                        'source' => 'qrserver'   
                   ],
                ]
            );
    

            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
                'list_title', [
                    'label'       => __( 'Content', 'element-ready-pro' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'List Title' , 'element-ready-pro' ),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'list',
                [
                    'label' => __( 'Line List', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'condition' => [
                        'source' => 'google'   
                    ],
                    'default' => [
                        [
                            'list_title' => __( 'Google', 'element-ready-pro' ),
                        ],
                    ],
                    'title_field' => '{{{ list_title }}}'
                ]
            );

            $this->add_control(
                'correction_lavel',
                [
                    'label' => __( 'Encoding', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => false,
                    'options' => [
                        'L' => __( 'Allows recovery of up to 7% data loss', 'element-ready-pro' ),
                        'M' => __( 'Allows recovery of up to 15% data loss', 'element-ready-pro' ),
                        'Q'  => __( 'Allows recovery of up to 25% data loss', 'element-ready-pro' ),
                        'H'  => __( 'Allows recovery of up to 30% data loss', 'element-ready-pro' ),
                      
                    ],
                    'default' =>  'L' ,
                    'condition' => [
                        'source' => 'google'   
                    ],
                ]
            );

		$this->end_controls_section();
	}

	protected function render() {

		$settings         = $this->get_settings_for_display();
		$random_id        = $this->get_id();
		$list             = $settings['list'];
		$size             = $settings['size']<10?150:$settings['size'];
		$correction_lavel = $settings['correction_lavel'];
		$margin           = $settings['margin'];
        $bg_color         = $settings['bg_color'];
        $image            = $settings['image'];
        $encoding         = $settings['encoding'];
        
        if($settings['source'] == 'google'){

            $oQRC  = new QRCode($bg_color,$encoding);                      
            foreach($list as $item){
                $oQRC->add_line($item['list_title']);
            }
            if($image['url'] !=''){
                $oQRC->add_photo($image['url']);
            }
            $oQRC->finish();
    
            $oQRC->display($size,$correction_lavel,$margin); // Display
        }elseif($settings['source'] == 'qrserver'){
            $alt = '';
            $title = '';
            $url = 'https://api.qrserver.com/v1/create-qr-code/';
            $with_arges = add_query_arg( array(
                'data'           => $settings['content_2'],
                'size'           => $size.'x'.$size,
                'charset-source' => $settings['encoding_2'],
                'color'          => str_replace('#','',$settings['color']),
                'bgcolor'        => str_replace('#','',$settings['bg_color']),
            ), $url );

            echo sprintf('<img src="%s" alt="%s" title="%s" />', $with_arges, $alt, $title);
        }


	}
}



