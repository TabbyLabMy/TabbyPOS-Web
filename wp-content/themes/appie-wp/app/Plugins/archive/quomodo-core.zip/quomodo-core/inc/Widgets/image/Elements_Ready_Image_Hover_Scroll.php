<?php
namespace Element_Ready_Pro\Widgets\image;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Elements_Ready_Image_Hover_Scroll extends Widget_Base {

	public function get_name() {
		return 'Elements_Ready_Image_Hover_Scroll';
	}

	public function get_title(){
		return esc_html__( 'ER Image Hover Scroll' , 'element-ready-pro' );
	}

	public function get_style_depends() {

		wp_register_style( 'eready-image-hover-scroll' , ELEMENT_READY_PRO_ROOT_CSS.'widgets/eready-image-hover-scroll.min.css' ); 
		
		return[
			'eready-image-hover-scroll'
		];
	}

	public function get_script_depends() {
        return [
            'element-ready-core',
        ];
    }

	public function get_icon() {
		return 'eicon-date';
	}

	public function get_categories() {
		return array('element-ready-addons');
	}

    public function get_keywords() {
        return [ 'image', 'scroll', 'image scroll','image hover scroll' ];
    }

	protected function register_controls() {

	
		$this->start_controls_section(
			'section_Settings',
			[
				'label' => esc_html__( 'Settings', 'element-ready-pro' ),
			]
		);

		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => 'https://i.imgur.com/aFFEZ9U.jpg',
				],
			]
		);

		$this->add_control(
			'image_scroll_time',
			[
				'label' => esc_html__( 'Scroll Time', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 30,
						'step' => 5,
					],
					
				],
				
				'selectors' => [
					'{{WRAPPER}} .elements-ready-img-scroll-window img' => 'transition: {{SIZE}}s all ease-in-out;',
				],
			

			]
		);
		
		$this->add_responsive_control(
			'image_width',
			[
				'label' => esc_html__( 'Width', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1200,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .elements-ready-img-scroll-window' => 'width: {{SIZE}}{{UNIT}};',
				],
			

			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label' => esc_html__( 'Height', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1200,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
			
				'selectors' => [
					'{{WRAPPER}} .elements-ready-img-scroll-window img' => 'height: {{SIZE}}{{UNIT}};',
				],
				

			]
		);


		$this->add_control(
			'svg_frame',
			[
				'label'        => esc_html__( 'Svg Frame', 'element-ready-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'element-ready-pro' ),
				'label_off'    => esc_html__( 'Off', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Svg Only', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'exclude_inline_options' => [
					'icon'
				]
				
			]
		);

		$this->add_responsive_control(
			'image_svg_width_size',
			[
				'label' => esc_html__( 'Width', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1200,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'condition' => [
					'svg_frame' => [
						'yes'
					]
				],
				'selectors' => [
					'{{WRAPPER}} .elements-ready-img-scroll-block svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			

			]
		);

		
		$this->add_responsive_control(
			'image_svg_height_size',
			[
				'label' => esc_html__( 'Height', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1200,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'condition' => [
					'svg_frame' => [
						'yes'
					]
				],
				'selectors' => [
					'{{WRAPPER}} .elements-ready-img-scroll-block svg' => 'height: {{SIZE}}{{UNIT}};',
				],
			

			]
		);

		$this->add_responsive_control(
			'image_svg_top',
			[
				'label' => esc_html__( 'Svg Top', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -1200,
						'max' => 1500,
						'step' => 5,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elements-ready-img-scroll-window.elements-ready-img-scroll-macpro' => 'top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'svg_frame' => [
						'yes'
					]
				],

			]
		);

		$this->add_responsive_control(
			'image_svg_left',
			[
				'label' => esc_html__( 'Svg Left', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'condition' => [
					'svg_frame' => [
						'yes'
					]
				],
				'range' => [
					'px' => [
						'min' => -1200,
						'max' => 1500,
						'step' => 5,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
			
				'selectors' => [
					'{{WRAPPER}} .elements-ready-img-scroll-window.elements-ready-img-scroll-macpro' => 'left: {{SIZE}}{{UNIT}};',
				],
				

			]
		);
	

		$this->end_controls_section();
       
		
		$this->start_controls_section(
			'style_date_wrapper_section',
			[
				'label' => esc_html__( 'Style', 'element-ready-pro' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
	
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'flex_width_wrapper_border',
					'label' => esc_html__( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .elements-ready-img-scroll-window img',
				]
			);

			$this->add_control(
				'flex_width_wrapper_padding',
				[
					'label' => esc_html__( 'Padding', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .elements-ready-img-scroll-window img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		

		$this->end_controls_section();

	}
	
	protected function render() {

		$settings = $this->get_settings_for_display();
		
	  ?>
	
	    <?php if(isset($settings['image']['url']) && $settings['image']['url'] !=''): ?>
			
				<div class="elements-ready-img-scroll-block">
					<div class="elements-ready-img-scroll-window <?php echo $settings['svg_frame'] == 'yes'?'elements-ready-img-scroll-macpro':''; ?>">
						<img src="<?php echo esc_url($settings['image']['url']); ?>">
					</div>
					<?php if($settings['svg_frame'] == 'yes'): ?>
						
						<?php if(isset($settings['icon']['value']['url']) && $settings['icon']['value']['url'] !=''): ?>
							<?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
							<?php else: ?>	
								<svg viewBox="0 0 520 443">
							<defs>
								<filter x="-29.9%" y="-500.0%" width="159.7%" height="1100.0%" filterUnits="objectBoundingBox" id="filter-1">
									<feGaussianBlur stdDeviation="20 0" in="SourceGraphic"></feGaussianBlur>
								</filter>
								<radialGradient cx="50%" cy="25.2858292%" fx="50%" fy="25.2858292%" r="778.056242%" gradientTransform="translate(0.500000,0.252858),scale(0.044444,1.000000),rotate(88.646548),translate(-0.500000,-0.252858)" id="radialGradient-2">
									<stop stop-color="#E9EBED" offset="0%"></stop>
									<stop stop-color="#9D9FA2" offset="100%"></stop>
								</radialGradient>
								<linearGradient x1="50%" y1="25.2858292%" x2="50%" y2="100%" id="linearGradient-3">
									<stop stop-color="#848589" offset="0%"></stop>
									<stop stop-color="#F5F5F5" offset="56.5841003%"></stop>
									<stop stop-color="#D5D5D5" offset="80.702943%"></stop>
									<stop stop-color="#BCBCBC" offset="90.8405902%"></stop>
									<stop stop-color="#8D8E92" offset="100%"></stop>
								</linearGradient>
								<linearGradient x1="100%" y1="50%" x2="0%" y2="50%" id="linearGradient-4">
									<stop stop-color="#D2D3D5" offset="0%"></stop>
									<stop stop-color="#95979B" offset="100%"></stop>
								</linearGradient>
								<radialGradient cx="92.9403782%" cy="-1.1418124%" fx="92.9403782%" fy="-1.1418124%" r="96.0040657%" gradientTransform="translate(0.929404,-0.011418),scale(0.600000,1.000000),rotate(90.000000),translate(-0.929404,0.011418)" id="radialGradient-5">
									<stop stop-color="#282828" offset="0%"></stop>
									<stop stop-color="#141414" offset="100%"></stop>
								</radialGradient>
								<linearGradient x1="3.061617e-15%" y1="50%" x2="100%" y2="50%" id="linearGradient-6">
									<stop stop-color="#B3B5BA" offset="0%"></stop>
									<stop stop-color="#F6F8FA" offset="100%"></stop>
								</linearGradient>
								<linearGradient x1="50%" y1="0%" x2="50%" y2="100%" id="linearGradient-7">
									<stop stop-color="#FFFFFF" stop-opacity="0.4" offset="0%"></stop>
									<stop stop-color="#FFFFFF" stop-opacity="0" offset="100%"></stop>
								</linearGradient>
								<radialGradient cx="50%" cy="26.2029892%" fx="50%" fy="26.2029892%" r="40.7383851%" id="radialGradient-8">
									<stop stop-color="#0E0036" offset="0%"></stop>
									<stop stop-color="#26006E" offset="100%"></stop>
								</radialGradient>
								<linearGradient x1="50%" y1="100%" x2="50%" y2="0%" id="linearGradient-9">
									<stop stop-color="#404040" offset="0%"></stop>
									<stop stop-color="#222222" offset="100%"></stop>
								</linearGradient>
							</defs>
							<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
								<g id="Apple-devices" transform="translate(-110.000000, -485.000000)">
									<g id="iMac-27&quot;" transform="translate(110.000000, 485.000000)">
										<g id="Foot" transform="translate(160.000000, 352.000000)">
											<ellipse id="shadow" fill-opacity="0.249999985" fill="#000000" filter="url(#filter-1)" cx="100.5" cy="85" rx="100.5" ry="6"></ellipse>
											<path d="M101.032505,78 C4.08888929,78 12.0380282,82.5 13.0213926,84.75 C13.9125512,86.7890273 57.2727923,86.9997379 101.032504,86.9997359 C144.792215,86.9997339 188.152456,86.7890273 189.043615,84.75 C190.026979,82.5 197.97612,78 101.032505,78 Z" id="rubber" fill="#000000"></path>
											<path d="M101.03287,77 C3.00000041,77 11.0384555,81 12.0328689,83 C12.9340405,84.8124687 56.7814754,84.999767 101.032869,84.9997652 C145.284263,84.9997635 189.131697,84.8124687 190.032869,83 C191.027282,81 199.065739,77 101.03287,77 Z" id="front" fill="url(#radialGradient-2)"></path>
											<path d="M42.8596846,0 C42.8596846,0 38.8820309,71 35.8987907,75 C32.9155505,79 11.0384555,79 12.0328689,81 C12.9340405,82.8124687 56.7814754,82.999767 101.032869,82.9997652 C145.284263,82.9997635 189.131697,82.8124687 190.032869,81 C191.027282,79 169.150187,79 166.166947,75 C163.183707,71 159.206053,0 159.206053,0 L101.032869,0 L42.8596846,0 Z" fill="url(#linearGradient-3)"></path>
										</g>
										<g id="Screen">
											<path d="M15.0017929,0 C6.71653147,0 0,6.72098482 0,14.9913586 L0,329 L520,329 L520,14.9913586 C520,6.71185988 513.282882,0 504.998207,0 L15.0017929,0 Z" id="blackglass" fill="#010000"></path>
											<path d="M0,329 L0,360.00153 C0,368.284956 6.71711823,375 15.0017929,375 L504.998207,375 C513.283469,375 520,368.28659 520,360.00153 L520,329 L0,329 Z" id="alu" fill="url(#linearGradient-4)"></path>
											<rect id="pixels" stroke="url(#radialGradient-5)" stroke-width="4" fill="#FFFFFF" stroke-linejoin="round" x="21" y="19" width="479" height="289"></rect>
											<rect id="edge" fill="url(#linearGradient-6)" x="0" y="329" width="520" height="1"></rect>
											<circle id="camera" stroke="url(#linearGradient-9)" fill="url(#radialGradient-8)" cx="260.5" cy="9.5" r="2.5"></circle>
										</g>
									</g>
								</g>
							</g>
						</svg>						
						<?php endif; ?> 
					<?php endif; ?>
				</div>
			
		<?php endif; ?> 
	  <?php
	}	
}
