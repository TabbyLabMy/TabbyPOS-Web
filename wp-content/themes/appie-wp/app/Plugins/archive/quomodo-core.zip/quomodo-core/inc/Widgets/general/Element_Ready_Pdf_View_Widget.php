<?php
namespace Element_Ready_Pro\Widgets\general;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Element_Ready\Controls\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Element_Ready_Pdf_View_Widget extends Widget_Base {

    public function get_name() {
        return 'Element_Ready_Pdf_View_Widget';
    }
    
    public function get_title() {
        return __( 'ER Pdf Viewer', 'element-ready-pro' );
    }

    public function get_icon() {
        return 'eicon-image-rollover';
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_script_depends() {

        wp_register_script( 'pdf-js', 'https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.2.7/pdfobject.min.js?ver=3.6.2', array('element-ready-core'), ELEMENT_READY_VERSION, true );
        return [
           'pdf-js'
        ];
    }
    public function get_style_depends() {
       
       // wp_register_style( 'eready-popup' , ELEMENT_READY_ROOT_CSS. 'widgets/popup.css' );
        return [  ];
    }

	public function get_keywords() {
        return [ 'pdf','pdf viewer', 'er pdf' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            '_content_section',
            [
                'label' => __( 'Content', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

            $this->add_control(
                'file_link',
                [
                    'label' => esc_html__( 'Select File', 'element-ready-pro' ),
                    'type'	=> Custom_Controls_Manager::MEDIAFILE,
                ]
            );

            $this->add_control(
                'height',
                [
                    'label' => esc_html__( 'Height', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'default' => [
                        'unit' => 'px',
                        'size' => 600,
                    ],
                   
                ]
            );

            $this->add_control(
                'width',
                [
                    'label' => esc_html__( 'Width', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'default' => [
                        'unit' => 'px',
                        'size' => 800,
                    ],
                  
                ]
            );

            $this->add_control(
                'page',
                [
                    'label'   => esc_html__( 'Page', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 1,
                    'max'     => 400,
                    'step'    => 1,
                    'default' => 1,
                ]
            );

            $this->add_control(
                'open_button',
                [
                    'label'        => esc_html__( 'Open Button ?', 'element-ready-pro' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'no',
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label'     => esc_html__( 'Button Text', 'element-ready-pro' ),
                    'type'      => \Elementor\Controls_Manager::TEXT,
                    'default'   => esc_html__( 'Open Document', 'element-ready-pro' ),
                    'condition' => ['open_button' => ['yes']]
                ]
            );

            $this->add_control(
                'text_align',
                [
                    'label' => esc_html__( 'Alignment', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => esc_html__( 'Left', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__( 'Center', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => esc_html__( 'Right', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'default' => 'left',
                    'toggle' => true,
                    'selectors' => [
                        '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                    ],
                ]
            );

        $this->end_controls_section();
        // TABLE STYLE
        $this->start_controls_section(
            '_table_style_section',
            [
                'label' => __( 'Button', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => ['open_button' => ['yes']]
            ]
        );

            $this->start_controls_tabs(
                'button__style_tabs'
            );
            
            $this->start_controls_tab(
                'style_button_normal_tab',
                [
                    'label' => esc_html__( 'Normal', 'element-ready-pro' ),
                ]
            );

        
            $this->add_control(
                'text_button_align',
                [
                    'label' => esc_html__( 'Alignment', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => esc_html__( 'Left', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__( 'Center', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => esc_html__( 'Right', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'default' => '',
                    'toggle' => true,
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__pdf_btn' => 'text-align: {{VALUE}}; width:100%;',
                    ],
                ]
            );

            $this->add_control(
                'button_display',
                [
                    'label' => esc_html__( 'Display', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'inline-block',
                    'options' => [
                        'block' => esc_html__( 'Block', 'element-ready-pro' ),
                        'inline-block' => esc_html__( 'Inline Block', 'element-ready-pro' ),
                   ],
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__pdf_btn' => 'display: {{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => esc_html__( 'Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                       '{{WRAPPER}} .element__ready__pdf_btn' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'content_typography',
                    'selector' => '{{WRAPPER}} .element__ready__pdf_btn',
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name'     => 'table_background',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .element__ready__pdf_btn',
                ]
            );

            $this->add_group_control(
                Group_Control_Border:: get_type(),
                    [
                        'name'     => 'table_border',
                        'label'    => esc_html__( 'Border', 'element-ready-pro' ),
                        'selector' => '{{WRAPPER}} .element__ready__pdf_btn',
                        'separator' => 'before',
                    ]
            );

            $this->add_responsive_control(
                'table_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__pdf_btn' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'table_padding',
                [
                    'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'default' => [
                        'top' => 10,
                        'bottom' => 10,
                        'left' => 10,
                        'right' => 10,
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__pdf_btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'table_margin',
                [
                    'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                   
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__pdf_btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            
            $this->end_controls_tab();

            $this->start_controls_tab(
                'style_button_hover_tab',
                [
                    'label' => esc_html__( 'Hover', 'element-ready-pro' ),
                ]
            );
            
                $this->add_control(
                    'title_hover_color',
                    [
                        'label' => esc_html__( 'Color', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .element__ready__pdf_btn:hover' => 'color: {{VALUE}}',
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name'     => 'hover_table_background',
                        'label'    => __( 'Background', 'element-ready-pro' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .element__ready__pdf_btn:hover',
                    ]
                );

                $this->add_control(
                    'input_box_transition',
                    [
                        'label'      => __( 'Transition', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => 0.1,
                                'max'  => 3,
                                'step' => 0.1,
                            ],
                        ],
                        'default' => [
                            'unit' => 'px',
                            'size' => 0.3,
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .element__ready__pdf_btn'   => 'transition: {{SIZE}}s;',
                           
                        ],
                    ]
                );

            $this->end_controls_tab();
            
            $this->end_controls_tabs();
    

        $this->end_controls_section();

     
    }

    protected function render( $instance = [] ) {

        $settings = $this->get_settings_for_display();
    
        $this->add_render_attribute( 'er_pdf_content_wrap_attr', 'class', 'element__ready__pdf__viewer__wrap' );
        $this->add_render_attribute( 'er_pdf_content_wrap_attr', 'data-url', $settings['file_link'] );
        $this->add_render_attribute( 'er_pdf_content_wrap_attr', 'data-height', $settings['height']['size'] );
        $this->add_render_attribute( 'er_pdf_content_wrap_attr', 'data-height_unit', $settings['height']['unit'] );
        $this->add_render_attribute( 'er_pdf_content_wrap_attr', 'data-width', $settings['width']['size'] );
        $this->add_render_attribute( 'er_pdf_content_wrap_attr', 'data-width_unit', $settings['width']['unit'] );
        $this->add_render_attribute( 'er_pdf_content_wrap_attr', 'data-page', $settings['page'] );
        
        ?> 
            <?php if($settings['open_button'] == 'yes'): ?> 
                <span class="element__ready__pdf_btn"><?php echo esc_html($settings['button_text']); ?></span>
            <?php endif; ?>
            <div <?php echo $this->get_render_attribute_string( 'er_pdf_content_wrap_attr' ); ?>>
            </div>
        <?php
    }
}