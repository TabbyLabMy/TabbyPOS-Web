  
  <?php if($settings['show_comment'] == 'yes'): ?>
            
              <div class="binduz-er-meta-mod binduz-post-comment">
                  <span>
                      <?php if($settings['meta_comment_icon']['library'] !=''): ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['meta_comment_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                       <?php endif; ?>
                  </span>
                  <a href="<?php the_permalink($post->ID); ?>" class="element-ready-pro-comment">
                   <?php echo get_comments_number($post->ID); ?>
                   <?php if($settings['show_comment_text'] == 'yes'): ?>
                        <?php if(get_comments_number($post->ID) > 1): ?>
                            <?php echo esc_html($settings['comment_texts']); ?>
                        <?php else: ?>
                          <?php echo esc_html($settings['comment_text']); ?>
                        <?php endif; ?>
                   <?php endif; ?>
                  </a>
               
              </div>
          
  <?php endif; ?>