<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Db_Controls;
use Element_Ready_Pro\Base\Traits\Widget_Controls\Box\ERP_Box_Style;
use Element_Ready_Pro\Base\Traits\Widget_Controls\Box\ERP_Common_Style;
use Element_Ready_Pro\Base\Traits\Widget_Controls\Box\ERP_Position_Style;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 
 */
trait Er_Style_Control
{
    use ERP_Box_Style,ERP_Common_Style,ERP_Position_Style;

    public function _er_init_style(){

		
		$this->preset_style_control();
    }

	public function preset_style_control(){

        $er_settings = $this->er_get_db_seetings();
        $db_content  = new Db_Controls($this->er_get_db_seetings(),$this->widget_post_id());
        $controls    = $db_content->er_get_style_fields();
  
		$this->start_controls_section(
			'er_preset_style_content_section',
			[
				'label' => esc_html__( 'General', 'element-ready-pro' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		if(is_array($controls)){
           
			
            foreach($controls as $key => $item){

				$title = $item['control_Title'].'_'.$er_settings['widget_name'].'_'.$this->widget_post_id().'_'.$key;
                $title = preg_replace('/\s+/', '_', $title);
				
				if( $item['control_type'] == 'style' ) {

					$selector = $this->er_get_selector($item);

					if( $item['control_f_type'] == 'color' ){
					
						$this->add_control(
							$title,
							[
								'label' => $item['control_Title'],
								'type' => \Elementor\Controls_Manager::COLOR,
								'selectors' => [
									$selector => 'color: {{VALUE}}',
								],
							]
						);
					} // control_f_type end
					
					if( $item['control_f_type'] == 'typhography' ){
					
						$this->add_group_control(
							\Elementor\Group_Control_Typography::get_type(),
							[
								'name' => $title,
								'label' => $item['control_Title'],
								'selector' => $selector,
							]
						);

					} // control_f_type end

					if( $item['control_f_type'] == 'background' ){
					
						$this->add_group_control(
							\Elementor\Group_Control_Background::get_type(),
							[
								'name' => $title,
								'label' => $item['control_Title'],
								'types' => [ 'classic', 'gradient', 'video' ],
								'selector' => $selector,
							]
						);
				
					} // control_f_type end

					if( $item['control_f_type'] == 'border' ){
					
						$this->add_group_control(
							\Elementor\Group_Control_Border::get_type(),
							[
								'name' => $title,
								'label' => $item['control_Title'],
								'selector' => $selector,
							]
						);
				
					} // control_f_type end
					
					if( $item['control_f_type'] == 'border-radius' ){
					
						$this->add_responsive_control(
							$title,
							[
								'label' => $item['control_Title'],
								'type' => \Elementor\Controls_Manager::SLIDER,
								'size_units' => [ 'px', '%' ],
								'range' => [
									'px' => [
										'min' => 0,
										'max' => 1000,
										'step' => 5,
									],
									'%' => [
										'min' => 0,
										'max' => 100,
									],
								],
								'default' => [
									'unit' => '%',
									'size' => 50,
								],
								'selectors' => [
									$selector => 'border-radius: {{SIZE}}{{UNIT}};',
								],
							]
						);
				
					} // control_f_type end

					if( $item['control_f_type'] == 'slider-width' ){
					
						$this->add_responsive_control(
							$title,
							[
								'label' => $item['control_Title'],
								'type' => Controls_Manager::SLIDER,
								'size_units' => [ 'px', '%' ],
								'range' => [
									'px' => [
										'min' => 0,
										'max' => 1000,
										'step' => 5,
									],
									'%' => [
										'min' => 0,
										'max' => 100,
									],
								],
								'default' => [
									'unit' => '%',
									'size' => 50,
								],
								'selectors' => [
									$selector => 'width: {{SIZE}}{{UNIT}};',
								],
							]
						);
				
					} // control_f_type end

					if( $item['control_f_type'] == 'slider-height' ){
					
						$this->add_responsive_control(
							$title,
							[
								'label' => $item['control_Title'],
								'type' => Controls_Manager::SLIDER,
								'size_units' => [ 'px', '%' ],
								'range' => [
									'px' => [
										'min' => 0,
										'max' => 1000,
										'step' => 5,
									],
									'%' => [
										'min' => 0,
										'max' => 100,
									],
								],
								'default' => [
									'unit' => '%',
									'size' => 50,
								],
								'selectors' => [
									$selector => 'height: {{SIZE}}{{UNIT}};',
								],
							]
						);
				
					} // control_f_type end
					
					if( $item['control_f_type'] == 'margin' ){
					
					
						$this->add_responsive_control(
							$title,
							[
								'label'      => $item['control_Title'],
								'type'       => Controls_Manager::DIMENSIONS,
								'size_units' => [ 'px', '%', 'em' ],
								'selectors'  => [
									$selector => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
								'separator' => 'before',
							]
						);
				
					} // control_f_type end

					if( $item['control_f_type'] == 'padding' ){
					
					
						$this->add_responsive_control(
							$title,
							[
								'label'      => $item['control_Title'],
								'type'       => Controls_Manager::DIMENSIONS,
								'size_units' => [ 'px', '%', 'em' ],
								'selectors'  => [
									$selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
								'separator' => 'before',
							]
						);
				
					} // control_f_type end

					if( $item['control_f_type'] == 'box-shadow' ){

						$this->add_group_control(
							\Elementor\Group_Control_Box_Shadow::get_type(),
							[
								'name' => $title,
								'label' => $item['control_Title'],
								'selector' => $selector,
							]
						);

					} // control_f_type end

					if( $item['control_f_type'] == 'text-shadow' ){

						$this->add_group_control(
							\Elementor\Group_Control_Text_Shadow::get_type(),
							[
								'name' => $title,
								'label' => $item['control_Title'],
								'selector' => $selector,
							]
						);

					} // control_f_type end

			    } // control_type end
			}
		}

		$this->end_controls_section();
		if(is_array($controls)){
           
			
            foreach($controls as $key => $item){

				$title = $item['control_Title'].'_'.$er_settings['widget_name'].'_'.$this->widget_post_id().'_'.$key;
                $title = preg_replace('/\s+/', '_', $title);
				
				if( $item['control_type'] == 'style' ) {

					$selector = $this->er_get_selector($item);

					if( $item['control_f_type'] == 'box-preset' ){

						$this->box_css(
							array(
								'title' => $item['control_Title'],
								'slug' => $title,
								'element_name' => $title.'_element_ready_',
								'selector' => $selector,
							)
						);

					} // control_f_type end

					if( $item['control_f_type'] == 'basic-preset' ){

						$this->text_css(
							array(
								'title' => $item['control_Title'],
								'slug' => $title,
								'element_name' => $title.'_element_ready_',
								'selector' => $selector,
							)
						);

					} // control_f_type end
				}
			} // endforeach
		}		 		
		
	}

	
	
	
}
  