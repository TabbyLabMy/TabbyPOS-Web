<?php
namespace Element_Ready_Pro\Modules\elefinder\category;

class WR_Settings_Finder_Category extends \Elementor\Core\Common\Modules\Finder\Base_Category {
	
	public function get_title() {
		return esc_html__( 'ER Settings', 'element-ready-pro' );
	}

	public function get_category_items( array $options = [] ) {

		$items = [
		
			'element_ready_dashboard' => [
				'title' => __( 'Element Ready DashBoard', 'element-ready-pro' ),
				'url' =>  $this->get_dashboard_url(),
				'icon' => 'edit',
				'keywords' => [
					'element-ready',
					esc_html__('Element Ready links','element-ready-pro'),
					esc_html__('settings','element-ready-pro')
					]
			],
			
		];

		return $items;
	}


	/**
	 * Dashboard page url
	 * @param page slug
	 * @return url string
	 */
	function get_dashboard_url($slug = null){

		if(is_null($slug)){
			
			return admin_url('admin.php?page='.ELEMENT_READY_SETTING_PATH);
		}

		return admin_url('admin.php?page='.$slug);
	}
    
}