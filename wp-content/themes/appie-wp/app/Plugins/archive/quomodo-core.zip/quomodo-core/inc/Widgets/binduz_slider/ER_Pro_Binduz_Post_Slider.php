<?php
namespace Element_Ready_Pro\Widgets\binduz_slider;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Element_Ready\Base\Repository\Base_Modal;
use Elementor\Group_Control_Image_Size;

require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );


if ( ! defined( 'ABSPATH' ) ) exit;

class ER_Pro_Binduz_Post_Slider extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public $base;

    public function get_name() {
        return 'element-ready-pro-binduz-er-slider-post';
    }

    public function get_title() {
        return esc_html__( 'ER News Slider' , 'element-ready-pro' );
    }
    public function get_script_depends(){

       return [
         'element-ready-core','slick'
       ];

    }
    public function get_style_depends(){

      wp_register_style( 'element-ready-binduz-post-slider' , ELEMENT_READY_ROOT_CSS. 'widgets/binduz-post-slider.css' );
        
      return [
          'element-ready-binduz-post-slider','slick'
      ];
       
    }

    public function get_icon() { 
        return "eicon-posts-carousel";
    }

    public function get_categories() {
      return [ 'element-ready-pro' ];
    }

    protected function register_controls() {
          
        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'element-ready-pro'),
            ]
        );

        $this->add_control(
			'block_style',
			[
				'label' => esc_html__( 'Style', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'element-ready-pro' ),
					'style2'  => esc_html__( 'Style 2', 'element-ready-pro' ),
					'style3'  => esc_html__( 'Style 3', 'element-ready-pro' ),
					'style4'  => esc_html__( 'Style 4', 'element-ready-pro' ),
					'style6'  => esc_html__( 'Style 5', 'element-ready-pro' ),
					'style7'  => esc_html__( 'Style 6', 'element-ready-pro' ),
				],
			]
		);

       $this->end_controls_section();
  
      $this->start_controls_section(
         'section_slick_tab',
             [
                 'label' => esc_html__('Slider', 'element-ready-pro'),
             ]
         );

         $this->add_control(
            'slider_enable',
            [
                'label'     => esc_html__('Enable', 'element-ready-pro'),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                'label_off' => esc_html__('No', 'element-ready-pro'),
                'default'   => 'yes',
            
            ]
        );
 
         $this->add_control(
             'slidesToShow',
             [
                 'label'         => esc_html__( 'Slide To show', 'element-ready-pro' ),
                 'type'          => Controls_Manager::NUMBER,
                 'default'       => '1',
                 'condition' => [
                     'block_style!' => [
                         'style'
                     ]
                 ]
             
             ]
         );

         $this->add_control(
             'slide_padding',
                 [
                     'label'         => esc_html__( 'Slide Padding', 'element-ready-pro' ),
                     'type'          => Controls_Manager::NUMBER,
                     'default'       => '0',
                 ]
             );
         
         $this->add_control(
             'show_nav',
             [
                 'label'     => esc_html__('Show Nav', 'element-ready-pro'),
                 'type'      => Controls_Manager::SWITCHER,
                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                 'label_off' => esc_html__('No', 'element-ready-pro'),
                 'default'   => 'yes',
             
             ]
         );

         $this->add_control(
             'autoplay',
             [
                 'label'     => esc_html__('Autoplay', 'element-ready-pro'),
                 'type'      => Controls_Manager::SWITCHER,
                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                 'label_off' => esc_html__('No', 'element-ready-pro'),
                 'default'   => 'yes',
             
             ]
         ); 
            
         $this->add_control(
             'autoplaySpeed',
                 [
                     'label'         => esc_html__( 'Auto play Speed', 'element-ready-pro' ),
                     'type'          => Controls_Manager::NUMBER,
                     'default'       => '2000',
                 ]
             );

         $this->add_control(
             'slide_speed',
                 [
                     'label'         => esc_html__( 'Slide Speed', 'element-ready-pro' ),
                     'type'          => Controls_Manager::NUMBER,
                     'default'       => '3000',
                 ]
             ); 

             $this->add_control(
                 'left_icon',
                 [
                     'label' => __( 'Left Indicator', 'element-ready-pro' ),
                     'type' => \Elementor\Controls_Manager::ICONS,
                     'default' => [
                         'value' => 'fa fa-angle-left',
                         'library' => 'solid',
                     ],
                 ]
             );

             $this->add_control(
                 'right_icon',
                 [
                     'label' => __( 'Right Indicator', 'element-ready-pro' ),
                     'type' => \Elementor\Controls_Manager::ICONS,
                     'default' => [
                         'value' => 'fa fa-angle-right',
                         'library' => 'solid',
                     ],
                 ]
             );

         $this->end_controls_section();	

   $this->start_controls_section(
            'section_slider_general_tab',
                [
                    'label' => esc_html__('General', 'element-ready-pro'),
                ]
            );

                  $this->add_control(
                    'post_count',
                        [
                            'label'         => esc_html__( 'Post count', 'element-ready-pro' ),
                            'type'          => Controls_Manager::NUMBER,
                            'default'       => '8',
                        ]
                    );

                  $this->add_control(
                    'post_title_crop',
                        [
                            'label'         => esc_html__( 'Post title crop', 'element-ready-pro' ),
                            'type'          => Controls_Manager::NUMBER,
                            'default'       => '8',
                        ]
                    );

                // uncommon  
               
                  $this->add_control(
                        'show_content',
                        [
                            'label'     => esc_html__('Show content', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'yes',
                           
                        ]
                    );
     
               
                    $this->add_control(
                        'post_content_crop',
                            [
                                'label'         => esc_html__( 'Post content crop', 'element-ready-pro' ),
                                'type'          => Controls_Manager::NUMBER,
                                'default'       => '18',
                                'condition' => [ 'show_content' => ['yes'] ]
                            ]
                    );

                    $this->add_control(
                     'image_sizee_options',
                     [
                         'label' => __( 'Tab Image', 'element-ready-pro' ),
                         'type' => \Elementor\Controls_Manager::HEADING,
                         'separator' => 'before',
                     ]
                 );

                 $this->add_group_control(
                     \Elementor\Group_Control_Image_Size::get_type(),
                     [
                         'name' => 'thumb_size', 
                         'include' => [],
                         'exclude' => [ 'custom' ],
                         'default' => 'medium',
                     ]
                 );
                
                    $this->add_control(
                        'show_post_meta',
                        [
                            'label'     => esc_html__('Post Meta', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'yes',
                        ]
                    );

                     $this->add_control(
                        'show_post_meta_toggle',
                        [
                           'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                           'label' => esc_html__( 'Post Top Meta', 'element-ready-pro' ),
                           'label_off' => esc_html__( 'Default', 'element-ready-pro' ),
                           'label_on' => esc_html__( 'Custom', 'element-ready-pro' ),
                           'return_value' => 'no',
                           'condition' => [
                              'block_style!' => ['style1']
                           ]
                        ]
                     );
                     
                     $this->start_popover();

                     $this->add_control(
                        'top_meta_enable',
                        [
                           'label'     => esc_html__('Enable', 'element-ready-pro'),
                           'type'      => Controls_Manager::SWITCHER,
                           'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                           'label_off' => esc_html__('No', 'element-ready-pro'),
                           'default'   => 'no',
                           'condition' => [
                              'show_post_meta' => ['yes']
                           ]
                        ]
                  );

                     $this->add_control(
                           'show_top_author',
                           [
                              'label'     => esc_html__('Show Author', 'element-ready-pro'),
                              'type'      => Controls_Manager::SWITCHER,
                              'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                              'label_off' => esc_html__('No', 'element-ready-pro'),
                              'default'   => 'no',
                              'condition' => [
                                 'top_meta_enable' => ['yes']
                              ]
                           ]
                     );

                     $this->add_control(
                        'show_top_author_image',
                        [
                           'label'     => esc_html__('Show Author Image', 'element-ready-pro'),
                           'type'      => Controls_Manager::SWITCHER,
                           'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                           'label_off' => esc_html__('No', 'element-ready-pro'),
                           'default'   => 'no',
                           'condition' => [
                              'top_meta_enable' => ['yes']
                           ]
                        ]
                  );

                     $this->add_control(
                        'show_top_date',
                        [
                           'label'     => esc_html__('Show Date', 'element-ready-pro'),
                           'type'      => Controls_Manager::SWITCHER,
                           'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                           'label_off' => esc_html__('No', 'element-ready-pro'),
                           'default'   => 'yes',
                           'condition' => [
                              'top_meta_enable' => ['yes']
                           ]
                        ]
                  );

                     $this->add_control(
                        'show_top_cat',
                        [
                           'label'     => esc_html__('Show Cat', 'element-ready-pro'),
                           'type'      => Controls_Manager::SWITCHER,
                           'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                           'label_off' => esc_html__('No', 'element-ready-pro'),
                           'default'   => 'no',
                           'condition' => [
                              'top_meta_enable' => ['yes']
                           ]
                        ]
                      );

                      $this->add_control(
                        'show_top_cat_icon',
                        [
                           'label' => esc_html__( 'Category Icon', 'element-ready-pro' ),
                           'type' => \Elementor\Controls_Manager::ICONS,
                           'condition' => [
                              'show_top_cat' => ['yes']
                           ]
                        ]
                     );
               

                      $this->add_control(
                        'show_top_comment',
                        [
                           'label'     => esc_html__('Show Comment', 'element-ready-pro'),
                           'type'      => Controls_Manager::SWITCHER,
                           'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                           'label_off' => esc_html__('No', 'element-ready-pro'),
                           'default'   => 'no',
                           'condition' => [
                              'top_meta_enable' => ['yes']
                           ]
                        ]
                     );
                        
                     $this->end_popover();

                     $this->add_control(
                        'bottom_post_meta_toggle',
                        [
                           'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                           'label' => esc_html__( 'Meta', 'element-ready-pro' ),
                           'label_off' => esc_html__( 'Default', 'element-ready-pro' ),
                           'label_on' => esc_html__( 'Custom', 'element-ready-pro' ),
                           'return_value' => 'yes',
                         
                        ]
                     );
                     
                     $this->start_popover();

                        $this->add_control(
                              'show_author',
                              [
                                 'label'     => esc_html__('Show Author', 'element-ready-pro'),
                                 'type'      => Controls_Manager::SWITCHER,
                                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                                 'label_off' => esc_html__('No', 'element-ready-pro'),
                                 'default'   => 'no',
                                 'condition' => [
                                    'show_post_meta' => ['yes']
                                 ]
                              ]
                        );

                        $this->add_control(
                           'show_author_image',
                           [
                              'label'     => esc_html__('Show Author Image', 'element-ready-pro'),
                              'type'      => Controls_Manager::SWITCHER,
                              'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                              'label_off' => esc_html__('No', 'element-ready-pro'),
                              'default'   => 'no',
                              'condition' => [
                                 'show_author' => ['yes']
                              ]
                           ]
                        );
   
                    
                        $this->add_control(
                              'show_date',
                              [
                                 'label'     => esc_html__('Show Date', 'element-ready-pro'),
                                 'type'      => Controls_Manager::SWITCHER,
                                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                                 'label_off' => esc_html__('No', 'element-ready-pro'),
                                 'default'   => 'yes',
                                 'condition' => [
                                    'show_post_meta' => ['yes']
                                 ]
                              ]
                        );

                   
     
              
                        $this->add_control(
                              'show_cat',
                              [
                                 'label'     => esc_html__('Show Category', 'element-ready-pro'),
                                 'type'      => Controls_Manager::SWITCHER,
                                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                                 'label_off' => esc_html__('No', 'element-ready-pro'),
                                 'default'   => 'yes',
                                 'condition' => [
                                    'show_post_meta' => ['yes']
                                 ]
                              ]
                        );

                        $this->add_control(
                           'show_meta_over_image',
                           [
                              'label'     => esc_html__('Meta Over Image?', 'element-ready-pro'),
                              'type' => \Elementor\Controls_Manager::SELECT,
                              'default' => '',
                              'options' => [
                                 'cat'  => esc_html__( 'Category', 'element-ready-pro' ),
                                 'date' => esc_html__( 'Date', 'element-ready-pro' ),
                                 '' => esc_html__( 'None', 'element-ready-pro' ),
                              ],
                           ]
                        );

                        $this->add_control(
                           'er_image_date_format',
                           [
                              'label'     => esc_html__('Date Format', 'element-ready-pro'),
                              'type' => \Elementor\Controls_Manager::SELECT,
                              'default' => '',
                              'options' => [
                                 ''          => '',
                                 'F j'       => esc_html__( 'F j', 'element-ready-pro' ),
                                 'F , j'       => esc_html__( 'F , j', 'element-ready-pro' ),
                                 'l F j Y' => esc_html__( 'l F j Y', 'element-ready-pro' ),
                                 'l, F j, Y' => esc_html__( 'l, F j, Y', 'element-ready-pro' ),
                                 'l, F j'    => esc_html__( 'l, F j', 'element-ready-pro' ),
                                 'l F j'    => esc_html__( 'l F j', 'element-ready-pro' ),
                                 'M j Y'    => esc_html__( 'M j Y', 'element-ready-pro' ),
                                 'M j, Y'    => esc_html__( 'M j, Y', 'element-ready-pro' ),
                                 'M , j'       => esc_html__( 'M , j', 'element-ready-pro' ),
                                 'M j'       => esc_html__( 'M j', 'element-ready-pro' ),
                                 'Y-m-d'     => esc_html__( 'Y-m-d', 'element-ready-pro' ),
                                 'Y/m/d'     => esc_html__( 'Y/m/d', 'element-ready-pro' ),
                                 'F Y'      => esc_html__( 'F Y', 'element-ready-pro' ),
                                 'F , Y'      => esc_html__( 'F, Y', 'element-ready-pro' ),
                              ],
                              'condition' => [
   
                                 'show_meta_over_image' => ['date']
                                 
                              ]
                           ]
                        );
              
                   
                        $this->add_control(
                              'show_readmore',
                              [
                                 'label'     => esc_html__('Show Readmore', 'element-ready-pro'),
                                 'type'      => Controls_Manager::SWITCHER,
                                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                                 'label_off' => esc_html__('No', 'element-ready-pro'),
                                 'default'   => 'yes',
                                 'condition' => [
                                    'show_post_meta' => ['yes']
                                 ]
                              ]
                        );

                     $this->add_control(
                        'readmore_text',
                              [
                                 'label'     => esc_html__('Readmore Text?', 'element-ready-pro'),
                                 'type'          => Controls_Manager::TEXT,
                                 'default'       => 'readmore',
                                 'condition' => [
                                    'show_readmore' => ['yes'],
                                   
                                 ]
                              ]
                        );

                        $this->add_control(
                              'show_comment',
                              [
                                 'label'     => esc_html__('Show Comment', 'element-ready-pro'),
                                 'type'      => Controls_Manager::SWITCHER,
                                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                                 'label_off' => esc_html__('No', 'element-ready-pro'),
                                 'default'   => 'yes',
                                 'condition' => [
                                    'show_post_meta' => ['yes']
                                 ]
                              ]
                        );

                        

                        $this->add_control(
                              'show_comment_text',
                              [
                                 'label'     => esc_html__('Comment Text?', 'element-ready-pro'),
                                 'type'      => Controls_Manager::SWITCHER,
                                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                                 'label_off' => esc_html__('No', 'element-ready-pro'),
                                 'default'   => 'no',
                                 'condition' => [
                                    'show_comment' => ['yes']
                                 ]
                              
                              ]
                        );

                        $this->add_control(
                        'comment_text',
                              [
                                 'label'         => esc_html__( 'Comment', 'element-ready-pro' ),
                                 'type'          => Controls_Manager::TEXT,
                                 'default'       => 'comment',
                                 'condition' => [
                                    'show_comment_text' => ['yes'],
                                    'show_comment' => ['yes']
                                 ]
                              ]
                        );

                        $this->add_control(
                        'comment_texts',
                              [
                                 'label'         => esc_html__( 'Comments', 'element-ready-pro' ),
                                 'type'          => Controls_Manager::TEXT,
                                 'default'       => 'comments',
                                 'condition' => [
                                    'show_comment_text' => ['yes'],
                                    'show_comment' => ['yes']
                                 ]
                              ]
                        );
                  
                
                        $this->add_control(
                              'show_view_count',
                              [
                                 'label'     => esc_html__('Show view Count', 'element-ready-pro'),
                                 'type'      => Controls_Manager::SWITCHER,
                                 'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                                 'label_off' => esc_html__('No', 'element-ready-pro'),
                                 'default'   => 'no',
                                 'condition' => [
                                    'block_style' => ['style2'],
                                    'show_post_meta' => ['yes']
                                       ]
                              ]
                        );

                     $this->end_popover();
   
          
                    
                    $this->add_responsive_control(
                     'er_aligntext_align',
                     [
                        'label'   => esc_html__( 'Alignment', 'element-ready-pro' ),
                        'type'    => \Elementor\Controls_Manager::CHOOSE,
                        'options' => [
                           'align-items:flex-start; text-align: left; justify-content: left;' => [
                              'title' => esc_html__( 'Left', 'element-ready-pro' ),
                              'icon'  => 'eicon-text-align-left',
                           ],
                           'align-items:center; text-align: center; justify-content: center;' => [
                              'title' => esc_html__( 'Center', 'element-ready-pro' ),
                              'icon'  => 'eicon-text-align-center',
                           ],
                           'align-items:flex-end; text-align: right; justify-content: right;' => [
                              'title' => esc_html__( 'Right', 'element-ready-pro' ),
                              'icon'  => 'eicon-text-align-right',
                           ],
                        
                        ],
                     
                        'toggle'    => true,
                        'selectors' => [
                           '{{WRAPPER}} .binduz-er-news-slider-content-slider .binduz-er-item'           => '{{VALUE}}',
                           '{{WRAPPER}} .binduz-er-social-news-box .binduz-er-social-news-item'           => '{{VALUE}}',
                        
                         
                       ],
                       'condition' => [
                          'block_style!' => ['style1','style3','style4','style6']
                       ]
                     
                     ]
                  );

                  $this->add_responsive_control(
                     'er_aligntext_flexc_align',
                     [
                        'label'   => esc_html__( 'Alignment', 'element-ready-pro' ),
                        'type'    => \Elementor\Controls_Manager::CHOOSE,
                        'options' => [
                           'align-items:flex-start; text-align: left;' => [
                              'title' => esc_html__( 'Left', 'element-ready-pro' ),
                              'icon'  => 'eicon-text-align-left',
                           ],
                           'align-items:center; text-align: center;' => [
                              'title' => esc_html__( 'Center', 'element-ready-pro' ),
                              'icon'  => 'eicon-text-align-center',
                           ],
                           'align-items:flex-end; text-align: right;' => [
                              'title' => esc_html__( 'Right', 'element-ready-pro' ),
                              'icon'  => 'eicon-text-align-right',
                           ],
                        
                        ],
                     
                        'toggle'    => true,
                        'selectors' => [
                           '{{WRAPPER}} .binduz-er-content'           => '{{VALUE}}',
                           '{{WRAPPER}} .er-meta-over-image'           => '{{VALUE}}',

                         
                       ],
                       'condition' => [
                        'block_style' => ['style1','style3','style4','style6']
                     ]
                     
                     ]
                  );
                              
       $this->end_controls_section();	

       $this->start_controls_section(
         'sectionmeta_order_item_tab',
             [
                 'label' => esc_html__('Content ReOrder', 'element-ready-pro'),
             ]
         );

         $this->add_control(
             '_order_title',
             [
                 'label'      => esc_html__( 'Title', 'element-ready-pro' ),
                 'type'       => Controls_Manager::SLIDER,
                 'size_units' => [ 'px' ],
                 'range'      => [
                     'px' => [
                         'min'  => -20,
                         'max'  => 100,
                         'step' => 1,
                     ],
                 
                 ],
                
                 'selectors' => [
                     '{{WRAPPER}} .binduz-er-content .binduz-er-trending-news-list-title' => 'order: {{SIZE}};',
                     '{{WRAPPER}} .binduz-er-content .binduz-er-title' => 'order: {{SIZE}};',
                 ],
                 'condition' => [
                  'block_style!' => [
                     'style2'
                  ]
               ]
                
             ]
         );

         $this->add_control(
             '_order_image',
             [
                 'label'      => esc_html__( 'Image', 'element-ready-pro' ),
                 'type'       => Controls_Manager::SLIDER,
                 'size_units' => [ 'px' ],
                 'range'      => [
                     'px' => [
                         'min'  => -20,
                         'max'  => 100,
                         'step' => 1,
                     ],
                 
                 ],
                
                 'selectors' => [
                     '{{WRAPPER}} .er-meta-over-image' => 'order: {{SIZE}};',
                 ],

                 'condition' => [
                    'block_style!' => [
                       'style2'
                    ]
                 ]
                
             ]
         );

         $this->add_control(
             '_order_content',
             [
                 'label'      => esc_html__( 'Content', 'element-ready-pro' ),
                 'type'       => Controls_Manager::SLIDER,
                 'size_units' => [ 'px' ],
                 'range'      => [
                     'px' => [
                         'min'  => -20,
                         'max'  => 100,
                         'step' => 1,
                     ],
                 
                 ],
                
                 'selectors' => [
                     '{{WRAPPER}} .er-binduz-news-content' => 'order: {{SIZE}};',
                     '{{WRAPPER}} .binduz-er-news-slider-content-slider .binduz-er-news-slider-content' => 'order: {{SIZE}};',
                 ],

                 'condition' => [
                     'show_content' => ['yes']
                 ]
                
             ]
         );

         $this->add_control(
             '_order_readmore',
             [
                 'label'      => esc_html__( 'ReadMore', 'element-ready-pro' ),
                 'type'       => Controls_Manager::SLIDER,
                 'size_units' => [ 'px' ],
                 'range'      => [
                     'px' => [
                         'min'  => -20,
                         'max'  => 100,
                         'step' => 1,
                     ],
                 
                 ],
                
                 'selectors' => [
                     '{{WRAPPER}} .er-readmore-btn' => 'order: {{SIZE}};',
                    
                 ],

                 'condition' => [
                     'show_readmore' => ['yes']
                 ]
                
             ]
         );

         $this->add_control(
             'meta_order_container',
             [
                 'label'      => esc_html__( 'Meta', 'element-ready-pro' ),
                 'type'       => Controls_Manager::SLIDER,
                 'size_units' => [ 'px' ],
                 'range'      => [
                     'px' => [
                         'min'  => -20,
                         'max'  => 100,
                         'step' => 1,
                     ],
                 
                 ],
                
                 'selectors' => [
                     '{{WRAPPER}} .binduz-er-meta-item' => 'order: {{SIZE}};',
                     '{{WRAPPER}} .element-ready-post-meta' => 'order: {{SIZE}};',
                 ],
                
             ]
         );

     $this->end_controls_section();	

     $this->start_controls_section('er_binduz_flex_item_section',
     [
        'label' => esc_html__( 'Single Item layout', 'element-ready-pro' ),
         'condition' => [
            'block_style!' => ['style2','style7']
         ]
        
     ]
    );

         $this->add_responsive_control(
                 'post_tab_grid_display',
                 [
                     'label' => esc_html__( 'Layout', 'element-ready-pro' ),
                     'type' => \Elementor\Controls_Manager::SELECT,
                     'default' => '',
                     'options' => [
                         'flex'         => esc_html__( 'Flexible', 'element-ready-pro' ),
                         'block'        => esc_html__( 'Block', 'element-ready-pro' ),
                     ],
                     'selectors' => [
                         '{{WRAPPER}} .binduz-er-trending-news-list-box' => 'display: {{VALUE}};',
                         '{{WRAPPER}} .binduz-er-news-viewed-most' => 'display: {{VALUE}};',
                         '{{WRAPPER}} .binduz-er-social-news-item' => 'display: {{VALUE}};',
                         '{{WRAPPER}} .binduz-er-latest-news-item' => 'display: {{VALUE}};'
                     ],
                 ]
                 
             );

             
             $this->add_responsive_control(
                 'post_tab_grid_display_row_clum',
                 [
                     'label' => esc_html__( 'Flex Direction', 'element-ready-pro' ),
                     'type' => \Elementor\Controls_Manager::SELECT,
                     'default' => '',
                     'options' => [
                         'column'         => esc_html__( 'Column', 'element-ready-pro' ),
                         'row'            => esc_html__( 'Row', 'element-ready-pro' ),
                         'column-reverse' => esc_html__( 'Column Reverse', 'element-ready-pro' ),
                         'row-reverse'    => esc_html__( 'Row Reverse', 'element-ready-pro' ),
                 
                     ],
                     'selectors' => [
                         '{{WRAPPER}} .binduz-er-trending-news-list-box' => 'flex-direction: {{VALUE}};',
                         '{{WRAPPER}} .binduz-er-news-viewed-most' => 'flex-direction: {{VALUE}};',
                         '{{WRAPPER}} .binduz-er-social-news-item' => 'flex-direction: {{VALUE}};',
                         '{{WRAPPER}} .binduz-er-latest-news-item' => 'flex-direction: {{VALUE}};'
                     ],
                     'condition' => [
                         'post_tab_grid_display!' => ['block']
                     ]
                  ]
                 
             );

             $this->add_responsive_control(
                 'er_tab_flex_layouts',
                 [
                     'label' => esc_html__( 'Content Column Gap', 'element-ready-pro' ),
                     'type' => \Elementor\Controls_Manager::SLIDER,
                     'size_units' => [ 'px' ],
                     'range' => [
                         'px' => [
                             'min' => 0,
                             'max' => 14,
                             'step' => 1,
                         ],
                     ],
                     'selectors' => [
                         '{{WRAPPER}} .binduz-er-trending-news-list-box' => 'gap: {{SIZE}}{{UNIT}};',
                         '{{WRAPPER}} .binduz-er-news-viewed-most' => 'gap: {{SIZE}}{{UNIT}};',
                         '{{WRAPPER}} .binduz-er-latest-news-item' => 'gap: {{SIZE}}{{UNIT}};',
                         '{{WRAPPER}} .binduz-er-social-news-item' => 'gap: {{SIZE}}{{UNIT}};',
                     ],
                     'condition' => [
                         'post_tab_grid_display!' => ['block']
                     ]
                 ]
             );


     $this->end_controls_section();


       $this->content_text([
         'title' => esc_html__('Meta Icon','element-ready-pro'),
         'slug' => '_meta_icons_content',
         'condition' => '',
         'controls' => [

            'meta_icon'=> [
               'label' => esc_html__( 'Meta Icon', 'element-ready-pro' ),
               'type'  => \Elementor\Controls_Manager::ICONS,
             ],

           'meta_cat_icon'=> [
             'label' => esc_html__( 'Meta Category Icon', 'element-ready-pro' ),
             'type'  => \Elementor\Controls_Manager::ICONS,
           ],

           'meta_author_icon'=> [
             'label' => esc_html__( 'Meta Author Icon', 'element-ready-pro' ),
             'type'  => \Elementor\Controls_Manager::ICONS,
           ],

           'meta_date_icon'=> [
             'label' => esc_html__( 'Meta Date Icon', 'element-ready-pro' ),
             'type'  => \Elementor\Controls_Manager::ICONS,
           ],

           'meta_comment_icon'=> [
             'label' => esc_html__( 'Meta Comment Icon', 'element-ready-pro' ),
             'type'  => \Elementor\Controls_Manager::ICONS,
           ],
           
           'meta_video_icon'=> [
             'label' => esc_html__( 'Meta Video Icon', 'element-ready-pro' ),
             'type'  => \Elementor\Controls_Manager::ICONS,
           ],
       
           'meta_readmore_icon'=> [
             'label' => esc_html__( 'Readmore Icon', 'element-ready-pro' ),
             'type'  => \Elementor\Controls_Manager::ICONS,
           ],
       
         ]
      ]);

     
       do_action( 'element_ready_section_data_exclude_tab', $this , $this->get_name() );  
       do_action( 'element_ready_section_date_filter_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_taxonomy_filter_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_sort_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_sticky_tab', $this , $this->get_name());  
     
       $this->box_minimum_css(
            array(
                'title' => esc_html__('Title Wrapper','element-ready-pro'),
                'slug' => '_title_wrapper_style',
                'element_name' => '_title_wrapper_element_ready_',
                'selector' => '{{WRAPPER}} .binduz-er-title',
                'hover_selector' => false,
                'disable_controls' => [
                  'display'
               ]
            )
        );

      $this->text_minimum_css(
         array(
             'title'          => esc_html__('Title','element-ready-pro'),
             'slug'           => '_title__style',
             'element_name'   => '_title_apper_element_ready_',
             'selector'       => '{{WRAPPER}} .binduz-er-title a',
             'hover_selector' => '{{WRAPPER}} .binduz-er-title:hover a',
             'disable_controls' => [
               'dimension','border','bg','display'
            ]
         )
      );


      $this->text_minimum_css(
         array(
            'title' => esc_html__('Content','element-ready-pro'),
            'slug' => 'post_content_style',
            'element_name' => 'post_content_element_ready_',
            'selector' => '{{WRAPPER}} .er-binduz-news-content',
            'hover_selector' => false,
            'condition' => [
               'show_content' => 'yes',
            ],
            'disable_controls' => [
               'alignment','position','display','size','bg'
            ]
         )
     );

     $this->box_css(
      array(

          'title' => esc_html__('Content Inner','element-ready-pro'),
          'slug' => '_contnt_verwr_box_style',
          'element_name' => '_content_ver_wer_wrapper_element_ready_',
          'selector' => '{{WRAPPER}} .binduz-er-item,{{WRAPPER}} .binduz-er-content,{{WRAPPER}} .binduz-er-social-news-item,{{WRAPPER}} .binduz-er-news-slider-content',
          'disable_controls' => [
            'alignment','position','display','size'
         ]
      )
   ); 


      $this->text_minimum_css(
         array(
            'title'            => esc_html__('Meta','element-ready-pro'),
            'slug'             => 'post_date_style',
            'element_name'     => 'post_date_element_ready_',
            'selector'         => '{{WRAPPER}} .binduz-er-meta-item a,{{WRAPPER}} .element-ready-post-meta a',
            'hover_selector'   => '{{WRAPPER}} .binduz-er-meta-item a:hover, {{WRAPPER}} .element-ready-post-meta a:hover',
            'disable_controls' => [
               'alignment','position','display','size','border'
            ]
           
         )
     ); 
    

     $this->text_minimum_css(
            array(
               'title'            => esc_html__('Meta icon','element-ready-pro'),
               'slug'             => 'post_date_icon_style',
               'element_name'     => 'post_date_icon_element_ready_',
               'selector'         => '{{WRAPPER}} .element-ready-post-meta i , {{WRAPPER}} .binduz-er-meta-item i, {{WRAPPER}} .binduz-er-meta-list li i, {{WRAPPER}} .binduz-er-meta-author .binduz-er-meta-list i',
               'hover_selector'   => false,
               'disable_controls' => [
                  'alignment','position','display','size'
               ]
             )
      );
  
      $this->box_css(
         array(
             'title' => esc_html__('Image Meta Wrapper','element-ready-pro'),
             'slug' => '_meta_over_image_wbox_style',
             'element_name' => '_meta_over_img_element_ready_',
             'selector' => '
                  {{WRAPPER}} .er-meta-over-image .element-ready-cat
             ',
             'hover_selector' => false,
             'condition' => [
                'show_meta_over_image' => ['date','cat']
             ],
             'disable_controls' => [
                'size','css','border','bg','box-shadow'
             ]
         )
      );
      $this->text_minimum_css(
         array(
            'title' => esc_html__('Meta Over Image','element-ready-pro'),
            'slug' => '_meta_over_image_box_style',
            'element_name' => '_meta_over_image_element_ready_',
            'condition' => [
               'show_meta_over_image' => ['cat','date']
            ],
            'hover_selector' => '
             
               {{WRAPPER}} .er-meta-over-image .element-ready-cat:hover
            ',
            'selector' => '
              
               {{WRAPPER}} .er-meta-over-image .element-ready-cat
            ',
            'disable_controls' => [
               'display','size','css','dimension'
            ]
           
         )
      );


     $this->text_minimum_css(
         array(

            'title'          => esc_html__('Author text','element-ready-pro'),
            'slug'           => 'posts_author_style',
            'element_name'   => 'posts_author_element_ready_',
            'selector'       => '{{WRAPPER}} .binduz-er-author span ,{{WRAPPER}} .binduz-er-meta-author > span',
            'hover_selector' => '{{WRAPPER}} .binduz-er-author span:hover, {{WRAPPER}} .binduz-er-meta-author > span:hover',
            'condition'      => [
               'show_author'  => 'yes',
               'block_style!' => ['style1']
            ],
         )
      );

      $this->box_minimum_css(
         array(

            'title'        => esc_html__('Author Image','element-ready-pro'),
            'slug'         => '_box_author_image_style',
            'element_name' => '_box_ver_author_image_element_ready_',
            'selector'     => '{{WRAPPER}} .binduz-er-author img,{{WRAPPER}} .binduz-er-meta-author img,{{WRAPPER}} .binduz-post-author img',
            'condition'    => [
               'show_author' => 'yes',
           ],
            
         )
      ); 

      $this->text_minimum_css(
            array(
               'title'          => esc_html__('Author name','element-ready-pro'),
               'slug'           => 'post_author_style',
               'element_name'   => 'post_author_element_ready_',
               'selector'       => '{{WRAPPER}} .binduz-er-author span ,{{WRAPPER}} .binduz-er-meta-author > span, {{WRAPPER}} .binduz-er-author span a,{{WRAPPER}} .binduz-er-meta-author span a,{{WRAPPER}} .binduz-post-author a',
               'hover_selector' => '{{WRAPPER}} .binduz-er-author span:hover, {{WRAPPER}} .binduz-er-meta-author > span:hover,{{WRAPPER}} .binduz-er-author span:hover a, {{WRAPPER}} .binduz-er-meta-author span:hover a',
               'condition'      => [
                  'show_author' => 'yes',
                  
               ],
            )
      );

      $this->text_minimum_css(
         array(
            'title'     => esc_html__('ReadMore','element-ready-pro'),
            'slug'      => '_readmore-right_style',
            'condition' => [
                'show_readmore' => ['yes']
             ],
            'element_name'   => '_readmore_element_ready_',
            'selector'       => '{{WRAPPER}} .er-readmore-btn',
            'hover_selector' => '{{WRAPPER}} .er-readmore-btn:hover',
         )
      );
      

      
      $this->box_minimum_css(
         array(
 
             'title' => esc_html__('Image Wrapper','element-ready-pro'),
             'slug' => '_box_image_box_style',
             'element_name' => '_box_ver_image_wrapper_element_ready_',
             'selector' => '{{WRAPPER}} .binduz-er-thumb',

             'disable_controls' => [
               'bg','display'
            ]
            
         )
      );

      $this->start_controls_section('er_binduz_image_section',
            [
               'label' => esc_html__( 'Image ', 'element-ready-pro' ),
               'tab'   => Controls_Manager::TAB_STYLE,
               
            ]
      );

         $this->add_responsive_control(
            'image_margin',
            [
               'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .er-meta-over-image img'     => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
               ],
            ]
         );

         $this->add_responsive_control(
            'box_image_height',
            [
               'label'      => esc_html__( 'Image height', 'element-ready-pro' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
               
               ],
               
               'selectors' => [
                  '{{WRAPPER}} .er-meta-over-image img'     => 'height: {{SIZE}}{{UNIT}};',
               
               ],
               
            ]
         );
    
         $this->add_responsive_control(
            'box_image_width',
            [
               'label'      => esc_html__( 'Image width', 'element-ready-pro' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
               
               ],
               'selectors' => [
                  '{{WRAPPER}} .er-meta-over-image img'     => 'width: {{SIZE}}{{UNIT}};',
                  
               ],
               
            ]
         ); 

         $this->add_responsive_control(
            'box_image_amax_width',
            [
               'label'      => esc_html__( 'Max width', 'element-ready-pro' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
               
               ],
               'selectors' => [
                  '{{WRAPPER}} .er-meta-over-image img'     => 'max-width: {{SIZE}}{{UNIT}};',
               
               ],
            
            ]
         ); 

         $this->add_responsive_control(
            'img_borders__radius',
            [
               'label'      => esc_html__( 'Image Border radius', 'element-ready-pro' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .er-meta-over-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
                  
               ],
            ]
         );

      $this->end_controls_section();

        $this->text_css(
         array(
            'title'     => esc_html__('Next Nav','element-ready-pro'),
            'slug'      => '_nav_arrow-nestctt_style',
            'condition' => [
                'slider_enable' => ['yes'],
                'show_nav' => ['yes']
             ],
            'element_name'     => '_nav_arrow_element_ready_',
            'selector'         => '{{WRAPPER}} .b-er-pro-news-slider-item-mod .slick-arrow.next',
            'hover_selector'   => '{{WRAPPER}} .b-er-pro-news-slider-item-mod .slick-arrow.next:hover',
            'disable_controls' => [
               'display','box-shadow','css','border','size','alignment'
             ]
         )
      );
      
      $this->text_css(
         array(
            'title'        => esc_html__('Left Nav','element-ready-pro'),
            'slug'         => '_nav_arrow-left_style',
            'element_name' => '_nav_arrow_left_element_ready_',
            'condition' => [
              'slider_enable' => ['yes'],
              'show_nav' => ['yes']
            ],
            'selector'     => '{{WRAPPER}} .b-er-pro-news-slider-item-mod .slick-arrow.prev',
            'hover_selector'     => '{{WRAPPER}} .b-er-pro-news-slider-item-mod .slick-arrow.prev:hover',
            'disable_controls' => [
               'display','box-shadow','css','border','size','alignment'
             ]
         )
      );

    
      
      $this->text_minimum_css(
         array(
            'title'        => esc_html__('Nav Icon','element-ready-pro'),
            'slug'         => '_nav_row-left_style',
            'element_name' => '_nav_arrowleft_element_ready_',
            'condition' => [
              'slider_enable' => ['yes'],
              'show_nav' => ['yes']
            ],
            'selector'     => '{{WRAPPER}} .b-er-pro-news-slider-item-mod .slick-arrow i',
            'hover_selector'     => '{{WRAPPER}} .b-er-pro-news-slider-item-mod .slick-arrow:hover i',
            'disable_controls' => [
               'display','box-shadow','css','position','border','dimension','bg'
             ]
         )
      );

      $this->box_css(
         array(
 
             'title'        => esc_html__('Navigation','element-ready-pro'),
             'slug'         => '_box_navigation_style',
             'element_name' => '_box_ver_navigation_element_ready_',
             'condition' => ['slider_enable' => ['yes']],
             'selector'     => '{{WRAPPER}} .b-er-pro-news-slider-item-mod .slick-arrow',
             'disable_controls' => [
               'display','box-shadow','css','position'
             ]
             
         )
      ); 
  
      $this->box_minimum_css(
        array(

            'title' => esc_html__('Box','element-ready-pro'),
            'slug' => '_box_verwr_box_style',
            'element_name' => '_box_ver_wer_wrapper_element_ready_',
            'selector' => '{{WRAPPER}} .binduz-er-social-news-box,{{WRAPPER}} .binduz-er-latest-news-item,{{WRAPPER}} .binduz-er-featured-item,{{WRAPPER}} .binduz-er-news-viewed-most,{{WRAPPER}} .binduz-er-featured-slider-item .binduz-er-trending-news-list-box,{{WRAPPER}} .binduz-er-news-slider-box',
           
        )
     ); 
      
   

    }

    public function get_slider_controls($settings){

       $return_settings = [
          'slidesToShow'  => 1,
          'show_nav'      => true,
          'autoplay'      => true,
          'autoplaySpeed' => 5000,
          'slide_speed'   => 1500,
          'slide_padding'   => 50,
          'left_icon'   => 'fa fa-angle-left',
          'right_icon'   => 'fa fa-angle-right',
       ]; 

      if(isset($settings['slidesToShow'])){
         $return_settings['slidesToShow'] = $settings['slidesToShow'];  
      }
      if(isset($settings['show_nav'])){
         $return_settings['show_nav'] = $settings['show_nav'] =='yes'?true:false;  
      } 
      
      if(isset($settings['autoplay'])){
         $return_settings['autoplay'] = $settings['autoplay']=='yes'?true:false;  
      }

      if(isset($settings['slider_enable'])){
         $return_settings['slider_enable'] = $settings['slider_enable']=='yes'?true:false;  
      }
      
      if(isset($settings['autoplaySpeed'])){
         $return_settings['autoplaySpeed'] = $settings['autoplaySpeed'];  
      }
      
      if(isset($settings['slide_speed'])){
         $return_settings['slide_speed'] = $settings['slide_speed'];  
      }
      
      if(isset($settings['slide_padding'])){
         $return_settings['slide_padding'] = $settings['slide_padding'];  
      }
      
      if(isset($settings['left_icon']['value'])){
         $return_settings['left_icon'] = $settings['left_icon']['value'];  
      }
      
      if(isset($settings['right_icon']['value'])){
         $return_settings['right_icon'] = $settings['right_icon']['value'];  
      }
    
      return $return_settings;
    }

    protected function render( ) { 

        $settings        = $this->get_settings();
        $post_title_crop = $settings['post_title_crop'];
        $post_count      = $settings['post_count'];
        
         if(is_search()){
               global $wp_query;
               $query = $wp_query;
         }else{
               $data  = new Base_Modal($settings);
               $query = $data->get();
         }

         if(!$query){
            return;  
         }

        ?>

            <?php if($settings['block_style'] =='style1'): ?>
               <div data-layout="<?php echo $settings['block_style']; ?>" class="binduz-er-featured-slider-item b-er-pro-news-slider-item-mod" data-slide-controls='<?php echo json_encode($this->get_slider_controls($settings)); ?>'>
                     <?php while ($query->have_posts()) : $query->the_post(); ?>
                           <div> 
                              <div class="binduz-er-trending-news-list-box">
                                 <?php if(has_post_thumbnail()): ?>
                                    <?php 
                                        $thumb_link  = Group_Control_Image_Size::get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumb_size', $settings );
                                    ?>
                                    <div class="binduz-er-thumb er-meta-over-image">

                                       <a href="<?php the_permalink() ?>">
                                          <img src="<?php echo esc_url( $thumb_link ) ?>" alt="<?php the_title_attribute(); ?>"> 
                                       </a>
                                         
                                       <?php include('parts/meta_over_image.php');  ?>
                                      
                                    </div>
                                 <?php endif; ?>
                                 <div class="binduz-er-content">
                                    <div class="binduz-er-meta-item">
         
                                       <?php include('parts/category.php');  ?>
                                   
                                       <?php include('parts/date.php');  ?>
                                       <?php include('parts/comment.php');  ?>
                                       <?php include('parts/author3.php');  ?>

                                    </div>
                                    <div class="binduz-er-trending-news-list-title">
                                       <?php include('parts/title.php');  ?>
                                    </div>
                                    <?php include('parts/content.php');  ?>

                                    <?php include('parts/readmore.php'); ?>
                                 </div>
                              </div>
                           </div>
                        <?php
                     
                           if($post_count==$query->current_post+1){
                                break;
                           } 
                            endwhile; 
                            wp_reset_postdata();
                        ?>
                     </div>     
               
            <?php endif; ?>
            <?php if( $settings['block_style'] == 'style2'): ?>
             
               <div class="er--qnews-block-container">
                     <div class="binduz-er-news-slider-box b-er-pro-news-slider-item-mod " data-layout="<?php echo $settings['block_style']; ?>" data-slide-controls='<?php echo json_encode($this->get_slider_controls($settings)); ?>'>
                        <div class="er--qnews-block-row">
                           <div class="er--qnews-block-col-lg-6">
                              <div class="binduz-er-news-slider-item">

                                    <?php while ($query->have_posts()) : $query->the_post(); ?>

                                          <?php 
                                             $thumb_link  = Group_Control_Image_Size::get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumb_size', $settings );
                                          ?>
                                          <?php if(has_post_thumbnail()): ?> 
                                             <div class="binduz-er-item er-meta-over-image">
                                                  <a href="<?php the_permalink() ?>">
                                                      <img src="<?php echo esc_url( $thumb_link ) ?>" alt="<?php the_title_attribute(); ?>"> 
                                                   </a>
                                                <?php include('parts/meta_over_image.php');  ?>
                                             </div>
                                          <?php endif; ?>

                                    <?php
                                       endwhile; 
                                       wp_reset_postdata();

                                    ?>
                              </div>
                           </div>
                           <div class="er--qnews-block-col-lg-6">
                         
                                 <div class="binduz-er-news-slider-content-slider">

                                    <?php
                                       while ($query->have_posts()) : $query->the_post(); ?>

                                          <div class="binduz-er-item">
                                             <?php include('parts/top_meta.php');  ?>
                                             <div class="binduz-er-news-slider-content">
                                                   <?php include('parts/title.php');  ?>
                                                   <?php include('parts/content.php');  ?>
                                             </div>
                                             <?php include('parts/meta.php');  ?>
                                             <?php include('parts/readmore.php'); ?>
                                          </div>

                                    <?php
                                             
                                       endwhile; 
                                       wp_reset_postdata();
                                    ?>
                                 </div>
                           </div>
                        </div>
                     </div>
               </div>
         
            <?php endif; ?>

            <?php if($settings['block_style'] =='style3'): ?>
                    <div class="binduz-er-news-viewed-most-slide b-er-pro-news-slider-item-mod " data-slide-controls='<?php echo json_encode($this->get_slider_controls($settings)); ?>'>
                            <?php while ($query->have_posts()) : $query->the_post(); ?>
                                       <div>
                                          <div class="binduz-er-news-viewed-most">
                                             <?php if(has_post_thumbnail()): ?>
                                                <?php 
                                                   $thumb_link  = Group_Control_Image_Size::get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumb_size', $settings );
                                                ?>
                                                <div class="binduz-er-thumb er-meta-over-image">
                                                   <a href="<?php the_permalink() ?>">
                                                      <img src="<?php echo esc_url( $thumb_link ) ?>" alt="<?php the_title_attribute(); ?>"> 
                                                   </a>
                                                   <?php include('parts/meta_over_image.php');  ?>
                                                </div>
                                             <?php endif; ?>
                                             <div class="binduz-er-content">
                                               
                                                <?php include('parts/top_meta.php');  ?>
                                                <?php include('parts/title.php'); ?>
                                                <?php include('parts/content.php');  ?>
                                                <?php include('parts/meta.php');  ?>
                                                <?php include('parts/readmore.php'); ?>

                                             </div>
                                          </div>
                                       </div>
                              <?php
                                    endwhile; 
                                    wp_reset_postdata();
                              ?>
                    </div>    
            <?php endif; ?>
            <?php if( $settings['block_style'] == 'style4' ): ?>
                  
                  <div class="binduz-er-news-slider-2-item b-er-pro-news-slider-item-mod" data-slide-controls='<?php echo json_encode($this->get_slider_controls($settings)); ?>'>
                        <?php while ($query->have_posts()) : $query->the_post(); ?>

                          <div>
                              <div class="binduz-er-news-viewed-most">
                                 <?php if(has_post_thumbnail( )): ?>
                                       <?php 
                                          $thumb_link  = Group_Control_Image_Size::get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumb_size', $settings );
                                       ?>
                                    <div class="binduz-er-thumb er-meta-over-image">
                                       <a href="<?php the_permalink() ?>">
                                          <img src="<?php echo esc_url( $thumb_link ) ?>" alt="<?php the_title_attribute(); ?>"> 
                                       </a>
                                       <?php include('parts/meta_over_image.php');  ?>
                                    </div>
                                 <?php endif; ?>
                                 <div class="binduz-er-content">
                                       <?php include('parts/top_meta.php');  ?>
                                       <?php include('parts/title.php'); ?>
                                       <?php include('parts/content.php');  ?>
                                       <?php include('parts/meta.php');  ?>
                                       <?php include('parts/readmore.php'); ?>
                                 </div>
                              </div>
                        </div>

                        <?php
                           endwhile; 
                           wp_reset_postdata();
                        ?>
                     </div>
                  </div>
              
            <?php endif; ?>
        
            <?php if($settings['block_style'] == 'style6'): ?>
               <div class="binduz-er-video-post b-er-pro-news-slider-item-mod binduz-er-top-news-2-slider binduz-er-news-slider-2-item" data-slide-controls='<?php echo json_encode($this->get_slider_controls($settings)); ?>'>
               <?php while ($query->have_posts()) : $query->the_post(); ?>
                              <div>
                                 <div class="binduz-er-latest-news-item">
                                    <?php if(has_post_thumbnail( )): ?>
                                       <div class="binduz-er-thumb er-meta-over-image">
                                          
                                             <?php 
                                                $thumb_link  = Group_Control_Image_Size::get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumb_size', $settings );
                                             ?>
                                             <a href="<?php the_permalink() ?>">
                                                <img src="<?php echo esc_url( $thumb_link ) ?>" alt="<?php the_title_attribute(); ?>"> 
                                             </a>
                                          <?php include('parts/meta_over_image.php');  ?>

                                          
                                       </div>
                                    <?php endif; ?>
                                    <div class="binduz-er-content">
                                       <?php include('parts/top_meta.php');  ?>
                                       <?php include('parts/title.php'); ?>
                                       <?php include('parts/content.php');  ?>
                                       <?php include('parts/meta.php');  ?>
                                       <?php include('parts/readmore.php'); ?>
                                    </div>
                                 </div>
                              </div>
                        <?php
                           endwhile; 
                           wp_reset_postdata();
                        ?>
                    </div>
            <?php endif; ?>
            <?php if( $settings['block_style'] == 'style7' ): ?>

                        <div class="binduz-er-social-news-box b-er-pro-news-slider-item-mod ">
                           <div class="er--qnews-block-row binduz-er-social-news-slide binduz-er-news-slider-2-item" data-slide-controls='<?php echo json_encode($this->get_slider_controls($settings)); ?>' >
                              <?php while ($query->have_posts()) : $query->the_post(); ?>
                                
                                 <div class="er--qnews-block-col-lg-4">
                                    <div class="binduz-er-social-news-item">
                                          <?php if(has_post_thumbnail( )): ?>
                                             <?php 
                                                $thumb_link  = Group_Control_Image_Size::get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumb_size', $settings );
                                             ?>
                                             <div class="binduz-er-thumb er-meta-over-image">
                                               <a href="<?php the_permalink() ?>">
                                                   <?php include('parts/meta_over_image.php');  ?>
                                                   <img src="<?php echo esc_url( $thumb_link ) ?>" alt="<?php the_title_attribute(); ?>"> 
                                                </a>
                                             </div>   
                                          <?php endif; ?>

                                          <?php include('parts/top_meta.php');  ?>
                                          <?php include('parts/title.php'); ?>
                                          <?php include('parts/meta.php');  ?>
                                          <?php include('parts/content.php');  ?>
                                         
                                          <?php include('parts/readmore.php'); ?>
                                    </div>
                                 </div>
                              <?php
                                 endwhile; 
                                 wp_reset_postdata();
                              ?>
                           </div>
                       </div>

                     
            <?php endif; ?>
          
           
      <?php  
    }

  

    
}