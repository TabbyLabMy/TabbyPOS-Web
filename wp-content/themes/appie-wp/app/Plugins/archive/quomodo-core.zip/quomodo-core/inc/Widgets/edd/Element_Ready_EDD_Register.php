<?php
namespace Element_Ready_Pro\Widgets\edd;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists('Easy_Digital_Downloads') ) {
    return;
}

class Element_Ready_EDD_Register extends Widget_Base {

    public function get_name() {
        return 'Element_Ready_EDD_Register';
    }

    public function get_title() {
        return esc_html__( 'ER Edd Register From', 'element-ready-pro' );
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_keywords() {
        return [ 'EDD', 'Edd Register', 'Register', 'Easy Digital Download' ];
    }
    
    public function get_icon() { 
        return 'eicon-lock-user';
    }

    protected function register_controls() {

        /*--------------------------
            EDD REGISTER FORM
        ----------------------------*/
        $this->start_controls_section(
            'section_edd_register',
            [
                'label' => esc_html__( 'EDD Resiter Form Content', 'element-ready-pro' ),
            ]
        );
            $this->add_control(
                'image',
                [
                   'label'   => esc_html__( 'Register Logo', 'element-ready-pro' ),
                   'type'    => Controls_Manager::MEDIA,
                ]
            );
            $this->add_control(
                'register-title',
                [
                    'label'   => esc_html__( 'Register Title', 'element-ready-pro' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => '',
                    'title'   => esc_html__( 'Enter After Regsiter Title', 'element-ready-pro' ),
                ]
            );
            $this->add_control(
                'url',
                [
                    'label'   => esc_html__( 'After Registration Redirect Url', 'element-ready-pro' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => '',
                    'title'   => esc_html__( 'Enter After Regeistration Redirect Url', 'element-ready-pro' ),
                ]
            );
            $this->add_control(
                'reg_url',
                [
                   'label'   => esc_html__( 'Login Url', 'element-ready-pro' ),
                   'type'    => Controls_Manager::TEXT,
                   'default' => '',
                   'title'   => esc_html__( 'Enter After Login Url', 'element-ready-pro' ),
                ]
            );
        $this->end_controls_section();
        /*----------------------------
            EDD REGISTER FORM
        -----------------------------*/

        /*--------------------------
            TITLE STYLE
        ----------------------------*/
        $this->start_controls_section(
            'top_title_section',
            [
                'label' => __( 'Title', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'top_title_typography',
                    'selector' => '{{WRAPPER}} .element__ready__website__login__register h3',
                ]
            );

            $this->add_control(
                'top_title_color',
                [
                    'label'  => __( 'Color', 'element-ready-pro' ),
                    'type'   => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register h3' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Border:: get_type(),
                [
                    'name'     => 'top_title_border',
                    'label'    => __( 'Border', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} .element__ready__website__login__register h3',
                ]
            );

            $this->add_responsive_control(
                'top_title_margin',
                [
                    'label'      => __( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'default'    => [
                        'top'      => '0',
                        'right'    => '0',
                        'bottom'   => '15',
                        'left'     => '0',
                        'isLinked' => true
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            
            $this->add_responsive_control(
                'top_title_padding',
                [
                    'label'   => __( 'Padding', 'element-ready-pro' ),
                    'type'    => Controls_Manager::DIMENSIONS,
                    'default' => [
                        'top'      => '0',
                        'right'    => '0',
                        'bottom'   => '0',
                        'left'     => '0',
                        'isLinked' => true
                    ],
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__website__login__register h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'custom_top_title_css',
                [
                    'label'     => __( 'Lavel Custom CSS', 'element-ready-pro' ),
                    'type'      => Controls_Manager::CODE,
                    'rows'      => 20,
                    'language'  => 'css',
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register h3' => '{{VALUE}};',
                    ],
                    'separator' => 'before',
                ]
            );
        $this->end_controls_section();
        /*--------------------------
            TITLE STYLE END
        ----------------------------*/

        /*--------------------------
            LOGO STYLE
        ----------------------------*/
        $this->start_controls_section(
            'logo_section',
            [
                'label' => __( 'Logo', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_responsive_control(
                'logo_display',
                [
                    'label'   => __( 'Display', 'element-ready-pro' ),
                    'type'    => Controls_Manager::SELECT,
                    'options' => [
                        'initial'      => __( 'Initial', 'element-ready-pro' ),
                        'block'        => __( 'Block', 'element-ready-pro' ),
                        'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
                        'flex'         => __( 'Flex', 'element-ready-pro' ),
                        'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
                        'none'         => __( 'none', 'element-ready-pro' ),
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .login__form__logo' => 'display: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Border:: get_type(),
                [
                    'name'     => 'logo_border',
                    'label'    => __( 'Border', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} .login__form__logo',
                ]
            );
            $this->add_responsive_control(
                'logo_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .login__form__logo' => 'overflow:hidden;border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',

                    ],
                ]
            );
            $this->add_responsive_control(
                'logo_width',
                [
                    'label'      => __( 'Width', 'element-ready-pro' ),
                    'type'       => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range'      => [
                        'px' => [
                            'min'  => 0,
                            'max'  => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .login__form__logo' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'logo_height',
                [
                    'label'      => __( 'Height', 'element-ready-pro' ),
                    'type'       => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range'      => [
                        'px' => [
                            'min'  => 0,
                            'max'  => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .login__form__logo' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'logo_margin',
                [
                    'label'      => __( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'default'    => [
                        'top'      => '0',
                        'right'    => '0',
                        'bottom'   => '15',
                        'left'     => '0',
                        'isLinked' => true
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .login__form__logo' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'logo_padding',
                [
                    'label'   => __( 'Padding', 'element-ready-pro' ),
                    'type'    => Controls_Manager::DIMENSIONS,
                    'default' => [
                        'top'      => '0',
                        'right'    => '0',
                        'bottom'   => '0',
                        'left'     => '0',
                        'isLinked' => true
                    ],
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .login__form__logo' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'custom_logo_css',
                [
                    'label'     => __( 'Lavel Custom CSS', 'element-ready-pro' ),
                    'type'      => Controls_Manager::CODE,
                    'rows'      => 20,
                    'language'  => 'css',
                    'selectors' => [
                        '{{WRAPPER}} .login__form__logo' => '{{VALUE}};',
                    ],
                    'separator' => 'before',
                ]
            );
        $this->end_controls_section();
        /*--------------------------
            LOGO STYLE END
        ----------------------------*/

        /*---------------------------
            INPUT STYLE
        ----------------------------*/
        $this->start_controls_section(
            'input_style_section',
            [
                'label' => __( 'Inputs', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs( 'tabs_input_style' );
                $this->start_controls_tab(
                    'tab_input_normal',
                    [
                        'label' => __( 'Normal', 'element-ready-pro' ),
                    ]
                );

                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_typography',
                            'selector' => '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea',
                        ]
                    );
                    
                    $this->add_responsive_control(
                        'input_box_height',
                        [
                            'label'      => __( 'Height', 'element-ready-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea' => 'min-height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'input_box_max_height',
                        [
                            'label'      => __( 'Max Height', 'element-ready-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea' => 'max-height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'input_box_width',
                        [
                            'label'      => __( 'Width', 'element-ready-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'input_text_color',
                        [
                            'label'     => __( 'Text Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'default'   => '#79879d',
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea, {{WRAPPER}} ::placeholder' => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                    
                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'input_background_color',
                            'label'    => __( 'Background', 'element-ready-pro' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea'
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'input_border',
                            'selector' => '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} input[type="url"],{{WRAPPER}} textarea',
                        ]
                    );

                    $this->add_responsive_control(
                        'input_radius',
                        [
                            'label'      => __( 'Border Radius', 'element-ready-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%' ],
                            'default'    => [
                                'top'      => '5',
                                'right'    => '5',
                                'bottom'   => '5',
                                'left'     => '5',
                                'isLinked' => false
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea' => 'border-radius : {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );
                    
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_box_shadow',
                            'selector' => '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea',
                        ]
                    );

                    $this->add_responsive_control(
                        'input_box_align',
                        [
                            'label'   => __( 'Align', 'element-ready-pro' ),
                            'type'    => Controls_Manager::CHOOSE,
                            'options' => [
                                'left' => [
                                    'title' => __( 'Left', 'element-ready-pro' ),
                                    'icon'  => 'fa fa-align-left',
                                ],
                                'center' => [
                                    'title' => __( 'None', 'element-ready-pro' ),
                                    'icon'  => 'fa fa-align-center',
                                ],
                                'right' => [
                                    'title' => __( 'Right', 'element-ready-pro' ),
                                    'icon'  => 'fa fa-align-right',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea' => 'float: {{VALUE}};',
                            ],
                            'default'   => '',
                            'separator' => 'before',
                        ]
                    );

                    $this->add_responsive_control(
                        'input_margin',
                        [
                            'label'      => __( 'Margin', 'element-ready-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'default'    => [
                                'top'      => '0',
                                'right'    => '0',
                                'bottom'   => '0',
                                'left'     => '0',
                                'isLinked' => false
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' => 'before',
                        ]
                    );
                    
                    $this->add_responsive_control(
                        'input_padding',
                        [
                            'label'   => __( 'Padding', 'element-ready-pro' ),
                            'type'    => Controls_Manager::DIMENSIONS,
                            'default' => [
                                'top'      => '12',
                                'right'    => '30',
                                'bottom'   => '12',
                                'left'     => '30',
                                'isLinked' => false
                            ],
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' => 'before',
                        ]
                    );

                    $this->add_responsive_control(
                        'custom_input_css',
                        [
                            'label'     => __( 'Input Field CSS', 'element-ready-pro' ),
                            'type'      => Controls_Manager::CODE,
                            'rows'      => 20,
                            'language'  => 'css',
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"],{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="tel"],{{WRAPPER}} input[type="date"],{{WRAPPER}} input[type="url"],{{WRAPPER}} input[type="email"],{{WRAPPER}} input[type="password"],{{WRAPPER}} textarea' => '{{VALUE}};',
                            ],
                            'separator' => 'before',
                        ]
                    );

                $this->end_controls_tab();

                $this->start_controls_tab(
                    'tab_input_focus',
                    [
                        'label' => __( 'Hover & Focus', 'element-ready-pro' ),
                    ]
                );

                    $this->add_control(
                        'input_focus_color',
                        [
                            'label'     => __( 'Text Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'default'   => '#79879d',
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"]:focus,{{WRAPPER}} input[type="text"]:focus,{{WRAPPER}} input[type="tel"]:focus,{{WRAPPER}} input[type="date"]:focus,{{WRAPPER}} input[type="url"]:focus,{{WRAPPER}} input[type="email"]:focus,{{WRAPPER}} input[type="password"]:focus,{{WRAPPER}} input[type="password"]:focus,{{WRAPPER}} textarea:focus' => 'color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'input_focus_background',
                            'label'    => __( 'focus Background', 'element-ready-pro' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} input[type="number"]:focus,{{WRAPPER}} input[type="text"]:focus,{{WRAPPER}} input[type="tel"]:focus,{{WRAPPER}} input[type="date"]:focus,{{WRAPPER}} input[type="url"]:focus,{{WRAPPER}} input[type="email"]:focus,{{WRAPPER}} input[type="password"]:focus,{{WRAPPER}} textarea:focus'
                        ]
                    );
                    
                    $this->add_control(
                        'input_focus_border_color',
                        [
                            'label'     => __( 'Border Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} input[type="number"]:focus,{{WRAPPER}} input[type="text"]:focus,{{WRAPPER}} input[type="tel"]:focus,{{WRAPPER}} input[type="date"]:focus,{{WRAPPER}} input[type="url"]:focus,{{WRAPPER}} input[type="email"]:focus,{{WRAPPER}} input[type="password"]:focus,{{WRAPPER}} textarea:focus' => 'border-color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_focus_box_shadow',
                            'selector' => '{{WRAPPER}} input[type="number"]:focus,{{WRAPPER}} input[type="text"]:focus,{{WRAPPER}} input[type="tel"]:focus,{{WRAPPER}} input[type="date"]:focus,{{WRAPPER}} input[type="url"]:focus,{{WRAPPER}} input[type="email"]:focus,{{WRAPPER}} input[type="password"]:focus,{{WRAPPER}} textarea:focus',
                        ]
                    );

                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();
        /*---------------------------
            INPUT STYLE END
        ----------------------------*/
        
        /*---------------------------
            BUTTON STYLE
        ----------------------------*/
        $this->start_controls_section(
            'button_section_style',
            [
                'label' => __( 'Button', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs( 'tabs_button_style' );
                $this->start_controls_tab(
                    'tab_button_normal',
                    [
                        'label' => __( 'Normal', 'element-ready-pro' ),
                    ]
                );
                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'button_typography',
                            'selector' => '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button',
                        ]
                    );
                    $this->add_control(
                        'button_text_color',
                        [
                            'label'     => __( 'Text Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button' => 'color: {{VALUE}};',
                            ],
                        ]
                    );        
                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'button_background_color',
                            'label'    => __( 'Background', 'element-ready-pro' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button',
                        ]
                    );            
                    $this->add_responsive_control(
                        'button_height',
                        [
                            'label'      => __( 'Height', 'element-ready-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'button_width',
                        [
                            'label'      => __( 'Width', 'element-ready-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );        
                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'button_border',
                            'selector' => '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button',
                        ]
                    );
                    $this->add_responsive_control(
                        'button_radius',
                        [
                            'label'      => __( 'Border Radius', 'element-ready-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%' ],
                            'default'    => [
                                'top'      => '5',
                                'right'    => '5',
                                'bottom'   => '5',
                                'left'     => '5',
                                'isLinked' => false
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );        
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'button_box_shadow',
                            'selector' => '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button',
                        ]
                    );
                    $this->add_responsive_control(
                        'button_margin',
                        [
                            'label'      => __( 'Margin', 'element-ready-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'default'    => [
                                'top'      => '0',
                                'right'    => '0',
                                'bottom'   => '0',
                                'left'     => '0',
                                'isLinked' => false
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' => 'before',
                        ]
                    );        
                    $this->add_responsive_control(
                        'button_padding',
                        [
                            'label'   => __( 'Padding', 'element-ready-pro' ),
                            'type'    => Controls_Manager::DIMENSIONS,
                            'default' => [
                                'top'      => '12',
                                'right'    => '40',
                                'bottom'   => '12',
                                'left'     => '40',
                                'isLinked' => false
                            ],
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' => 'before',
                        ]
                    );        
                    $this->add_control(
                        'button_transition',
                        [
                            'label'      => __( 'Transition', 'element-ready-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0.1,
                                    'max'  => 3,
                                    'step' => 0.1,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => 0.3,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button' => 'transition: {{SIZE}}s;',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'button_floting',
                        [
                            'label'   => __( 'Button Floating', 'element-ready-pro' ),
                            'type'    => Controls_Manager::CHOOSE,
                            'options' => [
                                'left' => [
                                    'title' => __( 'Left', 'element-ready-pro' ),
                                    'icon'  => 'fa fa-align-left',
                                ],
                                'none' => [
                                    'title' => __( 'None', 'element-ready-pro' ),
                                    'icon'  => 'fa fa-align-center',
                                ],
                                'right' => [
                                    'title' => __( 'Right', 'element-ready-pro' ),
                                    'icon'  => 'fa fa-align-right',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button' => 'float: {{VALUE}};',
                            ],
                            'default'   => 'none',
                            'separator' => 'before',
                        ]
                    );
                $this->end_controls_tab();

                $this->start_controls_tab(
                    'tab_button_hover',
                    [
                        'label' => __( 'Hover', 'element-ready-pro' ),
                    ]
                );
                    $this->add_control(
                        'button_hover_color',
                        [
                            'label'     => __( 'Text Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'separator' => 'before',
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"]:hover, {{WRAPPER}} button:hover' => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'button_hover_background',
                            'label'    => __( 'Hover Background', 'element-ready-pro' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'separator' => 'before',
                            'selector' => '{{WRAPPER}} input[type="submit"]:hover, {{WRAPPER}} button:before,{{WRAPPER}} button:hover',
                        ]
                    );
                    $this->add_control(
                        'button_before_hidding',
                        [
                            'label' => __( 'Hover Before Background', 'element-ready-pro' ),
                            'type' => Controls_Manager::HEADING,
                            'separator' => 'before',
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'button_hover_before_background',
                            'label'    => __( 'Hover Before Background', 'element-ready-pro' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'separator' => 'before',
                            'selector' => '{{WRAPPER}} input[type="submit"]:hover:before, {{WRAPPER}} button:hover:before',
                        ]
                    );
                    $this->add_control(
                        'button_hover_border_color',
                        [
                            'label'     => __( 'Border Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'separator' => 'before',
                            'selectors' => [
                                '{{WRAPPER}} input[type="submit"]:hover, {{WRAPPER}} button:hover' => 'border-color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'button_hover_box_shadow',
                            'selector' => '{{WRAPPER}} input[type="submit"]:hover, {{WRAPPER}} button:hover',
                        ]
                    );

                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();
        /*---------------------------
            BUTTON STYLE END
        -----------------------------*/

        /*---------------------------
            BOX STYLE
        ----------------------------*/
        $this->start_controls_section(
            'box_section_style',
            [
                'label' => __( 'Box', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'box_typography',
                    'selector' => '{{WRAPPER}} .element__ready__website__login__register',
                ]
            );
            $this->add_control(
                'box_text_color',
                [
                    'label'     => __( 'Text Color', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Background:: get_type(),
                [
                    'name'     => 'box_background_color',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .element__ready__website__login__register',
                ]
            );
            $this->add_responsive_control(
                'box_height',
                [
                    'label'      => __( 'Height', 'element-ready-pro' ),
                    'type'       => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range'      => [
                        'px' => [
                            'min'  => 0,
                            'max'  => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'box_width',
                [
                    'label'      => __( 'Width', 'element-ready-pro' ),
                    'type'       => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range'      => [
                        'px' => [
                            'min'  => 0,
                            'max'  => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Border:: get_type(),
                [
                    'name'     => 'box_border',
                    'selector' => '{{WRAPPER}} .element__ready__website__login__register',
                ]
            );
            $this->add_responsive_control(
                'box_radius',
                [
                    'label'      => __( 'Border Radius', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%' ],
                    'default'    => [
                        'top'      => '5',
                        'right'    => '5',
                        'bottom'   => '5',
                        'left'     => '5',
                        'isLinked' => false
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Box_Shadow:: get_type(),
                [
                    'name'     => 'box_box_shadow',
                    'selector' => '{{WRAPPER}} .element__ready__website__login__register',
                ]
            );
            $this->add_responsive_control(
                'box_margin',
                [
                    'label'      => __( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'default'    => [
                        'top'      => '0',
                        'right'    => '0',
                        'bottom'   => '0',
                        'left'     => '0',
                        'isLinked' => false
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'box_padding',
                [
                    'label'   => __( 'Padding', 'element-ready-pro' ),
                    'type'    => Controls_Manager::DIMENSIONS,
                    'default' => [
                        'top'      => '12',
                        'right'    => '40',
                        'bottom'   => '12',
                        'left'     => '40',
                        'isLinked' => false
                    ],
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__website__login__register' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'box_align',
                [
                    'label'   => __( 'Box Align', 'element-ready-pro' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-left',
                        ],
                        'center' => [
                            'title' => __( 'None', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-right',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__website__login__register' => 'text-align: {{VALUE}};',
                    ],
                    'default'   => 'none',
                    'separator' => 'before',
                ]
            );
        $this->end_controls_section();
        /*---------------------------
            BOX STYLE END
        -----------------------------*/

    }

    protected function render() {
		$settings         = $this->get_settings_for_display();
		$image            = $this->get_settings( 'image' );
		$redirect_url     = $this->get_settings( 'url' );
		$registration_url = $this->get_settings( 'reg_url' );
        $edd_register_redirect = $redirect_url;
        $is_editor = \Elementor\Plugin::$instance->editor->is_edit_mode();
		$register_title   = $this->get_settings( 'register-title' ); ?>

        <div class="element__ready__website__login__register">
            <?php if ($image['url']): ?>
	            <div class="login__form__logo">
	            	<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo $image['url']; ?>" alt="login-img"></a>
	            </div>
            <?php endif; ?>

            <?php if (! is_user_logged_in() ) : ?>
	            <?php if($register_title): ?>
	            	<h3><?php echo esc_html($register_title);?></h3>
	            <?php endif; ?>
            <?php endif; ?>
   
            <?php include('views/shortcode-register.php') ?>
         
            <?php if ( is_user_logged_in() ) : ?>

            <?php else :?>
	            <?php if ($registration_url) : ?>
	            	<a class="account__signing_register" href="<?php echo esc_attr($registration_url); ?>"><?php esc_html_e('Already Registered ! Login','element-ready-pro'); ?></a>
	            <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php
   }
   protected function content_template() {}
}