<?php
namespace Element_Ready_Pro\Widgets\learnpress;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Element_Ready\Base\Repository\Base_Modal;

if ( ! defined( 'ABSPATH' ) ) exit;
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

class Learnpress_Course extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public $base;

    public function get_name() {
        return 'element-ready-lp-course-block';
    }

    public function get_title() {
        return esc_html__( 'ER Course', 'element-ready-pro' );
    }

    public function get_icon() { 
        return 'eicon-posts-grid';
    }

   public function get_categories() {
      return [ 'element-ready-pro' ];
   }

  
   public function get_script_depends(){
         
         return [
            'element-ready-core',
         ];
   }
   
   public function get_style_depends(){
         
         return [
            'element-ready-grid',
            'element-ready-learnpress'
        ];
   }

    protected function register_controls() {

      
       do_action( 'element_ready_section_general_tab', $this, $this->get_name() );
       do_action( 'element_ready_section_data_exclude_tab', $this , $this->get_name() );  
       do_action( 'element_ready_section_date_filter_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_taxonomy_filter_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_sort_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_sticky_tab', $this , $this->get_name());  
        // Style
          
        $this->start_controls_section('element_ready_style_title_section',
        [
           'label' => esc_html__( 'Title', 'element-ready-pro' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
            $this->add_control(
               'block_title_color',
               [
                  'label'   => esc_html__('Color', 'element-ready-pro'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .signle__blog__content .title a' => 'color: {{VALUE}};',
                  
                  ],
               ]
            );

            $this->add_control(
               'block_title_hv_color',
               [
                  'label'   => esc_html__('Hover color', 'element-ready-pro'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .signle__blog__content .title a:hover' => 'color: {{VALUE}};',
                
                  ],
               ]
            );

            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'post_title_typography',
                  'label'    => esc_html__( 'Typography', 'element-ready-pro' ),
                  'selector' => '{{WRAPPER}} .signle__blog__content .title a',
               ]
            );

            $this->add_responsive_control(
             'title_margin',
             [
                'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                   '{{WRAPPER}} .signle__blog__content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
                ],
             ]
            );

            $this->add_responsive_control(
               'title_padding',
               [
                  'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                     '{{WRAPPER}} .signle__blog__content .title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                  ],
               ]
            );

      $this->end_controls_section();

      $this->start_controls_section('element_ready__post_content_section',
         [
            'label'     => esc_html__( 'Content ', 'element-ready-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
           
         ]
     );

         $this->add_control(
            'block_content_color',
            [
               'label'   => esc_html__('Color', 'element-ready-pro'),
               'type'    => Controls_Manager::COLOR,
               'default' => '',
               
               'selectors' => [
                  '{{WRAPPER}} .signle__blog__content .post-desc' => 'color: {{VALUE}};',
               ],
            ]
         );

        
         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
               'name'     => 'post_content_typography',
               'label'    => esc_html__( 'Typography', 'element-ready-pro' ),
               'selector' => '{{WRAPPER}} .signle__blog__content .post-desc',
            ]
         );
         $this->add_responsive_control(
         'content_margin',
         [
            'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}}  .signle__blog__content .post-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
         );
         $this->add_responsive_control(
            'content_padding',
            [
               'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .signle__blog__content .post-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

      $this->end_controls_section();

      $this->start_controls_section('element_ready_style_pcontent_section',
         [
            'label'     => esc_html__( 'Post meta', 'element-ready-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
         
         ]
     );
  
      $this->add_control(
       'post_meta_date_color',
         [
             'label' => esc_html__('Date color', 'element-ready-pro'),
             'type'  => Controls_Manager::COLOR,
             
             'selectors' => [
                 '{{WRAPPER}} .single__blog__meta .meta__date'    => 'color: {{VALUE}};',
             
             ],
         ]
      ); 
 
       $this->add_group_control(
         Group_Control_Typography:: get_type(),
         [
             'name'     => 'meta_other_typography',
             'label'    => esc_html__( ' Date Typography', 'element-ready-pro' ),
             'selector' => '{{WRAPPER}} .single__blog__meta .meta__date',
           
         ]
      );  

     // author
     
         $this->add_control(
            'post_meta_author_color',
            [
                  'label' => esc_html__('Author color', 'element-ready-pro'),
                  'type'  => Controls_Manager::COLOR,
                  
                  'selectors' => [
                     '{{WRAPPER}} .single__blog__meta .meta__author a'    => 'color: {{VALUE}};',
                  
                  ],
            ]
         ); 

         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                  'name'     => 'meta_author_typography',
                  'label'    => esc_html__( ' Author Typography', 'element-ready-pro' ),
                  'selector' => '{{WRAPPER}} .single__blog__meta .meta__author',
               
            ]
         ); 

     //cat

        $this->add_control(
         'post_category_color',
            [
               'label'     => esc_html__('Category Color', 'element-ready-pro'),
               'type'      => Controls_Manager::COLOR,
               'default'   => '',
               'selectors' => [

                  '{{WRAPPER}} .single__blog__meta .meta__category .cat' => 'color: {{VALUE}};',
            
               ],
            ]
         ); 

         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
               'name'     => 'meta_category_typography',
               'label'    => esc_html__( 'Category Typography', 'element-ready-pro' ),
                'selector' => '{{WRAPPER}} .single__blog__meta .meta__category .cat',
               
            ]
         );

         $this->add_responsive_control(
            'post__meta_margin',
            [
               'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                     '{{WRAPPER}} .single__blog__meta'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );
     
     $this->end_controls_section();
 
      $this->start_controls_section('element_ready_image_section',
         [
            'label' => esc_html__( 'Image', 'element-ready-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );

            $this->add_responsive_control(
            'image_margin',
               [
                  'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                     '{{WRAPPER}} .single__blog__post__thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  ],
               ]
            );

            $this->add_control(
               'post_image_overlay_c_heading',
               [
                  'label'     => esc_html__( 'Overlay color', 'element-ready-pro' ),
                  'type'      => \Elementor\Controls_Manager::HEADING,
                  'separator' => 'before',
               ]
            );
   
         
            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'      => 'post_image_overlay_color',
                  'label'     => esc_html__( 'Background', 'element-ready-pro' ),
                  'types'     => [ 'gradient' ],
                  'selector'  => '{{WRAPPER}} .gradient1::after',
                 
               ]
            );
            
            $this->add_control(
               'post_image_overlay_opecity',
               [
                  'label'      => esc_html__( 'Opacity', 'element-ready-pro' ),
                  'type'       => Controls_Manager::SLIDER,
                  'size_units' => [ 'px' ],
                  'range'      => [
                     'px' => [
                        'min'  => 0,
                        'max'  => 1,
                        'step' => .1,
                     ],
                   
                  ],
                 
                  'selectors' => [
                     '{{WRAPPER}} .single__blog__post__thumb::after' => 'opacity: {{SIZE}};',
                  ],
               ]
            );
  
            $this->add_responsive_control(
               'box_image_height',
               [
                  'label'      => esc_html__( 'Image height', 'element-ready-pro' ),
                  'type'       => Controls_Manager::SLIDER,
                  'size_units' => [ 'px' ,'%' ],
                  'range'      => [
                     'px' => [
                        'min'  => 0,
                        'max'  => 800,
                        'step' => 1,
                     ],
                  
                  ],
               
                  'selectors' => [
                     '{{WRAPPER}} .single__blog__post__thumb img' => 'height: {{SIZE}}{{UNIT}};',
                  ],
               ]
            );

         $this->add_responsive_control(
            'box_image_width',
            [
               'label'      => esc_html__( 'Image Width', 'element-ready-pro' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .single__blog__post__thumb img' => 'width: {{SIZE}}{{UNIT}};',
               ],
            ]
         );
      
          
      $this->end_controls_section();

      $this->start_controls_section('element_ready_single_box_section',
         [
            'label' => esc_html__( 'Post item', 'element-ready-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
   
      $this->add_responsive_control(
         'item_borders_radius',
         [
            'label'      => esc_html__( 'Border radius', 'element-ready-pro' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            
            'selectors' => [
               
               '{{WRAPPER}} .single__blog__post' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
               
            ],
         ]
      );

      $this->add_group_control(
         \Elementor\Group_Control_Box_Shadow:: get_type(),
         [
            'name'     => 'single_post_box_shadow',
            'label'    => esc_html__( 'Box Shadow', 'element-ready-pro' ),
            'selector' => '{{WRAPPER}} .single__blog__post',
         ]
      );
   
      $this->add_group_control(
         \Elementor\Group_Control_Background:: get_type(),
         [
            'name'     => 'single_box_background',
            'label'    => esc_html__( 'Background', 'element-ready-pro' ),
            'types'    => [ 'classic', 'gradient', 'video' ],
            'selector' => '{{WRAPPER}} .single__blog__post,{{WRAPPER}} .signle__blog__content ',
         ]
      );
   
     $this->add_responsive_control(
      'single_box_margin',
      [
         'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
         'type'       => Controls_Manager::DIMENSIONS,
         'size_units' => [ 'px','%'],
         'selectors'  => [
            '{{WRAPPER}} .single__blog__post' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
         ],
      ]
      );

      $this->add_responsive_control(
         'single_box_padding',
         [
            'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .single__blog__post' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
      );

      $this->end_controls_section();

      $this->start_controls_section('element_ready_box_section',
         [
            'label' => esc_html__( ' Section', 'element-ready-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
    
      $this->add_group_control(
			\Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'section_background',
               'label'    => esc_html__( 'Background', 'element-ready-pro' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .main-section',
            ]
        );
        
        $this->add_responsive_control(
         'box_margin',
            [
               'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
               ],
            ]
         );
         $this->add_responsive_control(
            'box_padding',
            [
               'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 
               ],
            ]
         );
      $this->end_controls_section();

      
        $this->start_controls_section('element_ready_readmore_section',
            [
                  'label'     => esc_html__( 'Readmore', 'element-ready-pro' ),
                  'tab'       => Controls_Manager::TAB_STYLE,
                 
            ]
         );

         $this->add_responsive_control(
            'readmore_margin',
                  [
                     'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px','%'],
                     'selectors'  => [
                        '{{WRAPPER}} .readmore__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     ],
                  ]
            );

            $this->add_responsive_control(
                  'readmore_padding',
                     [
                        'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                        '{{WRAPPER}} .readmore__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                     ]
            );

            $this->add_group_control(
                  \Elementor\Group_Control_Border::get_type(),
                  [
                     'name'     => 'readmore_border',
                     'label'    => esc_html__( 'Border', 'element-ready-pro' ),
                     'selector' => '{{WRAPPER}} .readmore__btn',
                     
                  ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background::get_type(),
               [
                  'name'     => 'readmore_background',
                  'label'    => esc_html__( 'Background', 'element-ready-pro' ),
                  'types'    => [ 'classic', 'gradient' ],
                  'selector' => '{{WRAPPER}} .readmore__btn',
               ]
            );

            $this->add_control(
            'readmore_color',
               [
                  'label'     => esc_html__('Color', 'element-ready-pro'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [
                     '{{WRAPPER}} .readmore__btn' => 'color: {{VALUE}};',
               
                  ],
               ]
            ); 

            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                     'name'     => 'readmore_typography',
                     'label'    => esc_html__( 'Typography', 'element-ready-pro' ),
                     'selector' => '{{WRAPPER}} .readmore__btn',
               ]
            );

            $this->add_control(
               'readmore_bottom_border_hide',
               [
                  'label' => esc_html__( 'Border hide', 'element-ready-pro' ),
                  'type' => \Elementor\Controls_Manager::SELECT,
                  'default' => 'solid',
                  'options' => [
                     'block'  => esc_html__( 'Show', 'element-ready-pro' ),
                     'none' => esc_html__( 'None', 'element-ready-pro' ),
                  ],
                  'selectors' => [
                     '{{WRAPPER}} a.readmore__btn:before' => 'display: {{VALUE}};',
               
                  ],
               ]
            );

            $this->add_control(
               'readmore_bottom_border_color',
                  [
                     'label'     => esc_html__('Bottom border Color', 'element-ready-pro'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} a.readmore__btn:before' => 'background: {{VALUE}};',
                  
                     ],
                  ]
            ); 


      $this->end_controls_section();

    }

    protected function render( ) { 
      
        $settings       = $this->get_settings();
        
        $data           = new Base_Modal($settings);
        $data->set_post_type('lp_course');
        $query          = $data->get();
       
        if( !$query ){
          return;  
        }
      
     ?>
      
      
        <!-- Course Start -->
        <section class="element-ready-popular-course-section">
             <div class="course-wrapper">
               <?php while($query->have_posts()) : $query->the_post(); ?>
                     <div class="course-item-1 text-center">
                        <?php

                           $options = get_post_meta( get_the_ID(), 'element_ready_lp_course_options', true );
                           $icon    = '';

                           if(isset( $options['course_icon'] )){

                              if(isset($options['course_icon']['url'])){
                                 $icon = $options['course_icon']['url'];
                              }
                              
                           }
                           
                        ?> 
                        <?php if($icon != ''): ?>
                              <img src="<?php echo esc_url($icon); ?>" />
                        <?php endif; ?>
                        <h4><a href="<?php echo esc_url(get_the_permalink()); ?>"> <?php echo esc_html(get_the_title()); ?> </a></h4>
                     </div>
                  <?php endwhile; ?>
            </div>
        </section>
        <!-- Course End -->


      <?php  
    }
    

    
}