<?php
namespace Element_Ready_Pro\Modules\Blog\Templates;

/**
 *  Blog Single Page Template
 *
 * @since 1.0
 */
class Portfolio extends Base{

    public $tpl_type = 'portfolio';
	
    /**
     * Page Not found
     * @varsion 1.1
     */
	public function register() {

        add_filter( 'single_template', [ $this , '_template_post' ],50 );
        add_action( 'element_ready_act_tpl_portfolio', [ $this , 'dynamic_content' ],50 );
        add_filter( 'theme_er-blog-tpl_templates', [$this,'add_page_template_to_dropdown'],50 );
	}
    /**
    * Add page templates.
    *
    * @param  array  $templates  The list of page templates
    *
    * @return array  $templates  The modified list of page templates
    */
    function add_page_template_to_dropdown( $templates )
    {    
        
        $templates['elementsready_blog'] = __( 'ElementReady', 'element-ready-pro' );
       
        return $templates;
    }
    public function _template_post($template){

        $template_id   = $this->get_active_data();
    
        if( !is_numeric( $template_id ) ){
            return $template;
        }

        if(isset($_GET['ver']) && isset($_GET['elementor-preview']) && is_numeric($_GET['elementor-preview'])){
          
            if(isset($_GET['p']) && 'portfolio'== get_post_type( $_GET['p'] )){
               
                return $template;
            }
        }
      
      
       $template_slug = get_page_template_slug( $template_id );
       $full_width    = ELEMENT_READY_BLOG_MODULE_PATH . '/Templates/portfolio/full-width.php';
       $canvas_width  = ELEMENT_READY_BLOG_MODULE_PATH . '/Templates/portfolio/offcanvas.php';
       $canvas_header_width  = ELEMENT_READY_BLOG_MODULE_PATH . '/Templates/portfolio/full-width-header-footer.php';
     
       if( $template_id > 1 && is_singular( 'portfolio' )){
         
           if($template_slug == 'elementor_canvas' && file_exists($canvas_width)){
               return $canvas_width; 
           }

           if($template_slug == 'elementsready_blog' && file_exists($canvas_header_width)){
               return $canvas_header_width; 
           }
          
           if(file_exists($full_width)){
               return $full_width;
           }
        
       } 

       return $template; 
    }
}