<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Pages;
if ( ! defined( 'ABSPATH' ) ) exit;

Class ER_P_Page {

    public $links = [
        
    ];
    public $edit_links = [
        
    ];
    public $page = 'page_element-ready-pro-shortcode-builder';
    public function register(){

        $this->links[] = [
            'label' => esc_html__('Category','element-ready'), 
            'url' => 'edit-tags.php?taxonomy=er_scb_builder_cat&post_type=erp_scb_builder',
            'class_attr' => '' 
        ];
        $this->links[] = [
            'label' => esc_html__('Regenerate All','element-ready'), 
            'url' => '#', 
            'class_attr' => 'er-element-scb-all-regenerate', 
        ];
        add_action( 'admin_menu' , [$this,'add__page'],12 );
       
        add_action( 'views_edit-erp_scb_builder' , [ $this,'add_sub_links' ], 100); 
        add_action( 'edit_form_after_title', [ $this, 'add_edit_post_sub_links' ], 100, 2 );
   
        
    }

    public function add__page(){
       
        wp_enqueue_style( 'element-ready-grid', ELEMENT_READY_ROOT_CSS .'grid.css' );
        add_submenu_page( null , 'shortcode_settings', 'Shortcode Builder', 'manage_options', 'element-ready-pro-scb', [$this,'settings'] );
        add_submenu_page( 'element_ready_elements_dashboard_page', 'Add Shortcode', 'ShortCode Builder',
        'manage_options', 'edit.php?post_type=erp_scb_builder');
        
        add_submenu_page( null, 'add_shortcode_settings', 'Add New Shortcode', 'manage_options', 'element-ready-pro-scb-add-new', [$this,'add_settings'] );
    }

    public function add_sub_links($post) {
     
        $screen = get_current_screen(); 
            
        if( isset($screen->parent_base) && 'element_ready_elements_dashboard_page' === $screen->parent_base && isset($screen->id) && $screen->id =='edit-erp_scb_builder' )
        {
            wp_enqueue_style( 'element-ready-pro-scbuilder-style', ELEMENT_READY_PRO_BUILDER_URL . 'assets/css/backend.css' ,array(), time());
            require_once( __DIR__ . '/../Templates/view-cpt-links.php' );     
        }

       
    }

    public function add_edit_post_sub_links($post) {
     
        $screen = get_current_screen(); 
        $post_id = $post->ID;
        
        $url = add_query_arg( array(
            'page' => 'element-ready-pro-scb',
            'post_type' => get_post_type($post_id),
            'post_id' => $post_id
        ), admin_url('admin.php') );

        $this->edit_links[] = [
            'label' => esc_html__('Back To List','element-ready-pro'), 
            'url' => admin_url( 'edit.php?post_type=erp_scb_builder' ),
            'class_attr' => '' 
        ];

        $this->edit_links[] = [
            'label' => esc_html__('Go Settings','element-ready-pro'), 
            'url' =>  $url ,
            'class_attr' => '' 
        ];

        if(isset($screen->post_type) && 'erp_scb_builder' == $screen->post_type){
            wp_enqueue_style( 'element-ready-pro-scbuilder-style', ELEMENT_READY_PRO_BUILDER_URL . 'assets/css/backend.css' ,array(), time());
            require_once( __DIR__ . '/../Templates/edit-cpt-links.php' );   
        }
      
    }
    
    public function store(){
       $this->components_options();
    }
 
    public function settings(){
         if(
              isset($_REQUEST[ 'post_type' ]) &&
              $_REQUEST[ 'post_type' ] == 'erp_scb_builder' &&
              isset( $_REQUEST[ 'post_id' ] )
             
            ){
                require_once( __DIR__ .'/..' .'/Templates/er-p-settings.php' );
            }else{
                wp_redirect( $_SERVER['HTTP_REFERER'] );
               
            }
        
           
    } 
    
    public function add_settings(){

       
        require_once( __DIR__ .'/..' .'/Templates/er-add-new.php' );
    }

    public function components_options(){

        
        if ( !isset($_POST['_element_ready_pro_ls_components']) || !wp_verify_nonce($_POST['_element_ready_pro_ls_components'], 'element-ready-pro-ls-components')) {
            wp_redirect($_SERVER["HTTP_REFERER"]);
        }
  
        if( !isset( $_POST['element_ready_pro_license_key'] ) ){
            wp_redirect($_SERVER["HTTP_REFERER"]); 
        }
       // Save
        update_option('element_ready_pro_license_key',$_POST['element_ready_pro_license_key']);
        
        if ( wp_doing_ajax() )
        {
          wp_die();
        }else{
           
            wp_redirect($_SERVER["HTTP_REFERER"]);
        }  
    }
   
    

}
