<?php

  if(\Elementor\Plugin::$instance->editor->is_edit_mode()){

 
        if(!$this->is_active($settings,$this->get_id()) ) {

        echo '<form method="post">';
                echo '<div class="element_ready_pro_protected_content_button_cnt">';
                        echo "<input value=" .$this->get_id(). " type='hidden' name='element-ready-protected-widget-id' />";
                        echo "<input name='element-ready-protected-widget-number' class='element-ready-pro-password-fl' type='text' /> 
                        <button class='element-ready-submit-btn'>" .$submit_text. "</button>";  
                echo "</div>";
            echo "</form>";
           
        }

        ?>

        <?php if($settings['custom_template'] == 'yes'): ?>
            <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $settings['template_id'] ); ?>
        <?php else: ?>
            
            <div class="element-ready-pro-widget-protection">
                <h3 class="element-ready-pro-title"> <?php echo esc_html($settings['title']); ?> </h3> 
                <div class="element-ready-pro-protected-content"> <?php echo esc_html($settings['content']); ?> </div> 
            </div>

        <?php endif; ?>

<?php  }else{ 

   if(!$this->is_active($settings,$this->get_id()) ) {

    echo '<form method="post">';
            echo '<div class="element_ready_pro_protected_content_button_cnt">';
                    echo "<input value=" .$this->get_id(). " type='hidden' name='element-ready-protected-widget-id' />";
                    echo "<input name='element-ready-protected-widget-number' class='element-ready-pro-password-fl' type='text' /> 
                    <button class='element-ready-submit-btn'>" .$submit_text. "</button>";  
            echo "</div>";
        echo "</form>";

        return;
       
    }

    ?>

    <?php if($settings['custom_template'] == 'yes'): ?>
        <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $settings['template_id'] ); ?>
    <?php else: ?>
        
        <div class="element-ready-pro-widget-protection">
            <h3 class="element-ready-pro-title"> <?php echo esc_html($settings['title']); ?> </h3> 
            <div class="element-ready-pro-protected-content"> <?php echo esc_html($settings['content']); ?> </div> 
        </div>

    <?php endif; 

} ?>