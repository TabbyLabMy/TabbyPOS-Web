
         <?php if( $settings[ 'show_meta_over_image' ] == 'cat' ): ?>
            <?php  $categories = get_the_category();
                if(! empty( $categories) ): ?>
                
                <?php echo '<a class="element-ready-cat" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>'; ?>
            
            <?php endif; ?>
        <?php endif; ?>
        <?php if( $settings[ 'show_meta_over_image' ] == 'date' ): ?>
            <?php

                $archive_year  = get_the_time( 'Y' ); 
                $archive_month = get_the_time( 'm' ); 
                $archive_day   = get_the_time( 'd' ); 
                $date_content = 'F j';
                if($settings['er_image_date_format'] !=''){
                    
                    $format_arr = explode(',',$settings['er_image_date_format']);

                    if(is_array($format_arr)){

                        $date_content  = '';
                        foreach($format_arr as $item){
                            $date_content .= '<span>'. get_the_date( $item ) . '</span>';
                        }
                        
                    }else{
                        $date_content  = get_the_date( $settings['er_image_date_format'] );
                    }

                }else{
                    $date_content  = get_the_date( get_option('date_format') );
                }
                

            ?>
                
            <a class="element-ready-cat er-qwr-date" href="<?php echo esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ); ?>">
                <?php 
                    echo wp_kses_post( $date_content );
                 ?>
            </a>

        <?php endif; ?>
    
  
