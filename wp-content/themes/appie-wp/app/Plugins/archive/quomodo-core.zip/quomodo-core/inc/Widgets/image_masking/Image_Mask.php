<?php
namespace Element_Ready_Pro\Widgets\image_masking;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;
use Elementor\Plugin;
use Element_Ready\Controls\Custom_Controls_Manager;
use Element_Ready_Pro\Base\Traits\Helper;

class Image_Mask extends Widget_Base {
    use Helper;
	public function get_name() {
		return 'Element_Ready_Pro_Image_Masking';
	}

	public function get_title() {
		return esc_html__( 'ER Image Masking', 'element-ready-pro' );
	}

	public function get_icon() {
		return 'eicon-featured-image';
	}

	public function get_categories() {
		return [ 'element-ready-pro' ];
	}

	public function get_keywords() {
		return [ 'image', 'image masking', 'masking','mask' ];
	}

    public function get_script_depends() {

        return ['element-ready-core'];
    }
    
    public function get_style_depends() {

        return[];
    }

	protected function register_controls() {

		$this->start_controls_section(
			'section_content_s',
			[
				'label' => esc_html__( 'Settings', 'element-ready-pro' ),
			]
        );

			$this->add_control(
				'image',
				[
					'label' => esc_html__( 'Choose Image', 'element-ready-pro' ),
					'type' => Controls_Manager::MEDIA,
					'show_label' => false,
					
				]
			);

			
			$this->add_group_control(
				\Elementor\Group_Control_Image_Size::get_type(),
				[
					'name' => 'thumbnail',
					'include' => [],
					'default' => 'large',
				]
			);

			$this->add_control(
				'image_text_align',
				[
					'label' => __( 'Alignment', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'element-ready-pro' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elment-ready-pro' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'element-ready-pro' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'toggle' => true,
					'selectors' => [
						'{{WRAPPER}} .element-ready-masking-container' => 'text-align: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'website_link',
				[
					'label' => __( 'Link', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'element-ready-pro' ),
					'show_external' => true,
					
				]
			);
	

		$this->end_controls_section();

		$this->start_controls_section(
			'element_ready_image_mask_style_section',
			[
				'label' => esc_html__( 'Image', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_responsive_control(
			'mask_image_wrap_width',
			[
				'label'      => __( 'Width', 'element-ready-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%','vw' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mask_image_wrap_max_width',
			[
				'label'      => __( 'Max Width', 'element-ready-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%','vw' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);


		
		$this->add_control(
			'mask_image_wrap_height',
			[
				'label'      => __( 'Height', 'element-ready-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'vh' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'element_ready_image_adv_style_tabs'
		);

		$this->start_controls_tab(
			'element_ready_style_normal_tab',
			[
				'label' => __( 'Normal', 'element-ready-pro' ),
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter:: get_type(),
			[
				'name'      => 'element_ready_image_filters',
				'selector'  => '{{WRAPPER}} img',
			]
		);

		$this->add_control(
			'element_ready_img_opacity',
			[
				'label' => __( 'Opacity', 'element-ready-pro' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_control(
			'element_ready_border_radius',
			[
				'label'      => __( 'Border Radius', 'element-ready-pro' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'element_ready_img_border',
				'label'    => __( 'Border', 'element-ready-pro' ),
				'selector' => '{{WRAPPER}} img',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'element_ready_img_box_shadow',
				'selector' => '{{WRAPPER}} img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'element-ready-pro' ),
			]
		);

		
		$this->add_group_control(
			Group_Control_Css_Filter:: get_type(),
			[
				'name'      => 'element_ready_image_filters_hover',
				'selector'  => '{{WRAPPER}} img:hover',
			]
		);

		$this->add_control(
			'element_ready_img_opacity_hover',
			[
				'label' => esc_html__( 'Opacity', 'element-ready-pro' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img:hover' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_control(
			'element_ready_border_radius_hover',
			[
				'label'      => esc_html__( 'Border Radius', 'element-ready-pro' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} img:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'element_ready_img_border_hover',
				'label'    => esc_html__( 'Border', 'element-ready-pro' ),
				'selector' => '{{WRAPPER}} img:hover',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'element_ready_img_box_shadow_hover',
				'selector' => '{{WRAPPER}} img:hover',
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
		$this->start_controls_section(
			'section_image_masking_n',
			[
				'label' => esc_html__( 'Masking', 'element-ready-pro' ),
			]
        );

		$this->add_control(
			'mask_shape',
			[
				'label' => esc_html__( 'Shapes', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => esc_html__( 'Default', 'element-ready-pro' ),
					'custom'  => esc_html__( 'custom', 'element-ready-pro' ),
				],
			]
		);
        
		$this->add_control(
			'mask_shape_default',
			[
				'label' => esc_html__( 'Default Shapes', 'element-ready-pro' ),
				'type' => Custom_Controls_Manager::RADIOIMAGE,
				'condition' => [
					'mask_shape' => 'default',
				],
				'default' => 'style1',
				'options' => $this->masking_image_shapes(),
				'selectors' => [
					'{{WRAPPER}} .element-ready-masking-container' => '-webkit-mask-image: url({{VALUE}}); mask-image: url({{VALUE}});',
				],
			]
        );
	

		$this->add_control(
			'mask_shape_custom',
			[
				'label' => esc_html__( 'Choose Shape', 'element-ready-pro' ),
				'type' => Controls_Manager::MEDIA,
				'show_label' => false,
				'selectors' => [
					'{{WRAPPER}} .element-ready-masking-container' => '-webkit-mask-image: url({{URL}}); mask-image: url({{URL}});',
				],
				'condition' => [
					'mask_shape' => 'custom',
				],
				
			]
		);
	 

	 
		$this->add_control(
			'mask_position',
			[
				'label' => esc_html__( 'Position', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
				   		'center'        => esc_html__( 'Center', 'element-ready-pro' ),
				   		'center center' => esc_html__( 'Center Center', 'element-ready-pro' ),
				   		'center left'   => esc_html__( 'Center Left', 'element-ready-pro' ),
				   		'center right'  => esc_html__( 'Center Right', 'element-ready-pro' ),
				   		'right'         => esc_html__( 'Right', 'element-ready-pro' ),
				   		'top'           => esc_html__( 'Top', 'element-ready-pro' ),
				   		'top center'    => esc_html__( 'Top Center', 'element-ready-pro' ),
				   		'top left'      => esc_html__( 'Top Left', 'element-ready-pro' ),
				   		'top right'     => esc_html__( 'Top Right', 'element-ready-pro' ),
				   		'bottom'        => esc_html__( 'Bottom', 'element-ready-pro' ),
				   		'bottom center' => esc_html__( 'Bottom Center', 'element-ready-pro' ),
				   		'bottom left'   => esc_html__( 'Bottom Left', 'element-ready-pro' ),
				   		'left'          => esc_html__( 'Left', 'element-ready-pro' ),
				   		'bottom right'  => esc_html__( 'Bottom Right', 'element-ready-pro' ),
				],
				'selectors' => [
					'{{WRAPPER}} .element-ready-masking-container' => ' -webkit-mask-position: {{VALUE}}; mask-position: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'mask_size',
			[
				'label' => esc_html__( 'Size', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'auto'    => esc_html__( 'Auto',  'element-ready-pro' ),
					'cover'   => esc_html__( 'Cover',  'element-ready-pro' ),
					'contain' => esc_html__( 'Contain', 'element-ready-pro' ),
					'initial' => esc_html__( 'Custom',  'element-ready-pro' ),
				],
				
				'selectors' => [
					'{{WRAPPER}} .element-ready-masking-container' => '-webkit-mask-size: {{VALUE}}; mask-size: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'mask_custom_size',
			[
				'label' => esc_html__( 'Custom Size', 'element-ready-pro' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', '%', 'vw' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'em' => [
						'min' => 0,
						'max' => 100,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'vw' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 100,
					'unit' => '%',
				],
				'required' => true,
				'selectors' => [
					'{{WRAPPER}} .element-ready-masking-container' => '-webkit-mask-size: {{SIZE}}{{UNIT}}; mask-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'mask_size' => 'initial',
				],
			]
		);

		$this->add_control(
			'mask_repeat',
			[
				'label' => esc_html__( 'Repeat', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'repeat'          => esc_html__( 'Repeat', 'element-ready-pro' ),
					'repeat-x'        => esc_html__( 'Repeat-x', 'element-ready-pro' ),
					'repeat-y'        => esc_html__( 'Repeat-y', 'element-ready-pro' ),
					'space'           => esc_html__( 'Space', 'element-ready-pro' ),
					'round'           => esc_html__( 'Round',  'element-ready-pro' ),
					'no-repeat'       => esc_html__( 'No-repeat', 'element-ready-pro' ),
					'repeat-space'    => esc_html__( 'Repeat Space',  'element-ready-pro' ),
					'round-space'     => esc_html__( 'Round Space',  'element-ready-pro' ),
					'no-repeat-round' => esc_html__( 'No-repeat Round', 'element-ready-pro' ),
				],
				'selectors' => [
					'{{WRAPPER}} .element-ready-masking-container' => '-webkit-mask-repeat: {{VALUE}}; mask-repeat: {{VALUE}};',
				],
			]
		);
	
	  
   
     
		$this->end_controls_section();
	}

	protected function render() {

		$settings  = $this->get_settings_for_display();
		
	
		
		$this->add_render_attribute(
			'wrapper_link',
			[
				'href' => $settings['website_link']['url'],
				'class' => [ 'element-ready-wrapper-link', $settings['website_link']['custom_attributes'] ],
				'rel' => $settings['website_link']['nofollow']!=''?'nofollow':'',
				'target' => $settings['website_link']['is_external']=='on'?'_blank':'_self',
			]
		);
       ?>
     
			<div class="element-ready-masking-container"> 
				<?php if($settings['website_link']['url'] !=''): ?>
					<a <?php echo $this->get_render_attribute_string( 'wrapper_link' ); ?> >
				<?php endif; ?>
					<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'image' ); ?>
						<?php if($settings['website_link']['url'] !=''): ?>
					</a>
			<?php endif; ?>
		</div>
       
       <?php 
	}
}



