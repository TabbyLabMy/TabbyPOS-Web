

    <?php $tag_type = get_post_type($post_id) == 'portfolio'? 'portfolio_tags' : 'post_tag'; ?>
    <?php if( has_term('', $tag_type, $post_id) ) : ?>
        <div class="element-ready-blog-post-tags-container"> 
            <?php if($settings['show_heading'] == 'yes'): ?>
                <h6 class="er-tags-heading">

                    <?php
                        echo element_ready_render_icons($settings['heading_icon'], 'tags--icon');
                        echo '<span>'. esc_html($settings['heading']) .'</span>'; 
                    ?> 

                </h6> 
            <?php endif; ?>
            <div class="element-ready-blog-post-tags-style1"> 
            
                <?php echo get_the_term_list($post_id, $tag_type); ?>
            </div>
        </div>
    <?php endif; ?>


