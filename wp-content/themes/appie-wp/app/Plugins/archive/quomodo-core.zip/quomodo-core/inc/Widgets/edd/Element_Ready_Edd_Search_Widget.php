<?php
namespace Element_Ready_Pro\Widgets\edd;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( !class_exists('Easy_Digital_Downloads') ) {
    return;
}

class Element_Ready_Edd_Search_Widget extends Widget_Base {

	public function get_name() {
		return 'Element_Ready_Edd_Search_Widget';
	}

	public function get_title() {
		return __( 'ER Edd Search Category', 'element-ready-pro' );
	}

	public function get_icon() {
		return 'eicon-search-results';
	}

	public function get_categories() {
		return array('element-ready-pro');
	}

    public function get_keywords() {
        return [ 'EDD', 'Edd Search', 'Search', 'Easy Digital Download' ];
    }

	public function get_script_depends() {
		return['nice-select','nice-select'];
	}

	public function get_style_depends() {
		return['nice-select'];
	}

	protected function register_controls() {

		/******************************
		 * 	CONTENT SECTION
		 ******************************/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'show_category',
				[
					'label'        => __( 'Show Category ?', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'element-ready-pro' ),
					'type'        => Controls_Manager::WYSIWYG,
					'placeholder' => __( 'Title', 'element-ready-pro' ),
					'separator'	=>	'before',
				]
			);
			$this->add_control(
				'title_tag',
				[
					'label'   => __( 'Title HTML Tag', 'elementor' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'h1'   => 'H1',
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'div'  => 'div',
						'span' => 'span',
						'p'    => 'p',
					],
					'default'   => 'h3',
					'condition' => [
						'title!' => '',
					],
				]
			);
			$this->add_control(
				'subtitle',
				[
					'label'       => __( 'Subtitle', 'element-ready-pro' ),
					'type'        => Controls_Manager::TEXTAREA,
					'placeholder' => __( 'Subtitle', 'element-ready-pro' ),
					'separator'	=>	'before',
				]
			);
			$this->add_control(
				'subtitle_position',
				[
					'label'   => __( 'Subtitle Position', 'element-ready-pro' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'after_title',
					'options' => [
						'before_title' => __( 'Before title', 'element-ready-pro' ),
						'after_title'  => __( 'After Title', 'element-ready-pro' ),
					],
					'condition' => [
						'subtitle!' => '',
					]
				]
			);
			$this->add_control(
				'description',
				[
					'label'       => __( 'Description', 'element-ready-pro' ),
					'type'        => Controls_Manager::TEXTAREA,
					'placeholder' => __( 'Description.', 'element-ready-pro' ),
					'separator'	=>	'before',
				]
			);
			$this->add_control(
				'placeholder_text',
				[
					'label'       => __( 'Search Placeholder', 'element-ready-pro' ),
					'type'        => Controls_Manager::TEXT,
					'placeholder' => __( 'Search Product', 'element-ready-pro' ),
					'separator'	=>	'before',
				]
			);
			$this->add_control(
				'show_button',
				[
					'label'        => __( 'Show Button ?', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'separator'	=>	'before',
				]
			);
			$this->add_control(
				'button_text',
				[
					'label'       => __( 'Button Title', 'element-ready-pro' ),
					'type'        => Controls_Manager::TEXT,
					'placeholder' => __( 'Button Text', 'element-ready-pro' ),
					'condition'   => ['show_button' => 'yes'],
					'default'      => 'Search',
				]
			);
			$this->add_control(
				'button_icon',
				[
					'label'       => __( 'Icon', 'element-ready-pro' ),
					'type'        => Controls_Manager::ICONS,
					'label_block' => true,
					'condition'   => ['show_button' => 'yes'],
				]
			);
			$this->add_control(
				'button_icon_align',
				[
					'label'   => __( 'Icon Position', 'element-ready-pro' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'left',
					'options' => [
						'left'  => __( 'Before', 'element-ready-pro' ),
						'right' => __( 'After', 'element-ready-pro' ),
					],
					'condition' => [
						'button_icon!' => '',
					],
				]
			);
			$this->add_control(
				'button_icon_indent',
				[
					'label' => __( 'Icon Spacing', 'element-ready-pro' ),
					'type'  => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'max' => 50,
						],
					],
					'condition' => [
						'button_icon!' => '',
					],
					'selectors' => [
						'{{WRAPPER}} .search__btn .search__btn_icon_right' => 'margin-left: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .search__btn .search__btn_icon_left'  => 'margin-right: {{SIZE}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		/*********************************
		 * 		STYLE SECTION
		 *********************************/

		/*----------------------------
			TITLE STYLE
		-----------------------------*/
		$this->start_controls_section(
			'title_style_section',
			[
				'label' => __( 'Title', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' =>[
					'title!' => ''
				],
			]
		);
			$this->add_group_control(
				Group_Control_Typography:: get_type(),
				[
					'name'     => 'title_typography',
					'selector' => '{{WRAPPER}} .box__title',
				]
			);

			// Title Color
			$this->add_control(
				'title_text_color',
				[
					'label'     => __( 'Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .box__title, {{WRAPPER}} .box__title a' => 'color: {{VALUE}};',
					],
				]
			);
			// Title Margin
			$this->add_responsive_control(
				'title_margin',
				[
					'label'      => __( 'Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .box__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		/*----------------------------
			TITLE STYLE END
		-----------------------------*/

		/*----------------------------
			SUBTITLE STYLE
		-----------------------------*/
		$this->start_controls_section(
			'subtitle_style_section',
			[
				'label' => __( 'Subtitle', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' =>[
					'subtitle!' => ''
				],
			]
		);
			$this->add_group_control(
				Group_Control_Typography:: get_type(),
				[
					'name'     => 'subtitle_typography',
					'selector' => '{{WRAPPER}} .box__subtitle',
				]
			);
			$this->add_control(
				'subtitle_color',
				[
					'label'  => __( 'Color', 'element-ready-pro' ),
					'type'   => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .box__subtitle' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'box_hover_subtitle_color',
				[
					'label'  => __( 'Box Hover Color', 'element-ready-pro' ),
					'type'   => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} :hover .box__subtitle' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_responsive_control(
				'subtitle_margin',
				[
					'label'      => __( 'Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .box__subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		/*----------------------------
			SUBTITLE STYLE END
		-----------------------------*/

		/*----------------------------
			FORM STYLE
		-----------------------------*/
		$this->start_controls_section(
			'form_style_section',
			[
				'label' => __( 'Form', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_responsive_control(
				'form_position',
				[
					'label'   => __( 'Position', 'element-ready-pro' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'initial'  => __( 'Initial', 'element-ready-pro' ),
						'absolute' => __( 'Absulute', 'element-ready-pro' ),
						'relative' => __( 'Relative', 'element-ready-pro' ),
						'static'   => __( 'Static', 'element-ready-pro' ),
					],
					'selectors' => [
						'{{WRAPPER}} .download__search__cats__form' => 'position: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Background:: get_type(),
				[
					'name'     => 'form_background',
					'label'    => __( 'Background', 'element-ready-pro' ),
					'types'    => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .download__search__cats__form',
				]
			);
			$this->add_group_control(
				Group_Control_Border:: get_type(),
				[
					'name'     => 'form_border',
					'label'    => __( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .download__search__cats__form',
				]
			);
			$this->add_control(
				'form_radius',
				[
					'label'      => __( 'Border Radius', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .download__search__cats__form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Box_Shadow:: get_type(),
				[
					'name'     => 'form_shadow',
					'selector' => '{{WRAPPER}} .download__search__cats__form',
				]
			);
			$this->add_responsive_control(
				'form_width',
				[
					'label'      => __( 'Width', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .download__search__cats__form' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'form_height',
				[
					'label'      => __( 'Height', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .download__search__cats__form' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'form_hr2',
				[
					'type' => Controls_Manager::DIVIDER,
				]
			);
			$this->add_responsive_control(
				'form_margin',
				[
					'label'      => __( 'Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .download__search__cats__form' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'form_padding',
				[
					'label'      => __( 'Padding', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .download__search__cats__form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'form_transition',
				[
					'label'      => __( 'Transition', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range'      => [
						'px' => [
							'min'  => 0.1,
							'max'  => 3,
							'step' => 0.1,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .download__search__cats__form' => 'transition: {{SIZE}}s;',
					],
				]
			);
		$this->end_controls_section();
		/*----------------------------
			FORM STYLE END
		-----------------------------*/

		/*----------------------------
			CATEGORY STYLE
		-----------------------------*/
		$this->start_controls_section(
			'category_style_section',
			[
				'label' => __( 'Category', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' =>[
					'show_category' => 'yes'
				],
			]
		);
			$this->start_controls_tabs( 'category_tab_style' );
				$this->start_controls_tab(
					'category_normal_tab',
					[
						'label' => __( 'Normal', 'element-ready-pro' ),
					]
				);
					$this->add_responsive_control(
						'category_position',
						[
							'label'   => __( 'Position', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'options' => [
								'initial'  => __( 'Initial', 'element-ready-pro' ),
								'absolute' => __( 'Absulute', 'element-ready-pro' ),
								'relative' => __( 'Relative', 'element-ready-pro' ),
								'static'   => __( 'Static', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__cats' => 'position: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'category_display',
						[
							'label'   => __( 'Display', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => 'inline-block',
							
							'options' => [
								'initial'      => __( 'Initial', 'element-ready-pro' ),
								'block'        => __( 'Block', 'element-ready-pro' ),
								'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
								'flex'         => __( 'Flex', 'element-ready-pro' ),
								'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
								'none'         => __( 'none', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__cats' => 'display: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'category_float',
						[
							'label'   => __( 'Float', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'options' => [
								'left'  =>  __( 'Left', 'element-ready-pro' ),
								'right' =>  __( 'Right', 'element-ready-pro' ),
								'none'  =>  __( 'None', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__cats' => 'float:{{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Typography:: get_type(),
						[
							'name'     => 'category_typography',
							'selector' => '{{WRAPPER}} .download__search__cats .nice-select.wide',
						]
					);
					$this->add_control(
						'category_normal_hr',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_control(
						'category_color',
						[
							'label'     => __( 'Color', 'element-ready-pro' ),
							'type'      => Controls_Manager::COLOR,
							'default'   => '',
							'selectors' => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'category_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .download__search__cats .nice-select.wide',
						]
					);
					$this->add_control(
						'category_dropdown_hr',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_control(
						'category_dropdown_color',
						[
							'label'     => __( 'Dropdown Color', 'element-ready-pro' ),
							'type'      => Controls_Manager::COLOR,
							'default'   => '',
							'selectors' => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide li' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'category_dropdown_background',
							'label'    => __( 'Dropdown Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .download__search__cats .nice-select.wide li',
						]
					);


					$this->add_group_control(
						Group_Control_Border:: get_type(),
						[
							'name'     => 'category_border',
							'label'    => __( 'Border', 'element-ready-pro' ),
							'selector' => '{{WRAPPER}} .download__search__cats .nice-select.wide',
						]
					);
					$this->add_control(
						'category_radius',
						[
							'label'      => __( 'Border Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Box_Shadow:: get_type(),
						[
							'name'     => 'category_shadow',
							'selector' => '{{WRAPPER}} .download__search__cats .nice-select.wide',
						]
					);
					$this->add_control(
						'category_hr',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_responsive_control(
						'category_width',
						[
							'label'      => __( 'Width', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'size' => 140,
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide' => 'min-width: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'category_height',
						[
							'label'      => __( 'Height', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide' => 'height: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'category_hr2',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_responsive_control(
						'category_margin',
						[
							'label'      => __( 'Margin', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'category_padding',
						[
							'label'      => __( 'Padding', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
				$this->end_controls_tab();
				$this->start_controls_tab(
					'category_hover_tab',
					[
						'label' => __( 'Focus', 'element-ready-pro' ),
					]
				);
					$this->add_control(
						'hover_category_color',
						[
							'label'     => __( 'Color', 'element-ready-pro' ),
							'type'      => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide:hover,{{WRAPPER}} .download__search__cats .nice-select.wide:focus' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'hover_category_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .download__search__cats .nice-select.wide:hover,{{WRAPPER}} .download__search__cats .nice-select.wide:focus',
						]
					);
					$this->add_control(
						'category_dropdown_hover_hr',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_control(
						'hover_category_dropdown_color',
						[
							'label'     => __( 'Dropdown Color', 'element-ready-pro' ),
							'type'      => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide .option:hover, {{WRAPPER}} .download__search__cats .nice-select.wide .option.focus, {{WRAPPER}} .download__search__cats .nice-select.wide .option.selected.focus' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'hover_category_dropdown_background',
							'label'    => __( 'Dropdown Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .download__search__cats .nice-select.wide .option:hover, {{WRAPPER}} .download__search__cats .nice-select.wide .option.focus, {{WRAPPER}} .download__search__cats .nice-select.wide .option.selected.focus',
						]
					);
					$this->add_group_control(
						Group_Control_Border:: get_type(),
						[
							'name'     => 'hover_category_border',
							'label'    => __( 'Dropdown Border', 'element-ready-pro' ),
							'selector' => '{{WRAPPER}} .download__search__cats .nice-select.wide .option:hover, {{WRAPPER}} .download__search__cats .nice-select.wide .option.focus, {{WRAPPER}} .download__search__cats .nice-select.wide .option.selected.focus',
						]
					);
					$this->add_control(
						'hover_category_radius',
						[
							'label'      => __( 'Dropdown Border Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .download__search__cats .nice-select.wide .option:hover, {{WRAPPER}} .download__search__cats .nice-select.wide .option.focus, {{WRAPPER}} .download__search__cats .nice-select.wide .option.selected.focus' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
				$this->end_controls_tab();
			$this->end_controls_tabs();
		$this->end_controls_section();
		/*----------------------------
			CATEGORY STYLE END
		-----------------------------*/

		/*----------------------------
			INPUT STYLE
		-----------------------------*/
		$this->start_controls_section(
			'input_style_section',
			[
				'label' => __( 'Input', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
			$this->start_controls_tabs( 'input_tab_style' );
				$this->start_controls_tab(
					'input_normal_tab',
					[
						'label' => __( 'Normal', 'element-ready-pro' ),
					]
				);
					$this->add_responsive_control(
						'input_position',
						[
							'label'   => __( 'Position', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'options' => [
								'initial'  => __( 'Initial', 'element-ready-pro' ),
								'absolute' => __( 'Absulute', 'element-ready-pro' ),
								'relative' => __( 'Relative', 'element-ready-pro' ),
								'static'   => __( 'Static', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__input' => 'position: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'input_display',
						[
							'label'   => __( 'Display', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => 'inline-block',
							
							'options' => [
								'initial'      => __( 'Initial', 'element-ready-pro' ),
								'block'        => __( 'Block', 'element-ready-pro' ),
								'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
								'flex'         => __( 'Flex', 'element-ready-pro' ),
								'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
								'none'         => __( 'none', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__input' => 'display: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'input_float',
						[
							'label'   => __( 'Float', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'options' => [
								'left'  =>  __( 'Left', 'element-ready-pro' ),
								'right' =>  __( 'Right', 'element-ready-pro' ),
								'none'  =>  __( 'None', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__input' => 'float:{{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Typography:: get_type(),
						[
							'name'     => 'input_typography',
							'selector' => '{{WRAPPER}} .download__search__input',
						]
					);
					$this->add_control(
						'normal_hr',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_control(
						'input_color',
						[
							'label'     => __( 'Color', 'element-ready-pro' ),
							'type'      => Controls_Manager::COLOR,
							'default'   => '',
							'selectors' => [
								'{{WRAPPER}} .download__search__input' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'input_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .download__search__input',
						]
					);
					$this->add_group_control(
						Group_Control_Border:: get_type(),
						[
							'name'     => 'input_border',
							'label'    => __( 'Border', 'element-ready-pro' ),
							'selector' => '{{WRAPPER}} .download__search__input',
						]
					);
					$this->add_control(
						'input_radius',
						[
							'label'      => __( 'Border Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .download__search__input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Box_Shadow:: get_type(),
						[
							'name'     => 'input_shadow',
							'selector' => '{{WRAPPER}} .download__search__input',
						]
					);
					$this->add_control(
						'input_hr',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_responsive_control(
						'input_width',
						[
							'label'      => __( 'Width', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__input' => 'width: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'input_height',
						[
							'label'      => __( 'Height', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__input' => 'height: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'input_hr2',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_responsive_control(
						'input_margin',
						[
							'label'      => __( 'Margin', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .download__search__input' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'input_padding',
						[
							'label'      => __( 'Padding', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .download__search__input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'input_align',
						[
							'label'   => __( 'Alignment', 'element-ready-pro' ),
							'type'    => Controls_Manager::CHOOSE,
							'options' => [
								'left' => [
									'title' => __( 'Left', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-left',
								],
								'center' => [
									'title' => __( 'Center', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-center',
								],
								'right' => [
									'title' => __( 'Right', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-right',
								],
								'justify' => [
									'title' => __( 'Justify', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-justify',
								],
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__input' => 'text-align: {{VALUE}};',
							],
							'default' => 'left',
						]
					);
					$this->add_control(
						'input_transition',
						[
							'label'      => __( 'Transition', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px' ],
							'range'      => [
								'px' => [
									'min'  => 0.1,
									'max'  => 3,
									'step' => 0.1,
								],
							],
							'default' => [
								'unit' => 'px',
								'size' => 0.3,
							],
							'selectors' => [
								'{{WRAPPER}} .download__search__input' => 'transition: {{SIZE}}s;',
							],
						]
					);
				$this->end_controls_tab();
				$this->start_controls_tab(
					'input_hover_tab',
					[
						'label' => __( 'Focus', 'element-ready-pro' ),
					]
				);
					$this->add_control(
						'hover_input_color',
						[
							'label'     => __( 'Color', 'element-ready-pro' ),
							'type'      => Controls_Manager::COLOR,
							'selectors' => [
								' {{WRAPPER}} .download__search__input:focus' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'hover_input_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .download__search__input:focus',
						]
					);
					$this->add_group_control(
						Group_Control_Border:: get_type(),
						[
							'name'     => 'hover_input_border',
							'label'    => __( 'Border', 'element-ready-pro' ),
							'selector' => '{{WRAPPER}} .download__search__input:focus',
						]
					);
				$this->end_controls_tab();
			$this->end_controls_tabs();
		$this->end_controls_section();
		/*----------------------------
			INPUT STYLE END
		-----------------------------*/

		/*----------------------------
			BUTTON STYLE
		-----------------------------*/
		$this->start_controls_section(
			'button_style_section',
			[
				'label' => __( 'Button', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' =>[
					'show_button' => 'yes'
				],
			]
		);
			$this->start_controls_tabs( 'button_tab_style' );
				$this->start_controls_tab(
					'button_normal_tab',
					[
						'label' => __( 'Normal', 'element-ready-pro' ),
					]
				);
					$this->add_responsive_control(
						'button_position',
						[
							'label'   => __( 'Position', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'options' => [
								'initial'  => __( 'Initial', 'element-ready-pro' ),
								'absolute' => __( 'Absulute', 'element-ready-pro' ),
								'relative' => __( 'Relative', 'element-ready-pro' ),
								'static'   => __( 'Static', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .search__btn' => 'position: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'button_display',
						[
							'label'   => __( 'Display', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => 'inline-block',
							
							'options' => [
								'initial'      => __( 'Initial', 'element-ready-pro' ),
								'block'        => __( 'Block', 'element-ready-pro' ),
								'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
								'flex'         => __( 'Flex', 'element-ready-pro' ),
								'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
								'none'         => __( 'none', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .search__btn' => 'display: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'button_float',
						[
							'label'   => __( 'Float', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'options' => [
								'left'  =>  __( 'Left', 'element-ready-pro' ),
								'right' =>  __( 'Right', 'element-ready-pro' ),
								'none'  =>  __( 'None', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .search__btn' => 'float:{{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Typography:: get_type(),
						[
							'name'     => 'button_typography',
							'selector' => '{{WRAPPER}} .search__btn',
						]
					);
					$this->add_control(
						'button_color',
						[
							'label'     => __( 'Color', 'element-ready-pro' ),
							'type'      => Controls_Manager::COLOR,
							'default'   => '',
							'selectors' => [
								'{{WRAPPER}} a.search__btn, {{WRAPPER}} .search__btn' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'button_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .search__btn',
						]
					);
					$this->add_group_control(
						Group_Control_Border:: get_type(),
						[
							'name'     => 'button_border',
							'label'    => __( 'Border', 'element-ready-pro' ),
							'selector' => '{{WRAPPER}} .search__btn',
						]
					);
					$this->add_control(
						'button_radius',
						[
							'label'      => __( 'Border Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .search__btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Box_Shadow:: get_type(),
						[
							'name'     => 'button_shadow',
							'selector' => '{{WRAPPER}} .search__btn',
						]
					);
					$this->add_control(
						'button_hr',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_responsive_control(
						'button_width',
						[
							'label'      => __( 'Width', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .search__btn' => 'width: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'button_height',
						[
							'label'      => __( 'Height', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .search__btn' => 'height: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'button_hr2',
						[
							'type' => Controls_Manager::DIVIDER,
						]
					);
					$this->add_responsive_control(
						'button_margin',
						[
							'label'      => __( 'Margin', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .search__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'button_padding',
						[
							'label'      => __( 'Padding', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .search__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
                    $this->add_control(
                        'button_transition',
                        [
                            'label'      => __( 'Transition', 'element-ready-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0.1,
                                    'max'  => 3,
                                    'step' => 0.1,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => 0.3,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .search__btn' => 'transition: {{SIZE}}s;',
                            ],
                        ]
                    );
				$this->end_controls_tab();
				$this->start_controls_tab(
					'button_hover_tab',
					[
						'label' => __( 'Hover', 'element-ready-pro' ),
					]
				);
					$this->add_control(
						'hover_button_color',
						[
							'label'     => __( 'Color', 'element-ready-pro' ),
							'type'      => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .search__btn:hover, {{WRAPPER}} a.search__btn:focus, {{WRAPPER}} .search__btn:focus' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'hover_button_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .search__btn:hover,{{WRAPPER}} .search__btn:focus',
						]
					);
					$this->add_group_control(
						Group_Control_Border:: get_type(),
						[
							'name'     => 'hover_button_border',
							'label'    => __( 'Border', 'element-ready-pro' ),
							'selector' => '{{WRAPPER}} .search__btn:hover,{{WRAPPER}} .search__btn:focus',
						]
					);
					$this->add_control(
						'hover_button_radius',
						[
							'label'      => __( 'Border Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .search__btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_group_control(
						Group_Control_Box_Shadow:: get_type(),
						[
							'name'     => 'hover_button_shadow',
							'selector' => '{{WRAPPER}} .search__btn:hover',
						]
					);
					$this->add_control(
						'button_hover_animation',
						[
							'label'    => __( 'Hover Animation', 'element-ready-pro' ),
							'type'     => Controls_Manager::HOVER_ANIMATION,
							'selector' => '{{WRAPPER}} .search__btn:hover',
						]
					);
				$this->end_controls_tab();
			$this->end_controls_tabs();
		$this->end_controls_section();
		/*----------------------------
			BUTTON STYLE END
		-----------------------------*/

		/*----------------------------
			BOX STYLE
		-----------------------------*/
		$this->start_controls_section(
			'box_style_section',
			[
				'label' => __( 'Box', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography:: get_type(),
				[
					'name'     => 'typography',
					'selector' => '{{WRAPPER}} .download__cat__search__form__wrap',
				]
			);
			$this->add_control(
				'box_color',
				[
					'label'  => __( 'Color', 'element-ready-pro' ),
					'type'   => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .download__cat__search__form__wrap' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_responsive_control(
				'box_align',
				[
					'label'   => __( 'Alignment', 'element-ready-pro' ),
					'type'    => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'element-ready-pro' ),
							'icon'  => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'element-ready-pro' ),
							'icon'  => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'element-ready-pro' ),
							'icon'  => 'fa fa-align-right',
						],
						'justify' => [
							'title' => __( 'Justify', 'element-ready-pro' ),
							'icon'  => 'fa fa-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}}' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();
		/*----------------------------
			BOX STYLE END
		-----------------------------*/
	}
	
	protected function render() {

		$r_id = rand(5655,5874);

		$settings = $this->get_settings_for_display();


		// Button Link Attr
		if ( 'yes' == $settings['show_button'] ) {
			$this->add_render_attribute( 'submit_button', 'class', 'search__btn' );
			if ( !empty( $settings['button_hover_animation'] ) ) {
				$this->add_render_attribute( 'submit_button', 'class', 'elementor-animation-' . $settings['button_hover_animation'] );
			}
			$this->add_render_attribute( 'submit_button', 'type', 'submit' );
		}
		
		// Button animation
		if ( $settings['button_hover_animation'] ) {
			$button_animation = 'elementor-animation-' . $settings['button_hover_animation'];
		}else{
			$button_animation = '';
		}

		// Title Tag
		if ( !empty( $settings['title_tag'] ) ) {
			$title_tag = $settings['title_tag'];
		}else{
			$title_tag = 'div';
		}

		// Title
		if ( !empty( $settings['title'] ) ) {
			$title = '<'.$title_tag.' class="box__title">'.wpautop( $settings['title'] ).'</'.$title_tag.'>';	
		}else{
			$title = '';
		}

		// Subtitle
		if ( !empty( $settings['subtitle'] ) ) {
			$subtitle = '<div class="box__subtitle">'.wpautop( $settings['subtitle'] ).'</div>';
		}else{
			$subtitle = '';
		}

		// Description
		if ( !empty( $settings['description'] ) ) {
			$description = '<div class="box__description">'.wpautop( $settings['description'] ).'</div>';
		}
		
		// Button
		if ( 'yes' == $settings['show_button'] && !empty($settings['button_text'] )  ) {
			$button = '<button '.$this->get_render_attribute_string( 'submit_button' ).'>'. esc_html( $settings['button_text'] ) .'</button>';
		}

		// Button With Icon
		if ( !empty(  $settings['button_icon'] ) ) {
			if (  'left' == $settings['button_icon_align'] ) {
				$button = '<button '.$this->get_render_attribute_string( 'submit_button' ).'>'.element_ready_render_icons($settings['button_icon'], 'search__btn_icon_left'). esc_html( $settings['button_text'] ) .'</button>';
			}elseif( 'right' == $settings['button_icon_align'] ){
				$button = '<button '.$this->get_render_attribute_string( 'submit_button' ).'>'. esc_html( $settings['button_text'] ) .element_ready_render_icons( $settings['button_icon'], 'search__btn_icon_right').'</button>';
			}
		}

		// Title Condition
		if ( 'before_title' == $settings['subtitle_position'] ) {
			$title_subtitle = $subtitle . $title;
		}elseif( 'after_title' == $settings['subtitle_position'] ){
			$title_subtitle = $title . $subtitle;
		}elseif( empty($settings['subtitle']) ){
			$title_subtitle = $title . $subtitle;
		}


		if ( !empty( $settings['placeholder_text'] ) ) {
			$placeholder_text = $settings['placeholder_text'];
		}else{
			$placeholder_text = 'Search Product';
		}

		$search_url = esc_url(home_url('/'));
		$taxonomies = array('download_category');
        $args       = array( 
           'orderby'    => 'count',
           'hide_empty' => true,
           'parent'     => 0,
        );
		$search_terms = element_ready_get_terms_dropdown( $taxonomies, $args );
		$input_value  = ( isset($_GET['s']) ) ? $_GET['s'] : null;

		$form = '
			<form id="download__search__cats__form__'.$r_id.'" method="GET" action="'.$search_url.'" class="download__search__cats__form">
				'.$search_terms.'
				<input class="download__search__input" name="s" value="'.$input_value.'" type="search" placeholder="'.esc_attr( $placeholder_text ).'">
            	<input type="hidden" name="post_type" value="download">
		        '.( isset( $button ) ? $button : '' ).'
			</form>'
		;

		$this->add_render_attribute( 'download-search-attr', 'class', 'download__cat__search__form__wrap' );

		echo'
			<div '.$this->get_render_attribute_string('download-search-attr').'>				
				'.( isset( $title_subtitle ) ? $title_subtitle : '' ).'
				'.( isset( $description ) ? $description : '' ).'
				'.( isset( $form ) ? $form : '' ).'
			</div>
		';
	}

	protected function content_template() {}
}