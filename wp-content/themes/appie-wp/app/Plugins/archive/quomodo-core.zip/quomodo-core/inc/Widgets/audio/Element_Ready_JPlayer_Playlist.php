<?php
namespace Element_Ready_Pro\Widgets\audio;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit;
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

class Element_Ready_JPlayer_Playlist extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;
 
    public $base;

    public function get_name() {
        return 'Element_Ready_Jplayer_Playlist_Widget';
    }
    
    public function get_title() {
        return esc_html__( 'Jplayer Audio Playlist', 'element-ready-pro' );
    }

    public function get_icon() {
        return 'eicon-play-o';
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_keywords() {
        return [ 'jplayer', 'audio', 'podcast' ];
    }

    public function get_script_depends(){

        return [
           'jplayer','jplayer-playlist','element-ready-pro-widget'
        ];

     }
     public function get_style_depends(){
      
        return [
        
           'element-ready-pro-widget'
        ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'element-ready-pro'),
            ]
        );

                $this->add_control(
                    'block_style',
                    [
                        'label' => esc_html__( 'Style', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => 'style2',
                        'options' => [

                            'style1' => esc_html__( 'Style 1', 'element-ready-pro' ),
                            'style2' => esc_html__( 'Style 2', 'element-ready-pro' ),
                        
                        ],
                    ]
                );

            


       $this->end_controls_section();

       $this->start_controls_section(
            'playlist_content_tab',
            [
                'label' => esc_html__('PlayList Content', 'element-ready-pro')
            ]
        );

        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title', [
				'label' => __( 'Title', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'List Title' , 'element-ready-pro' ),
				'label_block' => true,
			]
		);

        $repeater->add_control(
            'mp3',
            [
                'label'       => __( 'Audio Url', 'element-ready-pro' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => 'http://www.jplayer.org/audio/m4a/Miaow-07-Bubble.m4a',
                'placeholder' => __( 'Audio Url', 'element-ready-pro' ),
            ]
        );

		$this->add_control(
			'playlist',
			[
				'label' => __( 'PlayList', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => __( 'Jai Wolf - Indian Summer', 'elment-ready-pro' ),
						'mp3' => 'https://geo-samples.beatport.com/track/f360147d-297a-42f9-8996-d952160b3a30.LOFI.mp3',
					],
					[
						'title' => __( 'Friends', 'element-ready-pro' ),
						'mp3' => 'https://geo-samples.beatport.com/track/0fd1272a-9a9e-4640-a280-f3d147276de3.LOFI.mp3',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

       $this->end_controls_section();
       
       $this->start_controls_section(
            'section_settings_tab',
            [
                'label' => esc_html__('Playlist Settings', 'element-ready-pro'),
            ]
        );

        $this->add_control(
			'enable_audio_title',
			[
				'label'        => __( 'Enable Title', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

        $this->add_control(
			'show_stop_button',
			[
				'label'        => __( 'Stop Button', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

        $this->add_control(
			'show_back_forword_button',
			[
				'label'        => __( 'Back Forword', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

        $this->add_control(
			'show_current_time',
			[
				'label'        => __( 'Current Time', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

        $this->add_control(
			'show_total_duration',
			[
				'label'        => __( 'Total Duration', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

        $this->add_control(
			'remaining_duration',
			[
				'label'        => __( 'Remaining Duration', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition' => [
                    'show_total_duration' => ['yes']
                ]
			]
		);

        $this->add_control(
			'show_volumn',
			[
				'label'        => __( 'Show Volumn', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
        

        $this->add_control(
			'volume',
			[
				'label' => __( 'Default volume', 'element-ready-pro' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
                'condition' => [
                    'show_volumn' => ['yes']
                ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.1,
					],
				
				],
				'default' => [
					'unit' => 'px',
					'size' => 0.6,
				],
			
			]
		);

        $this->add_control(
			'default_mute',
			[
				'label'        => __( 'Default Mute', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'no',
                'condition' => [
                    'show_volumn' => ['yes']
                ],
			]
		);

        $this->add_control(
			'repeat',
			[
				'label'        => __( 'Repeat', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
          	]
		);

        $this->add_control(
			'suffle',
			[
				'label'        => __( 'Suffle', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
          	]
		);

        $this->add_control(
			'progressbar',
			[
				'label'        => __( 'Progressbar', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'element-ready-pro' ),
				'label_off'    => __( 'No', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
          	]
		);

       $this->end_controls_section();

       $this->start_controls_section(
        '_control_section_icon',
        [
            'label' => esc_html__( 'Play Controls Icon', 'element-ready-pro' ),
        ]
    );

    
        $this->add_control(
            'repeat_icon',
            [
                'label' => esc_html__( 'Repeat icon', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-repeat',
                    'library' => 'solid',
                ],
            ]
        );  
     
        $this->add_control(
            'suffle_icon',
            [
                'label' => esc_html__( 'Suffle icon', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-random',
                    'library' => 'solid',
                ],
            ]
        ); 
        
        $this->add_control(
            'forward_icon',
            [
                'label' => esc_html__( 'Forward icon', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-forward',
                    'library' => 'solid',
                ],
            ]
        );

        $this->add_control(
            'backward_icon',
            [
                'label' => esc_html__( 'Backward icon', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-backward',
                    'library' => 'solid',
                ],
            ]
        );
        
        $this->add_control(
            'stop_icon',
            [
                'label' => esc_html__( 'Stop icon', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-stop',
                    'library' => 'solid',
                ],
            ]
        ); 
        
        $this->add_control(
            'pause_icon',
            [
                'label' => esc_html__( 'Pause icon', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-pause',
                    'library' => 'solid',
                ],
            ]
        );
        
        $this->add_control(
            'play_icon',
            [
                'label' => esc_html__( 'Play icon', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-play',
                    'library' => 'solid',
                ],
            ]
        );
        


    $this->end_controls_section();

    $this->start_controls_section(
        'play_icon_style_section',
        [
            'label' => esc_html__( 'Icon Color', 'element-ready-pro' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

            $this->add_control(
                'hover_backgroundcolor',
                [
                    'label' => esc_html__( 'Hover Background', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-jp-audio-play-list .jp-type-playlist .jp-controls-holder button:hover' => 'background: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'backword_color',
                [
                    'label' => esc_html__( 'Backword Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-backward' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'forword_color',
                [
                    'label' => esc_html__( 'Forward Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-forward' => 'color: {{VALUE}}',
                    ],
                ]
            ); 
    
            $this->add_control(
                'play__color',
                [
                    'label' => esc_html__( 'Play Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-play' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'play_hover_color',
                [
                    'label' => esc_html__( 'Play hover Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-play:hover' => 'color: {{VALUE}}',
                    ],
                ]
            ); 
    
            $this->add_control(
                'pause_color',
                [
                    'label' => esc_html__( 'Pause Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-pause' => 'color: {{VALUE}}',
                    ],
                ]
            );
    
            $this->add_control(
                'pause_hover_color',
                [
                    'label' => esc_html__( 'Pause Hover Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-pause:hover' => 'color: {{VALUE}}',
                    ],
                ]
            ); 
    
            $this->add_control(
                'stop_color',
                [
                    'label' => esc_html__( 'Stop Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-stop' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'stop_hover_color',
                [
                    'label' => esc_html__( 'Stop hover Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-stop:hover' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'repeat_color',
                [
                    'label' => esc_html__( 'Repeat Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-repeat' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'suffle_color',
                [
                    'label' => esc_html__( 'Suffle Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .er-suffle' => 'color: {{VALUE}}',
                    ],
                ]
            );


        $this->end_controls_section();


       $this->box_minimum_css(
            array(
                'title'        => esc_html__('Main Container','element-ready-pro'),
                'slug'         => 'wrapper_jp_playlist',
                'element_name' => 'wrapper_ppoplaylist',
                'selector'     => '{{WRAPPER}} .jp-type-playlist',
            )
        ); 
    
        $this->box_minimum_css(
            array(
                'title'        => esc_html__('Playlist','element-ready-pro'),
                'slug'         => 'wrapper_playlist',
                'element_name' => 'wrapper_playlist',
                'selector'     => '{{WRAPPER}} .jp-playlist',
            )
        );   

        $this->text_minimum_css(
            array(
                'title'          => esc_html__('Playlist Item','element-ready-pro'),
                'slug'           => 'wrapper_playlist_ul',
                'element_name'   => 'wrapper_playlist_ul_li',
                'selector'       => '{{WRAPPER}} .er-jp-audio-play-list .jp-type-playlist .jp-playlist ul li a',
                'hover_selector' => false
            )
        );

        $this->text_minimum_css(
            array(
                'title' => esc_html__('Playlist Current Item','element-ready-pro'),
                'slug' => 'wrapper_playlist_ul_cur',
                'element_name' => 'wrapper_playlist_ul_li_cur',
                'selector' => '{{WRAPPER}} .er-jp-audio-play-list .jp-playlist ul li.jp-playlist-current a',
                'hover_selector' => false
            )
        );

        $this->text_minimum_css(
            array(
                'title'          => esc_html__('Title','element-ready-pro'),
                'slug'           => 'wrapper_playlist_title',
                'element_name'   => 'wrapper_playlist_ul_title',
                'selector'       => '{{WRAPPER}} .jp-title',
                'hover_selector' => false
            )
        );

        
        $this->element_size(
            array(
                'title'        => esc_html__('Volumebar Container Size','element-ready-pro'),
                'slug'         => 'wrapper_item_volume_style',
                'element_name' => 'wrapper_item_volumebar',
                'selector'     => '{{WRAPPER}} .jp-volume-bar',
            )
        ); 
        
        $this->box_minimum_css(
            array(
                'title'        => esc_html__('Volume','element-ready-pro'),
                'slug'         => 'wrapper_playlist_voll',
                'element_name' => 'wrapper_playlist_voll',
                'selector'     => '{{WRAPPER}} .jp-volume-bar .jp-volume-bar-value',
            )
        );

        $this->box_minimum_css(
            array(
                'title'        => esc_html__('Audio Porgressbar','element-ready-pro'),
                'slug'         => 'wrapper_playlist_progress',
                'element_name' => 'wrapper_playlist_progress',
                'selector'     => '{{WRAPPER}} .jp-progress',
            )
        );
        
        $this->box_minimum_css(
            array(
                'title'        => esc_html__('Porgress seekbar','element-ready-pro'),
                'slug'         => 'wrapper_playlist_progress_seek',
                'element_name' => 'wrapper_playlist_progress_seek',
                'selector'     => '{{WRAPPER}} .jp-progress .jp-seek-bar',
            )
        ); 
        
        $this->text_minimum_css(
            array(
                'title'        => esc_html__('Duration','element-ready-pro'),
                'slug'         => 'wrapper_playlist_duration',
                'element_name' => 'wrapper_playlist_duration',
                'selector'     => '{{WRAPPER}} .jp-duration',
                'hover_selector' => false
            )
        );
        
        $this->text_minimum_css(
            array(
                'title'        => esc_html__('Current Duration','element-ready-pro'),
                'slug'         => 'wrapper_playlist_cur_duration',
                'element_name' => 'wrapper_playlist_cur_duration',
                'selector'     => '{{WRAPPER}} .jp-current-time',
                'hover_selector' => false
            )
        ); 
        
        $this->box_minimum_css(
            array(
                'title'        => esc_html__('Play Control','element-ready-pro'),
                'slug'         => 'wrapper_playlist_contrls',
                'element_name' => 'wrapper_playlist_control',
                'selector'     => '{{WRAPPER}} .jp-controls',
            )
        );

    }


    protected function render( $instance = [] ) {

        $settings = $this->get_settings_for_display();

        $playlist = $settings['playlist'];
   
    
       ?>
				
            <div
                data-volume="<?php echo esc_attr(isset($settings['volume']['size'])?$settings['volume']['size']:0.2); ?>"
                data-remaining_duration="<?php echo esc_attr($settings['remaining_duration'] == 'yes' ? true : false); ?>"
                data-default_mute="<?php echo esc_attr($settings['default_mute'] == 'yes' ? true : false); ?>"
                data-playlist='<?php echo json_encode($playlist); ?>'
                class="jp-jplayer er-jp-jplayer-list">
            </div>
            <div id="jp-audio-<?php echo esc_attr($this->get_id()); ?>" class="jp-audio er-jp-audio-play-list" role="application" aria-label="media player">
                <div class="jp-type-playlist">
                    <div class="jp-gui">
                        <div class="jp-title-wrapper">
                            <?php if($settings['enable_audio_title'] == 'yes'): ?>
                            <div class="jp-title"></div>
                            <?php endif; ?>
                        </div>
                        <?php if( $settings[ 'show_volumn' ] == 'yes' ): ?>
                        <div class="jp-volume-controls">
                            <button class="jp-mute jp-btn" role="button" tabindex="0">
                                <i class="fal fa-volume"></i>
                                <i class="fal fa-volume-mute"></i>
                            </button>
                            <button class="jp-volume-max" role="button" tabindex="0"> 
                                <i class="fal fa-volume-up"></i>
                                <span class="er-jp-audio-hide">
                                    <?php echo esc_html__('max volume','element-ready-pro'); ?> 
                                </span>
                            </button>
                            <div class="jp-volume-bar">
                                <div class="jp-volume-bar-value"></div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="jp-controls-holder">
                            <div class="jp-controls">
                                <?php if( $settings['show_back_forword_button'] == 'yes'): ?>
                                    <button class="jp-previous jp-btn" role="button" tabindex="0">
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['backward_icon'], [ 'class' => 'er-backward' ] ); ?>  
                                    </button>
                                <?php endif; ?>
                                <button class="jp-play jp-btn" role="button" tabindex="0">
                                    
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['play_icon'], [ 'class' => 'er-play' ] ); ?>  
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['pause_icon'], [ 'class' => 'er-pause' ] ); ?>  
                                </button>
                                <?php if( $settings['show_stop_button'] == 'yes'): ?>
                                    <button class="jp-stop jp-btn" role="button" tabindex="0">
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['stop_icon'], [ 'class' => 'er-stop' ] ); ?>  
                                    </button>
                                <?php endif; ?>
                                <?php if( $settings['show_back_forword_button'] == 'yes'): ?>
                                    <button class="jp-next jp-btn" role="button" tabindex="0">
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['forward_icon'], [ 'class' => 'er-forward' ] ); ?>  
                                    </button>
                                <?php endif; ?>
                            </div>
                            <div class="jp-toggles">
                                <?php if($settings['repeat'] == 'yes'): ?>
                                    <button class="jp-repeat jp-btn" role="button" tabindex="0">
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['repeat_icon'], [ 'class' => 'er-repeat' ] ); ?>  
                                    </button>
                                <?php endif; ?>
                                <?php if($settings['suffle'] == 'yes'): ?>
                                    <button class="jp-shuffle jp-btn" role="button" tabindex="0">
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['suffle_icon'], [ 'class' => 'er-suffle' ] ); ?>  
                                    </button>
                                <?php endif; ?>
                            </div>
                            <?php if( $settings['progressbar'] == 'yes'): ?>
                                <div class="jp-progress">
                                    <div class="jp-seek-bar">
                                        <div class="jp-play-bar"></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="jp-times">
                                <?php if( $settings['show_current_time'] == 'yes' ): ?>
                                    <div class="jp-current-time" role="timer" aria-label="time">&nbsp;</div>
                                <?php endif; ?>
                                <?php if( $settings[ 'show_total_duration' ] == 'yes' ): ?>
                                    <div class="jp-duration" role="timer" aria-label="duration">&nbsp;</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="jp-playlist">
                        <ul>
                            <li>&nbsp;</li>
                        </ul>
                    </div>
                </div>
            </div>
					
			
        <?php
    }
}