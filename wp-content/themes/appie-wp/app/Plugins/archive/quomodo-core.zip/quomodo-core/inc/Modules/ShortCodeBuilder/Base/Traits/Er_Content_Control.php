<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Db_Controls;
use Element_Ready_Pro\Base\Traits\Widget_Controls\Box\ERP_Content_Controls as Preset_ERP_Controls;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * 
 */
trait Er_Content_Control
{
    use Preset_ERP_Controls;
    public $er_post_control = false; 
  	public function _er_init_content(){

       $er_settings = $this->er_get_db_seetings();
       $db_content  = new Db_Controls($this->er_get_db_seetings(),$this->widget_post_id());
       $controls    = $db_content->er_get_content_fields();
   
       if(is_array($controls)){

            $ad_controls = [
				'title' => esc_html__('Content','element-ready'),
				'slug' => '_advanced_content',
				'condition' => '',
				'controls' => [ ]
			];

            foreach($controls as $item){
               
				$title = 'erp_scb_'.$item['control_name'];
                $title = strtolower(preg_replace('/\s+/', '_', $title));

                if( $item['control_type'] == 'content' ) {

					if( $item['control_f_type'] == 'post' ){
						$this->er_post_control = true;
					} 
					// text control
                    if( $item['control_f_type'] == 'text' ){
					
                        $ad_controls['controls'][$title] =  [
                            'label'     => $item[ 'control_Title' ],
                            'type'          => \Elementor\Controls_Manager::TEXT,
                            'default'      => $item['control_default'], 
                        ];
						
                    }

					if( $item['control_f_type'] == 'number' ){
					
                        $ad_controls['controls'][$title] =  [
                            'label'     => $item[ 'control_Title' ],
                            'type'          => \Elementor\Controls_Manager::NUMBER,
                            'default'      => $item['control_default'], 
                        ];
						
                    }
					if( $item['control_f_type'] == 'textarea' ){
					
                        $ad_controls['controls'][$title] =  [
                            'label'     => $item[ 'control_Title' ],
                            'type'          => \Elementor\Controls_Manager::TEXTAREA,
                            'default'      => $item['control_default'], 
                        ];
				    }
					if( $item['control_f_type'] == 'editor' ){
					
                        $ad_controls['controls'][$title] =  [
                            'label'     => $item[ 'control_Title' ],
                            'type'          => \Elementor\Controls_Manager::WYSIWYG,
                            'default'      => $item['control_default'], 
                        ];
				    }
					if( $item['control_f_type'] == 'url' ){
					
                        $ad_controls['controls'][$title] =  [
                            'label'     => $item[ 'control_Title' ],
                            'type'          => \Elementor\Controls_Manager::URL,
                            
                        ];
				    }
					
					if( $item['control_f_type'] == 'media' ){
					
                        $ad_controls['controls'][$title] =  [
                            'label'     => $item[ 'control_Title' ],
                            'type' => \Elementor\Controls_Manager::MEDIA,
							'default' => [
								'url' => \Elementor\Utils::get_placeholder_image_src(),
							],
                            
                        ];
				    }

					if( $item['control_f_type'] == 'icon' ){
						
                        $ad_controls['controls'][$title] =  [
							
								'label' => $item[ 'control_Title' ],
								'type' => \Elementor\Controls_Manager::ICONS,
								'default' => [
									'value' => 'fas fa-star',
									'library' => 'solid',
								],
							
                            
                        ];
				    }
					
					
					if( $item['control_f_type'] == 'date-time' ){
					
                        $ad_controls['controls'][$title] =  [
                            'label'     => $item[ 'control_Title' ],
							'type' => \Elementor\Controls_Manager::DATE_TIME,
							
                            
                        ];
				    }
					
					if( $item['control_f_type'] == 'switch' ){
					
                        $ad_controls['controls'][$title] =  [
                            'label' => $item[ 'control_Title' ],
							'type' => \Elementor\Controls_Manager::SWITCHER,
							'label_on' => esc_html__( 'Show', 'element-ready-pro' ),
							'label_off' => esc_html__( 'Hide', 'element-ready-pro' ),
							'return_value' => 'yes',
							'default' => 'yes',
                            
                        ];
				    }

					if( $item['control_f_type'] == 'select' ){
						
                        $ad_controls['controls'][$title] =  [

							'label' => $item[ 'control_Title' ],
							'type' => \Elementor\Controls_Manager::SELECT,
							'default' => $item['control_default'],
							'options' => $this->get_er_choose_options($item),
                            
                        ];
				    }
					
					if( $item['control_f_type'] == 'select2' ){
						
                        $ad_controls['controls'][$title] =  [

							'label' => $item[ 'control_Title' ],
							'type' => \Elementor\Controls_Manager::SELECT2,
							'multiple' => true,
							'default' => $item['control_default'],
							'options' => $this->get_er_choose_options($item),
                            
                        ];
				    }
                
                }
				
			}
		   
			$this->content_text($ad_controls);

			$this->er_repeater_type_controls($controls);

            if($this->er_post_control){
				do_action( 'element_ready_pro_section_general_grid_tab', $this, $this->get_name() );
				do_action( 'element_ready_section_data_exclude_tab', $this , $this->get_name() );  
				do_action( 'element_ready_section_date_filter_tab', $this , $this->get_name());  
				do_action( 'element_ready_section_taxonomy_filter_tab', $this , $this->get_name());  
				do_action( 'element_ready_section_sort_tab', $this , $this->get_name());  
				do_action( 'element_ready_section_sticky_tab', $this , $this->get_name()); 
			}
			  
	   } 
 	    

	}

 	public function er_repeater_type_controls($controls){

		
		foreach($controls as $item){

			$title = 'erp_scb_'.$item['control_name'];
			$title = strtolower(preg_replace('/\s+/', '_', $title));

			if( $item['control_f_type'] == 'social-repeater' ){

					$this->start_controls_section(
						$title.'social_repeater_type_content_section',
						[
							'label' => ucfirst($item[ 'control_Title' ]),
							'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
						]
					);

							$repeater = new \Elementor\Repeater();

							$repeater->add_control(
								'title', [
									'label' => __( 'Title', 'element-ready-pro' ),
									'type' => \Elementor\Controls_Manager::TEXT,
									'default' => __( 'Brand Title' , 'element-ready-pro' ),
									'label_block' => true,
								]
							);

							$repeater->add_control(
								'icon', [
									'label' => __( 'Icon', 'element-ready-pro' ),
									'type' => \Elementor\Controls_Manager::ICONS,
									'show_label' => false,
								]
							);

							$repeater->add_control(
								'link',
								[
									'label' => __( 'Link', 'element-ready-pro' ),
									'type' => \Elementor\Controls_Manager::URL,
									'placeholder' => __( 'https://your-link.com', 'element-ready-pro' ),
									
								]
							);

							$this->add_control(
								$title,
								[
									'label' => ucfirst($item[ 'control_Title' ]),
									'type' => \Elementor\Controls_Manager::REPEATER,
									'fields' => $repeater->get_controls(),
									'title_field' => '{{{ title }}}',
								]
							);
					

					$this->end_controls_section();

			}elseif( $item['control_f_type'] == 'repeater' ){

				$control_args = isset($item['control_args'])?$item['control_args']:[];
               
				if(is_array($control_args)){
                   
					$this->start_controls_section(
						$title.'_repeatertype_content_section',
						[
							'label' => ucfirst($item[ 'control_Title' ]),
							'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
						]
					);
                        
					    $$title = new \Elementor\Repeater();
						$title_reapter_title = 'erp_scb_qs_repeater_id';
						$$title->add_control(
							  $title_reapter_title, [
								'label' => esc_html__('Auto Title','element-ready-pro'),
								'type' => \Elementor\Controls_Manager::TEXT,
								'show_label' => true,
								'default' => esc_html__('default title','element-ready-pro')
							]
						);

					    foreach($control_args as $k=> $repeater_item){
							
							if($repeater_item['control_type'] == 'icon'){

								$$title->add_control(
									$repeater_item['name'], [
										'label' => $repeater_item['title'],
										'type' => \Elementor\Controls_Manager::ICONS,
										'show_label' => true,
									]
								);
							}

							if($repeater_item['control_type'] == 'text'){
								$wigt_ttile = $repeater_item['name']; 
								$$title->add_control(
									$repeater_item['name'], [
										'label' => $repeater_item['title'],
										'type' => \Elementor\Controls_Manager::TEXT,
										'show_label' => true,
										'default' => isset( $repeater_item['default'] ) ? $repeater_item['default']:''
									]
								);
							}
							
							if($repeater_item['control_type'] == 'number'){
								
								$$title->add_control(
									$repeater_item['name'], [
										'label' => $repeater_item['title'],
										'type' => \Elementor\Controls_Manager::NUMBER,
										'show_label' => true,
										'default' => isset( $repeater_item['default'] ) ? $repeater_item['default']:''
									]
								);
							}
							
							if($repeater_item['control_type'] == 'textarea'){
								
								$$title->add_control(
									$repeater_item['name'], [
										'label' => $repeater_item['title'],
										'type' => \Elementor\Controls_Manager::TEXTAREA,
										'show_label' => true,
										'default' => isset( $repeater_item['default'] ) ? $repeater_item['default']:''
									]
								);
							}
							
							if($repeater_item['control_type'] == 'editor'){
								
								$$title->add_control(
									$repeater_item['name'], [
										'label' => $repeater_item['title'],
										'type' => \Elementor\Controls_Manager::WYSIWYG,
										'show_label' => true,
										'default' => isset( $repeater_item['default'] ) ? $repeater_item['default']:''
									]
								);
							}
							
							if($repeater_item['control_type'] == 'media'){
								
								$$title->add_control(
									$repeater_item['name'], [
										'label' => $repeater_item['title'],
										'type' => \Elementor\Controls_Manager::MEDIA,
										'show_label' => true,
									]
								);
							}
							
							if($repeater_item['control_type'] == 'date-time'){
								
								$$title->add_control(
									$repeater_item['name'], [
										'label' => $repeater_item['title'],
										'type' => \Elementor\Controls_Manager::DATE_TIME,
										'show_label' => true,
										'default' => isset( $repeater_item['default'] ) ? $repeater_item['default']:''
									]
								);
							}
							
							
							if($repeater_item['control_type'] == 'url'){
								
								$$title->add_control(
									$repeater_item['name'], [
										'label' => $repeater_item['title'],
										'type' => \Elementor\Controls_Manager::URL,
										'show_label' => true,
										
									]
								);
							}


						}
						
						$this->add_control(
							$title,
							[
								'label' => ucfirst($item[ 'control_Title' ]),
								'type' => \Elementor\Controls_Manager::REPEATER,
								'fields' => $$title->get_controls(),
								'title_field' => '{{{'. $title_reapter_title .'}}}',
							]
						);
	
					$this->end_controls_section();
				}

				
			}	
	    }
	 } 

	public function er_get_selector($item){

		$selector = '';
		if( isset( $item['control_selector'] ) && $item['control_selector']  !='' ){
			$selector = '{{WRAPPER}} '.$item['control_selector'];  
		}
		return $selector;
	
	}

	public function get_er_choose_options($item){
		$choose_items = [];
	
	     if( isset( $item[ 'control_args' ] ) && is_array( $item[ 'control_args' ] ) ){
			foreach( $item[ 'control_args' ] as $option ){
				$choose_items[$option['id']] = $option['name'];
			}
		 }
		
		return $choose_items;

	}
	
}
  