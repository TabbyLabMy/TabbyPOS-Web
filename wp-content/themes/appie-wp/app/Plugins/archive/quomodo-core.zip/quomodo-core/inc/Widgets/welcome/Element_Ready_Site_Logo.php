<?php
namespace Element_Ready_Pro\Widgets\welcome;

use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Element_Ready_Site_Logo extends Widget_Base {

    public function get_name() {
        return 'Element_Ready_Site_Logo_Widget';
    }
    
    public function get_title() {
        return __( 'ER Site Logo', 'element-ready-pro' );
    }

    public function get_icon() {
        return 'eicon-site-logo';
    }
    
	public function get_categories() {
		return [ 'element-ready-pro' ];
    }
    
    public function get_keywords() {
        return [ 'logo','site logo' ];
    }
  
    protected function register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'element-ready-pro' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

            $this->add_control(
                'enable_link',
                [
                    'label' => esc_html__( 'Enable Link', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'yes', 'element-ready-pro' ),
                    'label_off' => esc_html__( 'no', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

			$this->add_control(
				'text_align',
				[
					'label' => esc_html__( 'Alignment', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => esc_html__( 'Left', 'element-ready-pro' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => esc_html__( 'Center', 'element-ready-pro' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => esc_html__( 'Right', 'element-ready-pro' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'default' => 'left',
					'toggle' => true,
					'selectors' => [
						'{{WRAPPER}}' => 'text-align: {{VALUE}}',
					],
				]
			);

        $this->end_controls_section();

        $this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Image', 'element-ready-pro' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$this->start_controls_tabs(
			'style_tabs'
		);
		
			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'element-ready-pro' ),
				]
			);

			$this->add_control(
				'max_width',
				[
					'label' => esc_html__( 'Max Width', 'element-ready-pr' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} img' => 'max-width: {{SIZE}}{{UNIT}};',
					],
				]
			);
	
			$this->add_control(
				'max_height',
				[
					'label' => esc_html__( 'Max Height', 'element-ready-pr' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} img' => 'max-height: {{SIZE}}{{UNIT}};',
					],
				]
			);
	
			$this->add_control(
				'opacity',
				[
					'label' => esc_html__( 'opacity', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1,
							'step' => 0.1,
						],
					
					],
					'selectors' => [
						'{{WRAPPER}} img' => 'opacity: {{SIZE}};',
					],
				]
			);
	
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name'     => 'img_border',
					'label'    => esc_html__( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} img',
				]
			);
	
		
			
			$this->end_controls_tab();

			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'element-ready-pro' ),
				]
			);

			$this->add_control(
				'hover_opacity',
				[
					'label' => esc_html__( 'opacity', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1,
							'step' => 0.1,
						],
					
					],
					'selectors' => [
						'{{WRAPPER}} img:hover' => 'opacity: {{SIZE}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name'     => 'hover_img_border',
					'label'    => esc_html__( 'Hover Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} img:hover',
				]
			);

			$this->add_control(
				'hover_transition',
				[
					'label' => esc_html__( 'Transition', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 10,
							'step' => 0.1,
						],
					
					],
					'selectors' => [
						'{{WRAPPER}} a' => 'transition: all {{SIZE}}s ease-in-out;',
					],
				]
			);
			
			$this->end_controls_tab();
		
		$this->end_controls_tabs();
  

        $this->end_controls_section();
    }

    protected function render( $instance = [] ) {

      $settings = $this->get_settings_for_display();

     ?>
      <?php if($settings['enable_link'] == 'yes'): ?> 
        <a href="<?php echo get_home_url() ?>">
            <img src="<?php echo esc_url( wp_get_attachment_url( get_theme_mod( 'custom_logo' ) ) ) ?>" />
        </a> 
      <?php else: ?>
        <img src="<?php echo esc_url( wp_get_attachment_url( get_theme_mod( 'custom_logo' ) ) ) ?>" />
      <?php endif; ?>
    <?php
    }
}