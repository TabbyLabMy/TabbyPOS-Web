<?php
namespace Element_Ready_Pro\Widgets\wpdefault;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;

require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
if ( ! defined( 'ABSPATH' ) ) exit;

class Element_Ready_WP_Comment extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public function get_name() {
        return 'Element_Ready_Wp_Comment';
    }

    public function get_title() {
        return esc_html__( 'ER WP Comment', 'element-ready-pro' );
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_icon() { 
        return 'eicon-comments';
    }

    protected function register_controls() {

        /*---------------------------
            Nav
        -----------------------------*/
         $this->content_text([
            'title' => esc_html__('Settings','element-ready-pro'),
            'slug' => '_heading_content',
            'condition' => '',
            'controls' => [


                

                'title_hide' =>   [
                    'label' => esc_html__( 'Show title', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => '',
                    'options' => [
                        ''  => esc_html__( 'Yes', 'element-ready-pro' ),
                        'none' => esc_html__( 'No', 'element-ready-pro' ),
                    ],
                    'selectors' => [
                       '{{WRAPPER}} .widget-title' => 'display: {{VALUE}};',
                       '{{WRAPPER}} .widgettitle' => 'display: {{VALUE}};',
                    ],
                ],
               
                'widget_title'=> [
                    'label'   => esc_html__( 'Heading Title', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                ],

                'number'=> [
                    'label'   => esc_html__( 'number', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'default' => 6,
                ],
                
             

            ]
         ]);
        /*---------------------------
            Nav END
        -----------------------------*/

        /*--------------------------
            TITLE STYLE
        ----------------------------*/
        $this->text_css(
            array(
                'title' => esc_html__('Title','element-ready-pro'),
                'slug' => '_title_style',
                'element_name' => 'title_element_ready_',
                'selector' => '{{WRAPPER}} .widget-title,{{WRAPPER}} .widgettitle',
                'hover_selector' => '{{WRAPPER}}.widget-title:hover,{{WRAPPER}} .widgettitle:hover',
                'condition' => [
                    'title_hide' => '',
                ],
            )
        );
        /*--------------------------
            TITLE STYLE END
        ----------------------------*/
       
      
      
        $this->text_css(
            array(
                'title' => esc_html__('Post Title','element-ready-pro'),
                'slug' => 'post_select_style',
                'element_name' => 'post_select_element_ready_',
                'selector' => '{{WRAPPER}} li > a',
                'hover_selector' => '{{WRAPPER}} li > a:hover',
               
            )
        );

        
        $this->text_css(
            array(
                'title' => esc_html__('Author','element-ready-pro'),
                'slug' => 'date_select_style',
                'element_name' => 'date_select_element_ready_',
                'selector' => '{{WRAPPER}}  li span a',
                'hover_selector' => '{{WRAPPER}} li span:hover a',
            )
        );

        $this->text_css(
            array(
                'title' => esc_html__('Item','element-ready-pro'),
                'slug' => 'item_body_box_style',
                'element_name' => 'item_body_element_ready_',
                'selector' => '{{WRAPPER}} li',
            )
        );
        
        $this->box_css(
            array(
                'title' => esc_html__('Wrapper','element-ready-pro'),
                'slug' => 'wrapper_body_box_style',
                'element_name' => 'wrapper_body_element_ready_',
                'selector' => '{{WRAPPER}} ul',
            )
        );

    
    }

    protected function render() {

       $settings         = $this->get_settings();
       $widget_args = [];
       $widget_args['title'] = $settings['widget_title']==''?'':$settings['widget_title']; 
       $widget_args['number'] = $settings['number']; 
     
       ?>

        <div class="element-ready-wp-comment">
            <?php the_widget( 'WP_Widget_Recent_Comments' ,$widget_args); ?>
        </div>
    <?php
    }

    
    protected function content_template() {}
}

