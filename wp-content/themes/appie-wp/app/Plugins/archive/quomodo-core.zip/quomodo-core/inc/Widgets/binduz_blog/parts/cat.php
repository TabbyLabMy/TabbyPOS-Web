  
  <?php if($settings['show_cat'] == 'yes'): ?>
          <?php  $categories = get_the_category();
              if(! empty( $categories)  ): ?>
              <div class="binduz-er-meta-mod binduz-post-cat">
                  <span>
                      <?php if($settings['meta_cat_icon']['library'] !=''): ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['meta_cat_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                      <?php else: ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['meta_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                      <?php endif; ?>
                  </span>
                <?php echo '<a class="element-ready-pro-cat" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>'; ?>
              </div>
          <?php endif; ?>
  <?php endif; ?>