<?php
namespace Element_Ready_Pro\Widgets\learnpress;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Border;


require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

if ( ! defined( 'ABSPATH' ) ) exit;


class Learnpress_Course_Category extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public $base;

    public function get_name() {
        return 'element-ready-lp-course-category';
    }

    public function get_title() {
        return esc_html__( 'ER Learnpress Course Category', 'element-ready-pro' );
    }

    public function get_icon() { 
        return "eicon-theme-builder";
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
     }
  
    
     public function get_script_depends(){
           
           return [
              'element-ready-core'
           ];
     }
     
     public function get_style_depends(){
           
           return [
              'element-ready-learnpress'
          ];
     }

    protected function register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'element-ready-pro'),
            ]
        );

        $this->add_control(
			'layout',
			[
				'label' => esc_html__( 'Style', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'element-ready-pro' ),
					'style2' => esc_html__( 'Style 2', 'element-ready-pro' ),
				
				],
			]
        );
        
       $this->end_controls_section();

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('LearnPress Course Category', 'element-ready-pro'),
            ]
        );

            $this->add_control(
                'title', [
                    'label'       => esc_html__( 'Title', 'element-ready-pro' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'Explore more' , 'element-ready-pro' ),
                    'label_block' => true,
                    'condition' => [ 'layout' => ['style1'] ],
                ]
            );

            $this->add_control(
                'list_enable_content',
                [
                    'label'        => esc_html__( 'Enable count', 'element-ready-pro' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                   
                ]
            );

       
    
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'list_cat',
			[
				'label' => esc_html__( 'Category', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => false,
                'label_block' => true,
				'options' =>  element_ready_get_learnpress_category('course_category') ,
			
			]
		);
       
        $repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );

        $repeater->add_control(
			'list_image',
			[
				'label' => esc_html__( 'Image ', 'element-ready-pro' ),
				'description' => esc_html__( 'Image For Style 2', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				
			]
        );

        $repeater->add_control(
			'list_enable_custom_title',
			[
				'label'        => esc_html__( 'Enable Custom Title', 'element-ready-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
				'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
        );
        
		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Custom Title', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Design & Development' , 'element-ready-pro' ),
				'label_block' => true,
			]
        );

        
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Category List', 'element-ready-pro' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 
        $this->end_controls_section();

       

        $this->box_css(
            array(
               'title' => esc_html__('Title Wrapper','element-ready-pro'),
               'slug' => 'cat_title_w_style',
               'element_name' => 'cat_title_w_element_ready_',
               'selector' => '{{WRAPPER}} .element-ready-title',
            )
        );

        $this->text_css(
            array(
               'title' => esc_html__('Title','element-ready-pro'),
               'slug' => 'cat_title__style',
               'element_name' => 'cat_title_element_ready_',
               'selector' => '{{WRAPPER}} .element-ready-title a',
            )
        );

        $this->text_css(
            array(
               'title' => esc_html__('Content','element-ready-pro'),
               'slug' => 'cat_content__style',
               'element_name' => 'cat_contnt_element_ready_',
               'selector' => '{{WRAPPER}} .element-ready-lp-pcat-item p',
            )
        );

        $this->box_css(
            array(
               'title' => esc_html__('Icon Box','element-ready-pro'),
               'slug' => 'cat_ion__style',
               'element_name' => 'cat_icon_element_ready_',
               'selector' => '{{WRAPPER}} .element-ready-lp-course-thumb',
            )
        );

        $this->text_css(
            array(
               'title' => esc_html__('Icon','element-ready-pro'),
               'slug' => 'cat__icon_style',
               'element_name' => 'cat_icon_element_ready_',
               'selector' => '{{WRAPPER}} .element-ready-lp-course-thumb i',
            )
        );
        
         $this->text_wrapper_css(
            array(
               'title' => esc_html__('Item','element-ready-pro'),
               'slug' => 'content_item_box_style',
               'element_name' => 'content_item_element_ready_',
               'selector' => '{{WRAPPER}} .element-ready-lp-pcat-item',
               'hover_selector' => '{{WRAPPER}} .element-ready-lp-pcat-item:hover',
            )
         );

         $this->start_controls_section('element_ready_categhory_section',
         [
            'label' => esc_html__( 'Item Border Hover', 'element-ready-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
               'name'     => 'element_ready_box_bordrx_shadow',
               'label'    => esc_html__( 'Border', 'element-ready-pro' ),
               'selector' => '{{WRAPPER}} .element-ready-lp-pcat-item:hover::after',
            ]
         );
        $this->end_controls_section();
 

        $this->box_css(
            array(
               'title' => esc_html__('Content Box','element-ready-pro'),
               'slug' => 'content_box_box_style',
               'element_name' => 'content_box_element_ready_',
               'selector' => '{{WRAPPER}} .element-ready-lp-ccat-wrapper',
            )
         );
 
    } //Register control end

    protected function render( ) { 

        $settings      = $this->get_settings();
        $list          = $settings['list'];
        $title         = $settings['title'];
    
        $title_1       = str_replace(['{', '}'], ['<span>', '</span>'], $title);
         
    ?>
        <?php if($settings['layout'] == 'style1'): ?>    
                  
            <div class="element-ready-lp-ccat-wrapper style1">

                <?php foreach($list as $item): ?>
                    <?php if($item['list_cat'] !=''): ?>
                            <div class="element-ready-lp-pcat-item style1">
                                <?php if( $item['list_image']['url'] !='' ): ?>
                                    <div class="element-ready-lp-course-thumb">
                                        <img src="<?php echo esc_url($item['list_image']['url']); ?>" alt="<?php echo esc_html($item['list_title']); ?>">
                                    </div>
                                    
                                <?php endif; ?>
                                <?php if($item['list_icon']['library'] !=''): ?>
                                    <div class="element-ready-lp-course-thumb">
                                        <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </div>
                                <?php endif ?>
                                <?php $category = get_term_by('id', $item['list_cat'], 'course_category'); ?>                                             
                                   
                                <?php if($item['list_enable_custom_title'] == 'yes'): ?>
                                    <h4 class="element-ready-title"><a href="<?php echo esc_url(get_category_link($item['list_cat'])); ?>"> <?php echo esc_html($item['list_title']); ?> </a></h4>
                                <?php else: ?>
                                    <h4 class="element-ready-title"><a href="<?php echo esc_url(get_category_link($item['list_cat'])); ?>"> <?php echo esc_html($category->name); ?> </a></h4>
                                <?php endif; ?>
                                <?php if($settings['list_enable_content'] == 'yes'): ?>
                                    <p> <?php echo sprintf( _n( 'Over %s Course', 'Over %s Courses', $category->count, 'element-ready-pro' ),$category->count ); ?></p>
                                <?php endif; ?>

                            </div>
                    <?php endif; ?>

                <?php endforeach; ?>

            </div>
                 
        <?php endif; ?> 
        <!-- Course End -->
        <?php if( $settings['layout'] == 'style2' ): ?>   
            <!-- Course Start -->
                       
            <div class="element-ready-lp-ccat-wrapper style2">

                <?php foreach($list as $item): ?>
                    <?php if($item['list_cat'] !=''): ?>
                            <div class="element-ready-lp-pcat-item style1">
                                <?php if( $item['list_image']['url'] !='' ): ?>
                                    <div class="element-ready-lp-course-thumb">
                                        <img src="<?php echo esc_url($item['list_image']['url']); ?>" alt="<?php echo esc_html($item['list_title']); ?>">
                                    </div>
                                    
                                <?php endif; ?>
                                <?php if($item['list_icon']['library'] !=''): ?>
                                    <div class="element-ready-lp-course-thumb">
                                        <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </div>
                                <?php endif ?>
                                <?php $category = get_term_by('id', $item['list_cat'], 'course_category'); ?>                                             
                                   
                                <?php if($item['list_enable_custom_title'] == 'yes'): ?>
                                    <h4 class="element-ready-title"><a href="<?php echo esc_url(get_category_link($item['list_cat'])); ?>"> <?php echo esc_html($item['list_title']); ?> </a></h4>
                                <?php else: ?>
                                    <h4 class="element-ready-title"><a href="<?php echo esc_url(get_category_link($item['list_cat'])); ?>"> <?php echo esc_html($category->name); ?> </a></h4>
                                <?php endif; ?>
                                <?php if($settings['list_enable_content'] == 'yes'): ?>
                                    <p> <?php echo sprintf( _n( 'Over %s Course', 'Over %s Courses', $category->count, 'element-ready-pro' ),$category->count ); ?></p>
                                <?php endif; ?>

                            </div>
                    <?php endif; ?>

                <?php endforeach; ?>

            </div>
        <!-- Course End -->
        <?php endif; ?>  
    <?php  

    }
    
    protected function content_template() { }
}