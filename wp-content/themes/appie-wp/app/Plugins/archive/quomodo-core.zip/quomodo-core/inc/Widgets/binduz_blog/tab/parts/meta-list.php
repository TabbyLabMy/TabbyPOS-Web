<?php
        if($settings['show_post_meta'] == 'yes'): 
            echo '<div class="binduz-er-meta-list">';
                    if( $settings['show_comment'] ):
                            if($settings['meta_comment_icon']['library'] !=''): 
                             \Elementor\Icons_Manager::render_icon( $settings['meta_comment_icon'], [ 'aria-hidden' => 'true' ] );
                             endif;
                        echo esc_html(get_comments_number(get_the_ID())) .'</li>';
                    endif;
              
            echo '</div>';
        endif;

?>