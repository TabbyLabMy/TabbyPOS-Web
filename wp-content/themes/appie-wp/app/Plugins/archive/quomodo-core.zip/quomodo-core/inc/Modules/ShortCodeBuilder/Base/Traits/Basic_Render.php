<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Db_Controls;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Template_Engine as er_html_renderer;
use Element_Ready\Base\Repository\Base_Modal;
if ( ! defined( 'ABSPATH' ) ) exit;

trait Basic_Render {

    public $er_widget_controls = [];
  
    public function render(){
      
	   $basic_settings = $this->get_settings_for_display();
       echo $this->_get_widget_html();
      
    }


    public function _get_widget_html(){
       
        $settings = $this->get_er_settings();
        
        $this->er_set_controls();   

        $element_settings         = $this->get_settings_for_display();
        $remove_prefix_fields     = $this->er_remove_prefix_from_fields(false);
        $remove_prefix_fields_arr = $this->er_remove_prefix_from_array_fields(true);
        $remove_prefix_fields     = array_merge($remove_prefix_fields,$remove_prefix_fields_arr);
        
      
        $remove_prefix_fields[ $this->er_repeater_field_type() ] = $this->get_loop_content();

        if($this->get_loop_content_two() !=''){
            $remove_prefix_fields[$this->er_repeater_field_type('content_loop_field_two')] = $this->get_loop_content_two();
        }
        
        // get loop html one
       
        $_er_render = new er_html_renderer();  
        $_er_render->setContent($settings['content_html']); 
        $_er_render->setVars($remove_prefix_fields)
            ->setInjects(array('data'));
        $_er_render->compile();

        return $_er_render->getCompiled();
     
    }

  
    /*
    $type: content_loop_field_two | content_loop_field | post
    return type
    */  
    public function er_repeater_field_type( $type = 'content_loop_field' ){
       
      
       $settings = $this->get_er_settings();
       if(isset($settings[$type])){
         
          return $settings[$type];
       }   
       return false;
    }

    public function get_er_settings(){

        $id = $this->widget_post_id();
        $post_settings = [];
        if($id !=''){
            $post_settings = get_post_meta($id,ELEMENT_READY_PRO_BUILDER_WIDGET_KEY,true);
        }

        return $post_settings;
    }

    public function er_set_controls(){

        $settings         = $this->get_er_settings();
        $element_settings = $this->get_settings_for_display();
       
        if(isset($settings['control_list'])){

            $control_name = array_column($settings['control_list'], 'control_name');

            foreach($settings['control_list'] as $_item){
                $this->er_widget_controls[] = $_item;
            }

        }
    }

    public function er_remove_prefix_from_fields($arr=false){

        $er_arr           = [];
        
        $element_settings = $this->get_settings_for_display();
       
        foreach($element_settings as $key => $item){
            
            if($this->control_startsWith($key,'erp_scb_')){
               
                $new_item = preg_replace('/^erp_scb_/', '', $key,1);
                
                if( !$arr && !is_array($item) ) {
                    $er_arr[$new_item] = $item;
                }elseif( $arr && is_array($item) ){
                   
                    $er_arr[$new_item] = $item;
                }
               
            }   
        }
       
        return $er_arr;

    }

    public function er_remove_prefix_from_array_fields($arr=false){

        $er_arr           = [];
        
        $element_settings = $this->get_settings_for_display();
       
        foreach($element_settings as $key => $item){
            
            if($this->control_startsWith($key,'erp_scb_')){
               
                $new_item = preg_replace('/^erp_scb_/', '', $key,1);
                
                if( is_array($item) ) {
                   
                    if(isset($item['url']) && isset($item['id'])){
                        $er_arr[$new_item] = $item['url'];
                    }
                    if(isset($item['url']) && isset($item['is_external']) && isset($item['nofollow']) ){
                        $er_arr[$new_item] = $item['url'];
                    }
                    if(isset($item['value']) && isset($item['library']) ){
                        if($item['library'] == 'svg'){
                            $svg_url =  $item['value']['url'];
                            $er_arr[$new_item] = "<img src=".$svg_url." />";
                        }else{
                            $icon_class = $item['value'];
                            $er_arr[$new_item] = "<i class='".$icon_class."'></i>" ;
                        }
                        
                    }
                 
                }
               
            }   
        }
        
        return $er_arr;

    }

    public function er_generate_repeater_fields(){

        $er_arr           = [];
        
        $er_assoc = $this->er_remove_prefix_from_fields(true);
        foreach( $er_assoc as $key => $item ){

            $new_arra = [];
            foreach($item as $reitem){

                if( is_string( $reitem ) ){
                    $new_arra[] = ['title' => $reitem];
                }
               
            }

            $er_arr[$key] = $new_arra; 

        } 
        return $er_arr;

    }
    public function er_generate_repeater_f_one(){

        $er_arr = $this->er_generate_repeater_fields(); 
     
        if(isset($er_arr[$this->er_repeater_field_type()])){
           return [$this->er_repeater_field_type() => $er_arr[$this->er_repeater_field_type()]] ; 
        }
        return $er_arr;

    }
    public function er_generate_repeater_social_fields(){

        $er_arr           = [];
        $er_assoc = $this->er_remove_prefix_from_fields(true);
        
        foreach( $er_assoc as $key => $item ){
          
            $new_arra = [];
            if($this->er_repeater_field_type('content_loop_field') == $key){
                
                foreach($item as $reitem){

                    if( is_array( $reitem ) ){
    
                        $icon = '';
                        if( isset($reitem['icon']['library']) && $reitem['icon']['library'] == 'svg'){
                       
                            $img = isset($reitem['icon']['value']['url'])?$reitem['icon']['value']['url']:'';
                            $icon = "<img src='{$img}' />";
                        }else{
                           
                            $_icon = $reitem["icon"];
                            $font_class = $_icon['value'];
                            $icon = "<i class='{$font_class}' ></i>";
                            
                        }
    
                        $new_arra[] = [
    
                            'title' => $reitem['title'],
                            'link' => $reitem['link']['url'],
                           
                            'icon' => $icon
                        ];
    
    
                    }
                   
                }
    
                $er_arr[$key] = $new_arra; 
            } 
       

        } 
        return $er_arr;

    }
   
    public function er_generate_repeater_social_fields_two(){

        $er_arr           = [];
        $er_assoc = $this->er_remove_prefix_from_fields(true);
        
        foreach( $er_assoc as $key => $item ){
          
            $new_arra = [];
            if($this->er_repeater_field_type('content_loop_field_two') == $key){
                
                foreach($item as $reitem){

                    if( is_array( $reitem ) ){
    
                        $icon = '';
                        if( isset($reitem['icon']['library']) && $reitem['icon']['library'] == 'svg'){
                       
                            $img = isset($reitem['icon']['value']['url'])?$reitem['icon']['value']['url']:'';
                            $icon = "<img src='{$img}' />";
                        }else{
                           
                            $_icon = $reitem["icon"];
                            $font_class = $_icon['value'];
                            $icon = "<i class='{$font_class}' ></i>";
                            
                        }
    
                        $new_arra[] = [
    
                            'title' => $reitem['title'],
                            'link' => $reitem['link']['url'],
                           
                            'icon' => $icon
                        ];
    
    
                    }
                   
                }
    
                $er_arr[$key] = $new_arra; 
            } 
       

        } 
        return $er_arr;

    }
    public function er_generate_repeater_gen_fields(){

        $er_arr           = [];
        $er_assoc = $this->er_remove_prefix_from_fields(true);
        
        foreach( $er_assoc as $key => $item ){
 
            $new_arra = [];
          
            foreach($item as $reitem){
                 
                if( is_array( $reitem ) ){

                      $end_arra = []; 
                     foreach( $reitem as $jk => $end_item ){

                          // icon
                        if(isset($end_item['library'])){

                            if( $end_item['library'] == 'svg'){
                       
                                $img = isset($end_item['value']['url'])?$end_item['value']['url']:'';
                                $icon = "<img src='{$img}' />";
                            }else{
                                
                                $font_class = $end_item['value'];
                                $icon = "<i class='{$font_class}' ></i>";
                               
                            }
        
                            $end_arra[$jk] = $icon;
                        }elseif( isset( $end_item['url'] ) && isset( $end_item['nofollow'] ) && isset( $end_item['is_external'] ) ){
                            $end_arra[$jk] = $end_item['url'];
                        }elseif( isset( $end_item['url'] ) && isset( $end_item['id'] ) ){
                            $end_arra[$jk] = $end_item['url'];
                        }else{
                            $end_arra[$jk] = $end_item;
                        }
                       

                     } // endforeach

                    $new_arra[] = $end_arra;
                    
                }
               
            }

            $er_arr[$key] = $new_arra; 

        } 
   
        return $er_arr;

    }
    public function er_generate_repeater_gen_fields_two(){

        $er_arr           = [];
        $er_assoc = $this->er_remove_prefix_from_fields(true);
        
        foreach( $er_assoc as $key => $item ){
 
            $new_arra = [];
          
            foreach($item as $reitem){
                 
                if( is_array( $reitem ) ){

                      $end_arra = []; 
                     foreach( $reitem as $jk => $end_item ){

                          // icon
                        if(isset($end_item['library'])){

                            if( $end_item['library'] == 'svg'){
                       
                                $img = isset($end_item['value']['url'])?$end_item['value']['url']:'';
                                $icon = "<img src='{$img}' />";
                            }else{
                                
                                $font_class = $end_item['value'];
                                $icon = "<i class='{$font_class}' ></i>";
                               
                            }
        
                            $end_arra[$jk] = $icon;
                        }elseif( isset( $end_item['url'] ) && isset( $end_item['nofollow'] ) && isset( $end_item['is_external'] ) ){
                            $end_arra[$jk] = $end_item['url'];
                        }elseif( isset( $end_item['url'] ) && isset( $end_item['id'] ) ){
                            $end_arra[$jk] = $end_item['url'];
                        }else{
                            $end_arra[$jk] = $end_item;
                        }
                       

                     } // endforeach

                    $new_arra[] = $end_arra;
                    
                }
               
            }

            $er_arr[$key] = $new_arra; 

        } 
   
        return $er_arr;

    }
    
    public function er_generate_social_repeater_f_one(){
              
        $er_arr = $this->er_generate_repeater_social_fields(); 
    
        if(isset($er_arr[$this->er_repeater_field_type('content_loop_field')])){
           return [$this->er_repeater_field_type('content_loop_field') => $er_arr[$this->er_repeater_field_type('content_loop_field')]] ; 
        }
       
        return $er_arr;

    }
    
    public function er_generate_social_repeater_f_two(){
              
        $er_arr = $this->er_generate_repeater_social_fields_two(); 
        
        if(isset($er_arr[$this->er_repeater_field_type('content_loop_field_two')])){
           return [$this->er_repeater_field_type('content_loop_field_two') => $er_arr[$this->er_repeater_field_type('content_loop_field_two')]] ; 
        }
       
        return $er_arr;

    }

    public function er_generate_gen_repeater_f_one(){
              
        $er_arr = $this->er_generate_repeater_gen_fields(); 
    
        if(isset($er_arr[$this->er_repeater_field_type('content_loop_field')])){
           return [$this->er_repeater_field_type('content_loop_field') => $er_arr[$this->er_repeater_field_type('content_loop_field')]] ; 
        }
       
        return $er_arr;

    } 
    
    public function er_generate_gen_repeater_f_two(){
              
        $er_arr = $this->er_generate_repeater_gen_fields_two(); 
       
       
        if(isset($er_arr[$this->er_repeater_field_type('content_loop_field_two')])){
           return [$this->er_repeater_field_type('content_loop_field_two') => $er_arr[$this->er_repeater_field_type('content_loop_field_two')]] ; 
        }
       
        return $er_arr;

    }
    public function er_generate_repeater_f_two(){

        $er_arr = $this->er_generate_repeater_fields(); 
     
        if(isset($er_arr[$this->er_repeater_field_type('content_loop_field_two')])){
           return [$this->er_repeater_field_type('content_loop_field_two') => $er_arr[$this->er_repeater_field_type('content_loop_field_two')]] ; 
        }
        return $er_arr;

    }

    public function er_get_control_type( $field ){
       
        foreach($this->er_widget_controls as $item) {

            if( $field == $item['control_name'] ){
                return $item['control_f_type'];
            }
        }

        return 'text';
    }

    public function is_er_post_control_type( $field='post' ){
       
        foreach($this->er_widget_controls as $item) {

            if( $field == $item['control_f_type'] ){
                return true;
            }
        }

        return false;
    }

    function control_startsWith($string, $startString) 
    { 
        $len = strlen($startString); 
        return (substr($string, 0, $len) === $startString); 
    } 
  
    //repeater item one
    public function get_loop_content(){
        
        $loop_content     = '';
        $settings         = $this->get_er_settings();
        $element_settings = $this->get_settings_for_display();
      
      
        if(isset($settings['content_loop_html'])){
           
            if( $this->er_repeater_field_type('content_loop_field') == 'post' ){
                
                $html_content_one  = '';
                $html_content_one = '<loop.'.$this->er_repeater_field_type('content_loop_field').'>'; 
                $html_content_one .= $settings['content_loop_html']; 
                $html_content_one .= '</loop.'.$this->er_repeater_field_type('content_loop_field').'>';

                $repeater_fields  = $this->_er_get_posts_content_array();
               
                $_er_render = new er_html_renderer();  
                $_er_render->setContent($html_content_one); 
                $_er_render->setVars(['___title' => ''])
                 ->setLoops($repeater_fields)
                 ->setInjects(array('data'));
    
               $_er_render->compile();
               
               return $_er_render->getCompiled();

            }else{

                $html_content_one  = '';
                $html_content_one = '<loop.'.$this->er_repeater_field_type('content_loop_field').'>'; 
                $html_content_one .= $settings['content_loop_html']; 
                $html_content_one .= '</loop.'.$this->er_repeater_field_type('content_loop_field').'>';
             
                if($this->is_social_repeater($this->er_repeater_field_type('content_loop_field'))){
                   
                    $repeater_fields  = $this->er_generate_social_repeater_f_one();
                }elseif($this->is_repeater($this->er_repeater_field_type('content_loop_field'))){
                    $repeater_fields  = $this->er_generate_gen_repeater_f_one();
                      
                }else{

                    $repeater_fields  = $this->er_generate_repeater_f_one();
                }
               
                
                $_er_render = new er_html_renderer();  
                $_er_render->setContent($html_content_one); 
                $_er_render->setVars(['___title' => ''])
                 ->setLoops($repeater_fields)
                 ->setInjects(array('data'));
    
               $_er_render->compile();
              
               return $_er_render->getCompiled();
            }
          
        }
    }

    function is_social_repeater($field='un'){

        $settings     = $this->get_er_settings();
        $control_list = isset($settings['control_list'])?$settings['control_list']:[];
        
         foreach($control_list as $item){

            if($item['control_name'] == $field && $item['control_f_type'] == 'social-repeater' ){
               return true;
            }
         }

         return false;
       
    }
    function is_repeater($field='un'){

        $settings     = $this->get_er_settings();
        $control_list = isset($settings['control_list']) ? $settings['control_list']: [];
        
         foreach($control_list as $item){

            if($item['control_name'] == $field && $item['control_f_type'] == 'repeater' ){
               return true;
            }
         }

         return false;
       
    }

     //repeater item one
     public function get_loop_content_two(){
        
        $loop_content     = '';
        $settings         = $this->get_er_settings();
        $element_settings = $this->get_settings_for_display();
      
        if(isset($settings['content_loop_html_two'])){
            
            if( $this->er_repeater_field_type('content_loop_field_two') == 'post' ){
                
                $html_content_one  = '';
                $html_content_one = '<loop.'.$this->er_repeater_field_type('content_loop_field_two').'>'; 
                $html_content_one .= $settings['content_loop_html_two']; 
                $html_content_one .= '</loop.'.$this->er_repeater_field_type('content_loop_field_two').'>';
               
                $repeater_fields  = $this->_er_get_posts_content_array();
                
                $_er_render = new er_html_renderer();  
                $_er_render->setContent($html_content_one); 
                $_er_render->setVars(['___title' => ''])
                 ->setLoops($repeater_fields)
                 ->setInjects(array('data'));
    
               $_er_render->compile();
              
               return $_er_render->getCompiled();

            }else{
                
                $html_content_one  = '';
                $html_content_one = '<loop.'.$this->er_repeater_field_type('content_loop_field_two').'>'; 
                $html_content_one .= $settings['content_loop_html_two']; 
                $html_content_one .= '</loop.'.$this->er_repeater_field_type('content_loop_field_two').'>';
             
                if($this->is_social_repeater($this->er_repeater_field_type('content_loop_field_two'))){
                    $repeater_fields  = $this->er_generate_social_repeater_f_two();
                   
                }elseif($this->is_repeater($this->er_repeater_field_type('content_loop_field_two'))){
                    $repeater_fields  = $this->er_generate_gen_repeater_f_two();
                      
                }else{

                    $repeater_fields  = $this->er_generate_repeater_f_two();
                }

                $_er_render = new er_html_renderer();  
                $_er_render->setContent($html_content_one); 
                $_er_render->setVars(['___title' => ''])
                 ->setLoops($repeater_fields)
                 ->setInjects(array('data'));
    
               $_er_render->compile();
              
               return $_er_render->getCompiled();
            }
          
        }
    }


    public function _er_get_posts_content_array(){

        if( !$this->is_er_post_control_type() ){
         return [];
        }
        
        $post_data         = [];
        $settings          = $this->get_settings_for_display();
        $post_title_crop   = isset($settings['post_title_crop'])?$settings['post_title_crop']:20;
        $post_content_crop = isset($settings['post_content_crop'])?$settings['post_content_crop']:80;
        $data              = new Base_Modal($settings);
        $query             = $data->get_posts();
        
        if( !$query ){
          return $post_data;  
        }
       
        foreach( $query as $post_item ){
           
            $category = get_the_category( $post_item->ID );
            $posttags = get_the_tags( $post_item->ID );
            
            $new_post_array = [
                'title'               => wp_trim_words( $post_item->post_title, $post_title_crop,'' ),
                'excerpt'             => $post_item->post_excerpt,
                'name'                => $post_item->post_name,
                'url'                 => get_the_permalink( $post_item->ID ),
                'content'             => wp_trim_words($post_item->post_content,$post_content_crop,''),
                'author_name'         => get_the_author_meta( 'display_name' , $post_item->ID ),
                'author_url'          => get_author_posts_url( get_the_author_meta( $post_item->author_id ) ),
                'modified_date'       => date( get_option( 'date_format' ), strtotime( $post_item->post_modified ) ),
                'date'                => get_the_date( get_option( 'date_format' ) , $post_item->ID ),
                'image_full_url'      => get_the_post_thumbnail_url( $post_item->ID, 'full' ),
                'image_thumbnail_url' => get_the_post_thumbnail_url( $post_item->ID ),
                'category_name'       => null,
                'category_url'        => null,
                'tag_name'            => '',
                'tag_url'             => '',
                'comment_count'       => $post_item->comment_count
            ];
            
            if($category){
                
                $cats = [];
                foreach($category as $cat_item){
                    
                    $new_post_array['category_name'] = $cat_item->name;
                    $new_post_array['category_url']  = get_category_link( $cat_item->term_id );
                    
                }
  
            }

            if($posttags){
                
                $tags = [];
                foreach($posttags as $tag_item){
                    
                     $new_post_array['tag_name'] = $tag_item->name ;
                     $new_post_array['tag_url'] = get_tag_link($tag_item->term_id);
                    
                }
  
            }
           
            $post_data['post'][] = $new_post_array;
        }
       
       return $post_data;
    }
}