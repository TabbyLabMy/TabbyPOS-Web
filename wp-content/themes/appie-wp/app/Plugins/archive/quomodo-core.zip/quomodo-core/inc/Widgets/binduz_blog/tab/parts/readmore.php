<?php if( $settings['show_readmore'] =='yes' ): ?>
  
    <a class="er-readmore-btn" href="<?php the_permalink() ?>"> 
         <?php echo $settings['readmore_text']; ?>
        <?php if($settings['meta_readmore_icon']['library'] !=''): ?>
            <?php \Elementor\Icons_Manager::render_icon( $settings['meta_readmore_icon'], [ 'aria-hidden' => 'true' ] ); ?>
        <?php endif; ?>
    </a>

<?php endif; ?>