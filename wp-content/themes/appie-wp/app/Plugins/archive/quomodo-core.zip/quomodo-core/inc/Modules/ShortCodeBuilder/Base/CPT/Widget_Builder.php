<?php
/**
 * @package  Element Ready
 */
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base\CPT;
use Element_Ready\Api\Callbacks\Custom_Post;
use Element_Ready_Pro\Base\Traits\Helper;
class Widget_Builder extends Custom_Post
{
    use Helper;
    public $name         = '';
    public $menu         = 'ShortCode Builder';
    public $textdomain   = '';
    public $posts        = array();
    public $public_quary = false;
    public $slug         = 'erp_scb_builder';
    public $search       = false;


    public function element_ready_get_components_option($key = false){
        
        $this->name = esc_html__('ShortCode Builder','element-ready-pro');
        $option = get_option('element_ready_components');
       
        if($option == false){
            return false;
        }
        
        return isset($option[$key]) ? $option[$key] == 'on'?true:false:false;
    }
    
    

	public function register() {

        //if( $this->element_ready_get_modules_option('customer_request') ) {
            $this->textdomain = 'element-ready-pro';
            $this->posts      = array();
            add_action( 'init', array( $this, 'create_post_type' ) );
            add_filter( 'manage_erp_scb_builder_posts_columns',[$this,'new_cpt_columns']);
            add_action( 'manage_erp_scb_builder_posts_custom_column' , [ $this,'custom_columns'], 10, 2 ); 
            add_filter( 'post_row_actions',[$this,'_action_row'], 10, 2);
           // add_action( 'add_meta_boxes', array( $this, 'add_metabox' ) );
           add_action( 'admin_footer-edit.php' , [ $this,'load_asset_js' ] );
            add_action( 'save_post_erp_scb_builder',array( $this, 'save' ) );
       //}

      
    }
    
    
   

    public function add_metabox() {
     
        add_meta_box(
            'element_ready_widget_slug_settings',
            esc_html__( 'Settings','element-ready' ),
            array( $this, 'render_meta_box_content' ),
            'erp_scb_builder',
            'advanced',
            'default'
        );

    
 
    }

    public function render_meta_box_content( $post ) {
 
        wp_nonce_field( 'element_ready_pro_scb_builder', 'element_ready_scb_builder_nonce' );
        $widget_slug = get_post_meta( $post->ID, 'element_ready_pro_scb_widget_slug', true );

       ?>

       <label for="element_ready_pro_widget_slug">
           <?php echo esc_html__( 'Widget Slug', 'element-ready-pro' ); ?>
       </label>
       <input type="text" name="element_ready_pro_scb_widget_slug" value="<?php echo esc_attr($widget_slug); ?>" />
      
       <?php
   }
   
   public function save( $post_id ) {
    
    
    if ( ! isset( $_POST['element_ready_scb_builder_nonce'] ) ) {
        return $post_id;
    }
    
    $nonce = $_POST['element_ready_scb_builder_nonce'];

    if ( ! wp_verify_nonce( $nonce, 'element_ready_pro_scb_builder' ) ) {
        return $post_id;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return $post_id;
    }

    $widget_slug = sanitize_text_field( $_POST['element_ready_pro_scb_widget_slug'] );
  
    update_post_meta( $post_id, 'element_ready_pro_scb_widget_slug', $widget_slug );
   }

    function _action_row($actions, $post){
        unset($actions['trash']);
        unset($actions['inline hide-if-no-js']);
        if('erp_scb_builder' == $post->post_type){
           
            $delete_url = add_query_arg( array(
                'post_type' => $post->post_type,
                'post_id' => $post->ID,
                'delete_post' => '1'
            ), admin_url('admin.php') );

            $actions['shortcode_widget_delete'] = '<a class="er-scb-wp-delete-post" data-id="'.$post->ID.'" href="javascript:void(0)">'.esc_html__('delete').'</a>';
            // setting 
            $url = add_query_arg( array(
                'page' => 'element-ready-pro-scb',
                'post_type' => $post->post_type,
                'post_id' => $post->ID
            ), admin_url('admin.php') );
            
            $actions['shortcode_widget_settings'] = '<a href="'.esc_url($url).'">'.esc_html__('open settings').'</a>';
            
           
        }

        

        return $actions;
    }
    function new_cpt_columns( $columns ) {
     
        $columns['customer_edit'] = esc_html__('Settings','element-ready-pro');
        return $columns;
    }
    
    function custom_columns( $column, $post_id ) {
        switch ( $column ) {

             case 'customer_edit':
                $url = add_query_arg( array(
                    'page' => 'element-ready-pro-scb',
                    'post_type' => get_post_type($post_id),
                    'post_id' => $post_id
                ), admin_url('admin.php') );
                echo '<a class="element-ready-scb-setting-link" href="'.esc_url($url).'">'.esc_html__('Open Settings').'</a>'; 
                break;
        }
    }

    public function create_post_type(){
   
        $this->init( 'erp_scb_builder', $this->name, $this->menu, array( 'menu_icon' => 'dashicons dashicons-admin-page',
            'supports'            => array( 'title' ),
            'exclude_from_search' => $this->search,
            'has_archive'         => false,                                               // Set to false hides Archive Pages
            'publicly_queryable'  => $this->public_quary,
            
            'show_in_menu'        => false
        )
       );

       $this->register_custom_post();
    }

    public function load_asset_js($data){
      
        wp_enqueue_script( 'wp-util' ); 
       ?>
        <script>
           
            jQuery('.er-scb-wp-delete-post').on('click',function(){

             let id = null;
             let er_that_post = jQuery(this);
             id = er_that_post.attr('data-id'); 
           
            jQuery.ajax({
                url: '<?php echo admin_url( 'admin-ajax.php' ); ?>', // This is globally available, it resolves to the admin ajax url
                method: 'POST',
                data: {
                    // The action must be the same element_ready_pro_scb_remove_widget_as the name of your php class
                    action: 'element_ready_pro_scb_remove_widget_',
                    // For security reason, you must specify the nonce created for your php class
                    // You can get it by suffixing "Nonce" to your php class, like so
                    nonce: '<?php echo wp_create_nonce( 'element_ready_pro_scb_nonce' ); ?>',
                    post_id: id
                    // Then send whatever data you like
                
                    
                },
                success: function (response) {
                   
                    if(response.success){
                        let er_message_template = `<div class="notice notice-success is-dismissible">
                            <p> ${response.data.message}  </p>
                        </div>`;
                        er_that_post.parents('tr.iedit').remove();
                        jQuery('.element-ready-dash-cpt-scb-header').before(er_message_template);
                    }
                    
                },
            });

            }); 

        </script>
       <?php 
        
    }

}