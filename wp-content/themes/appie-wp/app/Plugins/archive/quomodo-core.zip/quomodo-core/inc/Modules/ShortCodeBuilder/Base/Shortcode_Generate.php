<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base;
use Element_Ready\Base\BaseController;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Shortcode_Base as Shortcode_Base;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\File_Maker;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\Common as BuilderCommon;

Class Shortcode_Generate {

    use File_Maker;
    use BuilderCommon;
    public $widget_list = [];

   function recreate(){

      $dumper = new \Nette\PhpGenerator\Dumper;
      $widget_list = $this->get_posts();

      foreach($widget_list as $widget){

       
        $class_uniq_name = ucfirst('er_scb_'.preg_replace('/\s+/', '_', $widget['slug']));
        $class_uniq_name = preg_replace('/-/', '_', $class_uniq_name);
        $er_widget_title = isset($widget['settings']['widget_name'])?$widget['settings']['widget_name']:$widget['title'];
        $class_uniq_id   = 'return '.'"'.preg_replace('/\s+/', '_', $class_uniq_name).'"'.';';
        $widget_title    = 'return '.'"'.$er_widget_title.'"'.';';
        $widget_icon     = 'return '.'"'.'fa fa-handshake-o'.'"'.';';
        $widget_u_name    = 'return '.'"'.$class_uniq_name.'"'.';';
        $widget_keywords = $dumper->dump(['custom widget','user widget']);
        $widget_cat      = $dumper->dump(['element-ready-pro']);
        $widget_script   = $dumper->dump([]);
        $widget_style    = $dumper->dump([]);
        $widget_id       = $widget['id'];

        $file            = new \Nette\PhpGenerator\PhpFile;
        $file->addComment('This file is auto-generated.');
        $namespace = $file->addNamespace('Element_Ready_Pro\Modules\ShortCodeBuilder\Widgets');
     
        $namespace->addUse('Elementor\Controls_Manager');
        $namespace->addUse('Elementor\Icons_Manager');
        $namespace->addUse('Elementor\Group_Control_Typography');
        $namespace->addUse('Elementor\Group_Control_Background');
        $namespace->addUse('Elementor\Group_Control_Border');
        $namespace->addUse('Elementor\Group_Control_Css_Filter');
        $namespace->addUse('Elementor\Group_Control_Box_Shadow');
        $namespace->addUse('Elementor\Group_Control_Image_Size');
        $namespace->addUse('Elementor\Modules\DynamicTags\Module as TagsModule');
        $namespace->addUse('Elementor\Utils');
        $namespace->addUse('Elementor\Plugin');
        $namespace->addUse('Elementor\Repeater');

        
        
        $class = $namespace->addClass($class_uniq_name)->setExtends(Widget_Base::class);
        $method = $class->addMethod('get_name')->setBody($class_uniq_id);
        $method = $class->addMethod('get_title')->setBody($widget_title);
        $method = $class->addMethod('get_icon')->setBody($widget_icon);
        $method = $class->addMethod('get_categories')->setBody("return $widget_cat;");
        $method = $class->addMethod('get_keywords')->setBody("return $widget_keywords;");
        //$method = $class->addMethod('get_script_depends')->setBody("return $widget_script;");
       // $method = $class->addMethod('get_style_depends')->setBody("return $widget_style;");
        $method = $class->addMethod('widget_post_id')->setBody("return $widget_id;");
        $method = $class->addMethod('widget_post_id')->setBody("return $widget_id;");
        $method = $class->addMethod('get_widget_name')->setBody("$widget_u_name");

       // $class->addTrait(Traits\Er_Style_Control::class);
        //$class->addTrait(Traits\Basic_Render::class);
       
        $this->save_content($file,$class_uniq_name);
 
       
      }
  
   }

   function single_widget_init($id){

        $dumper = new \Nette\PhpGenerator\Dumper;
        
        $widget = $this->get_post($id);
        
        $class_uniq_name = ucfirst('er_scb_'.preg_replace('/\s+/', '_', $widget['slug']));
        $class_uniq_name = preg_replace('/-/', '_', $class_uniq_name);
        $er_widget_title = isset($widget['settings']['widget_name'])?$widget['settings']['widget_name']:$widget['title'];
        $class_uniq_id   = 'return '.'"'.preg_replace('/\s+/', '_', $class_uniq_name).'"'.';';
        $widget_title    = 'return '.'"'.$er_widget_title.'"'.';';
        $widget_u_name    = 'return '.'"'.$class_uniq_name.'"'.';';
        $widget_icon     = 'return '.'"'.'fa fa-handshake-o'.'"'.';';
        $widget_keywords = $dumper->dump(['custom widget','user widget']);
        $widget_cat      = $dumper->dump(['element-ready-pro']);
        $widget_script   = $dumper->dump([]);
        $widget_style    = $dumper->dump([]);
        $widget_id       = $widget['id'];
     
        $file            = new \Nette\PhpGenerator\PhpFile;
        $file->addComment('This file is auto-generated.');
        $namespace = $file->addNamespace('Element_Ready_Pro\Modules\ShortCodeBuilder\Widgets');
       
        $namespace->addUse('Elementor\Controls_Manager');
        $namespace->addUse('Elementor\Icons_Manager');
        $namespace->addUse('Elementor\Group_Control_Typography');
        $namespace->addUse('Elementor\Group_Control_Background');
        $namespace->addUse('Elementor\Group_Control_Border');
        $namespace->addUse('Elementor\Group_Control_Css_Filter');
        $namespace->addUse('Elementor\Group_Control_Box_Shadow');
        $namespace->addUse('Elementor\Group_Control_Image_Size');
        $namespace->addUse('Elementor\Modules\DynamicTags\Module as TagsModule');
        $namespace->addUse('Elementor\Utils');
        $namespace->addUse('Elementor\Plugin');
        $namespace->addUse('Elementor\Repeater');

        
        // add methods
        $class = $namespace->addClass($class_uniq_name)->setExtends(Widget_Base::class);
        $method = $class->addMethod('get_name')->setBody($class_uniq_id);
        $method = $class->addMethod('get_title')->setBody($widget_title);
        $method = $class->addMethod('get_icon')->setBody($widget_icon);
        $method = $class->addMethod('get_categories')->setBody("return $widget_cat;");
        $method = $class->addMethod('get_keywords')->setBody("return $widget_keywords;");
        //$method = $class->addMethod('get_script_depends')->setBody("return $widget_script;");
       // $method = $class->addMethod('get_style_depends')->setBody("return $widget_style;");
        $method = $class->addMethod('widget_post_id')->setBody("return $widget_id;");
        $method = $class->addMethod('get_widget_name')->setBody("$widget_u_name");

        //$class->addTrait(Traits\Register_Controls::class);
        //$class->addTrait(Traits\Basic_Render::class);
       
        $this->save_content($file,$class_uniq_name);
        $this->save_css($id,$class_uniq_name);
        $this->save_js($id,$class_uniq_name);
      
  
   }

    
   
 

   
}