<h3 class="binduz-er-title"><a href="<?php the_permalink($post->ID) ?>"> <?php echo esc_html(wp_trim_words( get_the_title($post->ID),$settings['post_title_crop'],'' )); ?> </a></h3>
