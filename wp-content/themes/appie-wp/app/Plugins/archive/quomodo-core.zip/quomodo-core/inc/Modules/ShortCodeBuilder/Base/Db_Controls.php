<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base;
use Elementor\Controls_Manager;
class Db_Controls 
{
  
   public $er_settings = [];
   public $post_id = null;
 
   public function __construct($settings = [],$widget_id=null) {
     
     $this->er_settings = $settings;
     $this->post_id     = $widget_id;
   }

   public function er_get_content_fields(){
      
      $content_controls = []; 
      if( is_array( $this->er_settings ) ){

        if( isset($this->er_settings['control_list']) ){
          $content_controls = $this->er_settings['control_list'];
       }

      }
    
      return $content_controls;  
   }


   public function er_get_style_fields(){

    $style_controls = []; 
   
    if( is_array( $this->er_settings ) ){

      if(  isset($this->er_settings['control_list']) ){
        $style_controls = $this->er_settings['control_list'];
      }

    }
  
    return $style_controls;  
   }


}