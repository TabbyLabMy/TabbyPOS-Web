<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Base;
use Element_Ready\Base\BaseController;

class Enqueue extends BaseController
{
    public $page = 'admin_page_element-ready-pro-scb';
	public function register() {
        
		// admin
		add_action( 'admin_enqueue_scripts', array( $this, 'backend' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'frontend' ) );
        add_action( 'admin_footer' , [ $this,'load_templates' ] );
        add_action( 'admin_footer' , [ $this,'load_asset_templates' ] );
         // elementor editor
		add_action( 'elementor/editor/after_enqueue_scripts', [ __CLASS__, 'enqueue_editor_scripts' ] );
   
   	}
    
    public static function enqueue_editor_scripts() {

        wp_enqueue_style( 'element-ready-builder-lib', ELEMENT_READY_PRO_BUILDER_URL . 'assets/css/elementor.css',1.1,true );
		wp_enqueue_script(
			'element-ready-builder-lib',
			ELEMENT_READY_PRO_BUILDER_URL . 'assets/js/elementor.js',
			[
				'jquery',
			],
			1.1,
			true
		);

		wp_localize_script( 'element-ready-pro-builder-lib', 'er_builder_lib', array(
			'logoUrl'	=> ELEMENT_READY_ROOT_IMG.'logo.svg',
		) );
	}
	
	function backend( $handle ) {
        // enqueue all our scripts
      
        if( $handle == $this->page || $handle == 'admin_page_element-ready-pro-scb-add-new'){
       
            if ( ! did_action( 'wp_enqueue_media' ) ) {
                wp_enqueue_media();
            }
            // handlers
            // jquery-ui-draggable ,jquery-ui-droppable ,jquery-ui-tabs ,jquery-ui-sortable ,jquery-ui-menu	
            wp_enqueue_script( 'thickbox' );
            wp_enqueue_style( 'thickbox' );
             wp_enqueue_script( 'codemirror', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.60.0/codemirror.min.js', null, ELEMENT_READY_PRO_VERSION, true );
             wp_enqueue_style( 'codemirror', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.60.0/codemirror.min.css' );
             wp_enqueue_style( 'codemirror-draqula', 'https://codemirror.net/theme/dracula.css' );
           
            wp_enqueue_style( 'element-ready-pro-scbuilder-style', ELEMENT_READY_PRO_BUILDER_URL . 'assets/css/backend.css' ,array(), time());
        
            wp_enqueue_script( 'element-ready-pro-scbuilder-backend-script', ELEMENT_READY_PRO_BUILDER_URL . 'assets/js/backend.js', array('jquery','underscore','wp-util','jquery-ui-draggable' ,'jquery-ui-droppable' ,'jquery-ui-tabs' ,'jquery-ui-sortable' ,'jquery-ui-menu'),time(),true );
        
            $_obj = array(
                'ajax_url'      => admin_url( 'admin-ajax.php' ),
                'scb_nonce'     => wp_create_nonce( 'element_ready_pro_scb_nonce' ),
                'service_title' => esc_html__('Shortcode Builder','element-ready-pro')
            );

            //page=element-ready-pro-scb&post_type=erp_scb_builder&post_id=1946

            if( 
                isset($_REQUEST['page']) &&
                isset($_REQUEST['post_type']) &&
                $_REQUEST['post_type'] == 'erp_scb_builder' && 
                $_REQUEST['page'] == 'element-ready-pro-scb'
                  ){
                    $the_post_ = get_post($_REQUEST['post_id']);   
                    $_obj['post_id'] = isset($_REQUEST['post_id'])?$_REQUEST['post_id']:-1;
                    $_obj['er_post'] = $the_post_;
                    $_obj['widget_settings_data'] = get_post_meta($_REQUEST['post_id'],ELEMENT_READY_PRO_BUILDER_WIDGET_KEY,true);
            }

            wp_localize_script( 'element-ready-pro-scbuilder-backend-script', 'shortcode_builder_obj', $_obj );

        }
    }

    function frontend() {
       
        wp_enqueue_style( 'element-ready-pro-scbuilder-frontend', ELEMENT_READY_PRO_BUILDER_URL . 'assets/css/frontend.css' );
     	wp_enqueue_script( 'element-ready-pro-scb-frontend', ELEMENT_READY_PRO_BUILDER_URL . 'assets/js/frontend.js');
       $this->register_script();
    }

    public function register_script(){
        $key = 'element_ready_scb_builder_cdn_list';
        $option_data = get_option($key);
        
        if(is_array($option_data)){
            foreach($option_data as $item){

                if( isset($item['type']) && $item['type']=='js'){

                   if($item['name'] == 'jquery' || $item['name'] == 'Jquery' ){
                       continue;
                   }

                   if( $item['url'] == '' || $item['url'] == '#'  ){
                    continue;
                   }
                   
                   wp_register_script($item['name'], 
                   $item['url'],  
                   array (),                 
                   false, false);
                }
            }
        }
    }

    public function load_templates(){
       
        if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'element-ready-pro-scb' ){
            require_once( __DIR__ .'/..' .'/Templates/underscore.template.php' );
        }
    
   }

   public function load_asset_templates($hook){
       
        wp_enqueue_script( 'wp-util' );
       ?>
         
       <script>

            jQuery('.er-element-scb-all-regenerate').on('click',function(){
        
            jQuery.ajax({
                url: '<?php echo admin_url( 'admin-ajax.php' ); ?>', // This is globally available, it resolves to the admin ajax url
                method: 'POST',
                data: {
                    // The action must be the same as the name of your php class
                    action: 'element_ready_pro_scb_set_widget_regenerate_',
                    // For security reason, you must specify the nonce created for your php class
                    // You can get it by suffixing "Nonce" to your php class, like so
                    nonce: '<?php echo wp_create_nonce( 'element_ready_pro_scb_nonce' ); ?>',
                    // Then send whatever data you like
                  
                    
                },
                success: function (response) {
                    let er_message_template = `<div class="notice notice-success is-dismissible">
                        <p> ${response.data.message}  </p>
                    </div>`;
                     
                    jQuery('.element-ready-dash-cpt-scb-header').before(er_message_template);
                },
            });

         }); 

       </script>
       <?php 
   }
    
  
}