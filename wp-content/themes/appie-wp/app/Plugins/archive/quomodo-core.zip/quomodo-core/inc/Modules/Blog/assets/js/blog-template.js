jQuery(document).ready(function(){
    "use strict";

    function er_tpl_blog_message_render(response){
            
        var notice= jQuery("#er-blog-tpl-js-notice");
        notice.addClass('show');
        notice.html(response.data.msg);
        if(response.success) {

            setTimeout(function(){

                notice.removeClass('show');

            } , 1000);

        }else{

            setTimeout(function(){

           notice.removeClass('show');

          } , 1000);
        }
    }
    
    // Iframe Popup
    jQuery(document).on('click', '.content_edit a.er-blog-tpl-edit-button' ,function(e){
          
        e.preventDefault();
        var url = jQuery(this).attr('href');
        var dynamic_content = jQuery('.er-blog-tpl-content .wready-md-body');
        var iframe = jQuery('<iframe></iframe>');
        iframe.attr('src', url);
        iframe.hide().on('load',function(){
         
        }).fadeIn('2500');

        dynamic_content.html(iframe);
        jQuery('#er-blog-tpl-nifty-modal').nifty("show");
        
    });

    // Option Store
    jQuery(document).on('click', '.er-blog-tpl-content .wready-md-close' ,function(){
       jQuery(this).parent().parent('.nifty-modal').removeClass('wready-md-show');
    });
    jQuery(document).on( 'click', '.er-blog-tpl-switch > input', function(){
        
        var switch_active = jQuery(this);
       
        var post_id = switch_active.attr('data-post_id');
        var active = switch_active.is(":checked") ? 'active' : 'inacitve';
       
        setTimeout(function(){
          
            jQuery.ajax({
                    type : "post",
                    dataType : "json",
                    url : wp.ajax.settings.url,
                    data : {
                        'action': "er_blog_template_options_store",
                        'er_post_id' : post_id,
                        'er_blog_tpl_key': 'er_blog_tpl_active',
                        'er_blog_tpl_value': active
                    },
                    success: function(response) {
                        er_tpl_blog_message_render(response);
                    }
                 }) 
        },1000);
       

    });

    jQuery(document).on( 'change','.er-template-type-select-fld select' , function(){
        
        var template_type = jQuery(this);
      
        var post_id = template_type.attr('data-post_id');
        var tpl_type = template_type.val();
        
        setTimeout(function(){
          
            jQuery.ajax({
                    type : "post",
                    dataType : "json",
                    url : wp.ajax.settings.url,
                    data : {
                        'action'           : "er_blog_template_options_store",
                        'er_post_id'       : post_id,
                        'er_blog_tpl_key'  : 'er_blog_tpl_type',
                        'er_blog_tpl_value': tpl_type
                    },
                    success: function(response) {
                        er_tpl_blog_message_render(response);
                    }
                 }) 
        },1000);
  

    });
    
   
});

