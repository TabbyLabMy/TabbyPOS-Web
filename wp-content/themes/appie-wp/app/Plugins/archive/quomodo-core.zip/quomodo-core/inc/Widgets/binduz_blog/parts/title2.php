<h3 class="binduz-er-title er-news-title-gl">
    <a href="<?php the_permalink() ?>"> <?php echo esc_html(wp_trim_words( get_the_title(),$settings['post_title_crop'],'' )); ?> </a>
</h3>
