<?php
namespace Element_Ready_Pro\Widgets\weather;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Element_Ready\Api\Open_Weather_Api as Weather_Api;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

class Open_Weather_Map extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public $base;

    public function get_name() {
        return 'element-ready-open-weather-map';
    }

    public function get_title() {
        return esc_html__( 'ER Weather Days', 'element-ready-pro' );
    }
    public function get_keywords() {
		return ['er weather','weather','map','days'];
	}

    public function get_icon() { 
        return "eicon-google-maps";
    }

   public function get_categories() {
      return [ 'element-ready-pro' ];
   }
  
   public function get_style_depends() {

    wp_register_style( 'eready-weather' , ELEMENT_READY_ROOT_CSS. 'widgets/weather.css' );
    return [ 'eready-weather' ];
  }
    protected function register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'element-ready-pro'),
            ]
        );

        $this->add_control(
			'layout',
			[
				'label' => esc_html__( 'Style', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'element-ready-pro' ),
					'style2' => esc_html__( 'Style 2', 'element-ready-pro' ),
				],
			]
		);

       $this->end_controls_section();
       
        $this->content_text([
            'title' => esc_html__('Settings','element-ready-pro'),
            'slug' => '_heading_content',
            'condition' => '',
            'controls' => [
                
               
                'coordinates_lat'=> [
                    'label'   => esc_html__( 'Coordinates Latitude', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                   
                ],
                
                'coordinates_lon'=> [
                    'label'   => esc_html__( 'Coordinates Longitude', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                    
                ],

                
                'exclude' => [
                    'label' => esc_html__( 'Exclude', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'multiple' => true,
                    'label_block' => true,
                    'default' => [],
                    'options' => [
                        'current'  => esc_html__( 'current', 'element-ready-pro' ),
                        //'minutely' => esc_html__( 'minutely', 'element-ready-pro' ),
                        //'hourly' => esc_html__( 'hourly', 'element-ready-pro' ),
                        'daily' => esc_html__( 'daily', 'element-ready-pro' ),
                        //'alerts' => esc_html__( 'alerts', 'element-ready-pro' ),
                    
                    ],
                ],

                'units' =>   [
                    'label' => esc_html__( 'Unit', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'standard',
                    'options' => [
                        'standard'  => esc_html__( 'Standard', 'element-ready-pro' ),
                        'metric' => esc_html__( 'Metric', 'element-ready-pro' ),
                        'imperial' => esc_html__( 'Imperial', 'element-ready-pro' ),
                    ],
                    
                ],
                 
                'weather_cache_enable'=> [
                    'label'        => __( 'Cach ?', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => __( 'Show', 'element-ready-pro' ),
                    'label_off'    => __( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => '',
                 ],

         
            ]
         ]);
     
         $this->content_text([
            'title' => esc_html__('Content Settings','element-ready-pro'),
            'slug' => '_content',
            'condition' => [
                'layout' => ['style1']
            ],
            'controls' => [
           
              

                'show_time'=> [
                    'label'        => __( 'Time Enable', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => __( 'Show', 'element-ready-pro' ),
                    'label_off'    => __( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                 ],

                'time_title'=> [
                    'label'   => esc_html__( 'Time', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__('Today','element-ready-pro'),
                    'condition' =>[
                        'show_time' => ['yes']
                    ]
                ],

               
                'show_weather_'=> [
                    'label'        => esc_html__( 'Forcast Title', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => '',
                ],
                
                'humidity_show'=> [
                    'label'        => esc_html__( 'Humidity', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ],

                'humidity_title'=> [
                    'label'   => esc_html__( 'Humidity', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__('Humidity','element-ready-pro'),
                    'condition' =>[
                        'humidity_show' => ['yes']
                    ]
                ],

                
                'wind_speed_show'=> [
                    'label'        => esc_html__( 'Wind Speed', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ],
                'wind_speed_title'=> [
                    'label'   => esc_html__( 'Wind Speed', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__('Speed','element-ready-pro'),
                    'condition' =>[
                        'wind_speed_show' => ['yes']
                    ]
                ],

                'wind_deg_show'=> [
                    'label'        => esc_html__( 'Wind deg', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ],
                'wind_deg_title'=> [
                    'label'   => esc_html__( 'Wind Deg', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__('Deg','element-ready-pro'),
                    'condition' =>[
                        'wind_deg_show' => ['yes']
                    ]
                ],
                
                'pressure'=> [
                    'label'        => esc_html__( 'pressure', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ],
                'pressure_text'=> [
                    'label'   => esc_html__( 'Pressure', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__('Pressure','element-ready-pro'),
                    'condition' =>[
                        'pressure' => ['yes']
                    ]
                ],

                'show_weather_icon'=> [
                    'label'        => esc_html__( 'Icon Enable', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ],

                'show_weather_desc'=> [
                    'label'        => esc_html__( 'Desc Enable', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ],

               


   
         
            ]
         ]);

         $this->content_text([
            'title' => esc_html__('Content Order','element-ready-pro'),
            'slug' => 'order_content_item',
            'condition' => [
                'layout' => ['style1']
            ],
            'controls' => [
           
                'time_order'=> [
                    'label'   => esc_html__( 'Time Order', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min' => -100,
				    'max' => 100,
				    'step' => 5,
				    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .element-ready-weather-time' => 'order: {{VALUE}};',
                      
                     ],
                ],

                
                'icon_order'=> [
                    'label'   => esc_html__( 'Icon Order', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min' => -100,
				    'max' => 100,
				    'step' => 5,
				    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .element-ready-weather-icon' => 'order: {{VALUE}};',
                      
                     ],
                ],
                
                'desc_order'=> [
                    'label'   => esc_html__( 'Desc Order', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min' => -100,
				    'max' => 100,
				    'step' => 5,
				    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .element-ready-weather-desc' => 'order: {{VALUE}};',
                      
                     ],
                ],

                
                'temp_order'=> [
                    'label'   => esc_html__( 'Tempareture Order', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min' => -100,
				    'max' => 100,
				    'step' => 5,
				    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .element-ready-weather-temp' => 'order: {{VALUE}};',
                      
                     ],
                ],
         
            ]
         ]);
        // 
        
        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Current Time Wrapper','element-ready-pro'),
                'slug' => '_time_box_style',
                'element_name' => '_time_wrapper_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-weather-time',
                'condition' => [
                    'exclude!' => ['current'],
                    'layout' => ['style1'],
                ]
            )
        ); 

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Current Time','element-ready-pro'),
                'slug' => '_time_text_style',
                'element_name' => '_time_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-weather-time h5',
                'condition' => [
                    'exclude!' => ['current'],
                    'layout' => ['style1'],
                ]
               
            )
        ); 

        
        $this->text_wrapper_css(
            array(
                'title'        => esc_html__('Current Weather','element-ready-pro'),
                'slug'         => '_cweatehr_text_style',
                'element_name' => '_cweather_element_ready_',
                'selector'     => '{{WRAPPER}} .element-ready-weather-desc,{{WRAPPER}} .weather-Sunny p',
                'hover_selector'     => false,
                'condition'    => [
                    'exclude!' => ['current'],
                   
                ]
              
            )
        ); 

        $this->text_wrapper_css(
            array(
                'title'        => esc_html__('Sunset','element-ready-pro'),
                'slug'         => '_cweatehr_sunset_text_style',
                'element_name' => '_cweather+sunset_element_ready_',
                'selector'     => '{{WRAPPER}} .weather-sunset p',
                'hover_selector'     => false,
                'condition'    => [
                    'exclude!' => ['current'],
                    'layout' => ['style2'],
                ]
              
            )
        ); 

        

        $this->box_css(
            array(
                'title' => esc_html__('Current Meta Wrapper','element-ready-pro'),
                'slug' => 'wrapper_cmeta_box_style',
                'element_name' => 'wrapper_cmeta_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-weather-temp',
                'hover_selector'     => false,
                'condition' => [
                    'exclude!' => ['current'],
                    'layout' => ['style1'],
                ]
               
               
            )
        ); 

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Current Meta item','element-ready-pro'),
                'slug' => '_cweatehr_mitem_text_style',
                'element_name' => '_cweather_mitem_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-weather-temp > div,{{WRAPPER}} .element-ready-weather-map-meta > div',
                'hover_selector'     => false,
                'condition' => [
                    'exclude!' => ['current'],
                   
                ]
              
            )
        );
        
        $this->box_css(
            array(
                'title' => esc_html__('Current Main Wrapper','element-ready-pro'),
                'slug' => 'wrapper_body_box_style',
                'element_name' => 'wrapper_body_element_ready_',
                'hover_selector'     => false,
                'selector' => '{{WRAPPER}} .element-ready-weather-wrapper,{{WRAPPER}} .element-ready-w3-container.active .element-ready-weather-map-item',
                'condition' => [
                    'exclude!' => ['current']
                ]
               
               
            )
        );

        $this->box_css(
            array(
                'title'        => esc_html__('Daily item','element-ready-pro'),
                'slug'         => 'wrapper_daily_item__box_style',
                'element_name' => 'wrapper_daily_item_element_ready_',
                'selector'     => '{{WRAPPER}} .element-ready-weather-daily-wrapper .element-ready-weather-map-item,{{WRAPPER}} .element-ready-w3-bar-item .text p',
                'hover_selector'     => false,
                'condition' => [
                    'exclude!' => ['daily'],
                    'layout' => ['style1']
                ]
            )
        );

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Daily Meta item','element-ready-pro'),
                'slug' => '_cweatehrs_daily_text_style',
                'element_name' => '_cweather_sdaily_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-weather-map-meta > div',
                'hover_selector'  => false,
                'condition' => [
                    'exclude!' => ['daily'],
                    'layout' => ['style1']
                ]
              
            )
        );

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Daily Meta day','element-ready-pro'),
                'slug' => '_cweatehr_daily_text_style',
                'element_name' => '_cweather_daily_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-w3-bar-item .text p',
                'hover_selector'  => false,
                'condition' => [
                    'exclude!' => ['daily'],
                    'layout' => ['style2']
                ]
              
            )
        );

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Daily Meta temp','element-ready-pro'),
                'slug' => '_cweatehr_daily_temp_style',
                'element_name' => '_cweather_daily_temp_element_ready_',
                'selector' => '{{WRAPPER}} .element-ready-w3-bar-item .temperature',
                'hover_selector'  => false,
                'condition' => [
                    'exclude!' => ['daily'],
                    'layout' => ['style2']
                ]
              
            )
        );

        $this->box_css(
            array(
                'title'        => esc_html__('Daily icon','element-ready-pro'),
                'slug'         => 'wrapper_daily_icon__box_style',
                'element_name' => 'wrapper_daily_icon_element_ready_',
                'selector'     => '{{WRAPPER}} .element-ready-w3-bar-item .icon',
                'condition' => [
                    'exclude!' => ['daily'],
                    'layout' => ['style2']
                ]
            )
        );

        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Daily Meta footer','element-ready-pro'),
                'slug' => '_cweatehr_meta_footer_text_style',
                'element_name' => '_cweather_dmeta_footer_element_ready_',
                'selector' => '{{WRAPPER}} .weather-map-text > div',
                'hover_selector' => false,
                'condition' => [
                    'exclude!' => ['daily'],
                    'layout' => ['style1']
                ]
              
            )
        );

        $this->box_css(
            array(
                'title'        => esc_html__('Daily Main Wrapper','element-ready-pro'),
                'slug'         => 'wrapper_daily_body_box_style',
                'element_name' => 'wrapper_daily_body_element_ready_',
                'selector'     => '{{WRAPPER}} .element-ready-weather-daily-wrapper,{{WRAPPER}} .element-ready-w3-bar-item',
                'condition' => [
                    'exclude!' => ['daily']
                ]
            )
        );
       
    }
    public function get_weather_icon($icon){

        if($icon == ''){
            return;
        }

        $iconurl = 'http://openweathermap.org/img/w/'.$icon.'.png';

        $this->add_render_attribute(
            'element_img_wrapper',
            [
                'src' => $iconurl,
                'class' => [ 'element-ready-weather-icon'],
            ]
        );

        return "<img ". $this->get_render_attribute_string( 'element_img_wrapper' )." />";
    }

    protected function render( ) { 
      
        $settings = $this->get_settings();
       
        $api_key = element_ready_get_api_option( 'weather_api_key' );
        $options = [
           'api_key'              => $api_key,
           'coordinates_lat'      => $settings['coordinates_lat'],
           'coordinates_lon'      => $settings['coordinates_lon'],
           'weather_cache_enable' => $settings['weather_cache_enable'],
           'exclude'              => implode(',',$settings['exclude']),
           'units'                => $settings['units'],
        ];

        $icon = '';
        $api_data = Weather_Api::historical($options);   
        if( isset( $api_data->current->weather[0]->icon ) ){
            $icon = $this->get_weather_icon($api_data->current->weather[0]->icon);
        }
        
        $data = isset($api_data->current)?$api_data->current:[];
       
     ?>
         <?php if($settings['layout'] == 'style1'): ?>
            <?php if(isset($api_data->current)): ?>
                    <div class="element-ready-weather-wrapper">

                        <div class="element-ready-weather-time">
                            <h5> <?php echo esc_html($settings['time_title']);  ?> </h5>
                        </div>
                    
                        <?php if( $settings['show_weather_icon'] =='yes' && $icon !=''): ?>
                            <div class="element-ready-weather-icon">
                                <?php echo wp_kses_post($icon); ?>
                            </div> 
                        <?php endif; ?>
                        <?php if( $settings['show_weather_'] =='yes' && isset($data->weather[0]->main)): ?>
                            <div class="element-ready-weather">
                                <h5> <?php echo esc_html($data->weather[0]->main);  ?> </h5>
                            </div>
                        <?php endif; ?>
                        <?php if( $settings['show_weather_desc'] =='yes' && isset($data->weather[0]->description) ): ?>
                            <div class="element-ready-weather-desc">
                                <?php echo esc_html($data->weather[0]->description) ?>
                            </div>  
                        <?php endif; ?>
                        <div class="element-ready-weather-temp">
                            <?php if(isset($data->temp)): ?>
                                <div class="temp">
                                    <?php echo esc_html($data->temp); ?>
                                    <span> 

                                        <?php if($settings['units'] == 'metric'): ?>  
                                            °C
                                        <?php elseif($settings['units'] == 'imperial'): ?>   
                                            °F
                                        <?php else: ?>  
                                            k
                                        <?php endif; ?>

                                    </span>
                                </div>
                                <?php if($settings['humidity_show'] =='yes'): ?>
                                    <div class="humidity">
                                        <?php if($settings['humidity_title'] !=''): ?>
                                            <span> <?php echo esc_html( $settings['humidity_title'] ); ?> </span>
                                        <?php endif; ?>
                                        <?php echo esc_html($data->humidity); ?> 

                                    </div>
                                <?php endif; ?>
                                <?php if($settings['wind_speed_show'] =='yes'): ?>
                                    <div class="wind-speed"> 
                                    <?php if($settings['wind_speed_title'] !=''): ?>
                                            <span> <?php echo esc_html( $settings['wind_speed_title'] ); ?> </span>
                                        <?php endif; ?>
                                        <?php echo esc_html($data->wind_speed); ?> 
                                    </div>
                                <?php endif; ?>
                            
                                <?php if($settings['wind_deg_show'] =='yes'): ?>
                                    <div class="wind-deg"> 
                                    <?php if($settings['wind_deg_title'] !=''): ?>
                                            <span> <?php echo esc_html( $settings['wind_deg_title'] ); ?> </span>
                                        <?php endif; ?>
                                        <?php echo esc_html($data->wind_deg); ?> 
                                    </div>
                                <?php endif; ?>
                                
                                <?php if($settings['pressure'] =='yes'): ?>
                                    <div class="wind-pressure"> 
                                    <?php if($settings['pressure_text'] !=''): ?>
                                            <span> <?php echo esc_html( $settings['pressure_text'] ); ?> </span>
                                        <?php endif; ?>
                                        <?php echo esc_html($data->pressure); ?> 
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div> 

                    </div>
            <?php endif; ?>
            <?php if(isset($api_data->daily)):?>
                <div class="element-ready-weather-daily-wrapper">

                    <?php foreach($api_data->daily as $day): ?>
                        <div class="element-ready-weather-map-item">
                            <div class="element-ready-weather-map-meta">
                                <div class="date"><?php echo date("F j",$day->dt); ?></div>
                                <div class="temperature"> 
                                   <?php echo esc_html($day->temp->day); ?> 
                                        <?php if($settings['units'] == 'metric'): ?>  
                                            °C
                                        <?php elseif($settings['units'] == 'imperial'): ?>   
                                            °F
                                        <?php else: ?>  
                                            k
                                        <?php endif; ?>
                                </div>
                                <div class="windspeed"><?php echo esc_html($day->wind_speed) ?> <?php echo esc_html__('KMPH','element-ready-pro') ?></div>
                                <?php if(isset($day->rain)): ?>
                                    <div class="rain"><?php echo esc_html($day->rain); ?></div>
                                <?php endif; ?>
                                <?php if(isset($day->snow)): ?>
                                    <div class="snow"><?php echo esc_html($day->snow); ?></div>
                                <?php endif; ?>
                               
                            </div>

                            <div class="element-ready-weather-map-details">
          
                                <div class="weather-map-text">
                                    <div class="weather-Sunny">
                                        <div class="weather-map-thumb">
                                            <img height="50" width="50" src="<?php echo esc_url(ELEMENT_READY_ROOT_IMG.'sunrise.svg'); ?>" /> 
                                        </div>
                                        <P><?php echo esc_html($day->weather[0]->main); ?></P>
                                    </div>
                                    
                                    <div class="weather-sunset">
                                        <div class="weather-map-thumb">
                                            <img height="50" width="50" src="<?php echo esc_url(ELEMENT_READY_ROOT_IMG.'sunset.png'); ?>" />
                                        </div>
                                        <p><?php echo esc_html__('sunset','element-ready-pro'); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                   <?php endforeach; ?>   
                  
                </div>
            <?php endif; ?>


      <?php endif; ?>

      <?php if($settings['layout'] == 'style2'): ?>
            <?php if(isset($api_data->current)): ?>
                    <div class="element-ready-weather-wrapper style2">

                        <div class="element-ready-weather-time">
                            <h5> <?php echo esc_html($settings['time_title']);  ?> </h5>
                        </div>
                    
                        <?php if( $settings['show_weather_icon'] =='yes' && $icon !=''): ?>
                            <div class="element-ready-weather-icon">
                                <?php echo wp_kses_post($icon); ?>
                            </div> 
                        <?php endif; ?>
                        <?php if( $settings['show_weather_'] =='yes' && isset($data->weather[0]->main)): ?>
                            <div class="element-ready-weather">
                                <h5> <?php echo esc_html($data->weather[0]->main);  ?> </h5>
                            </div>
                        <?php endif; ?>
                        <?php if( $settings['show_weather_desc'] =='yes' && isset($data->weather[0]->description) ): ?>
                            <div class="element-ready-weather-desc">
                                <?php echo esc_html($data->weather[0]->description) ?>
                            </div>  
                        <?php endif; ?>
                        <div class="element-ready-weather-temp">
                            <?php if(isset($data->temp)): ?>
                                <div class="temp">
                                    <?php echo esc_html($data->temp); ?>
                                    <span> 

                                        <?php if($settings['units'] == 'metric'): ?>  
                                            °C
                                        <?php elseif($settings['units'] == 'imperial'): ?>   
                                            °F
                                        <?php else: ?>  
                                            k
                                        <?php endif; ?>

                                    </span>
                                </div>
                                <?php if($settings['humidity_show'] =='yes'): ?>
                                    <div class="humidity">
                                        <?php if($settings['humidity_title'] !=''): ?>
                                            <span> <?php echo esc_html( $settings['humidity_title'] ); ?> </span>
                                        <?php endif; ?>
                                        <?php echo esc_html($data->humidity); ?> 

                                    </div>
                                <?php endif; ?>
                                <?php if($settings['wind_speed_show'] =='yes'): ?>
                                    <div class="wind-speed"> 
                                    <?php if($settings['wind_speed_title'] !=''): ?>
                                            <span> <?php echo esc_html( $settings['wind_speed_title'] ); ?> </span>
                                        <?php endif; ?>
                                        <?php echo esc_html($data->wind_speed); ?> 
                                    </div>
                                <?php endif; ?>
                            
                                <?php if($settings['wind_deg_show'] =='yes'): ?>
                                    <div class="wind-deg"> 
                                    <?php if($settings['wind_deg_title'] !=''): ?>
                                            <span> <?php echo esc_html( $settings['wind_deg_title'] ); ?> </span>
                                        <?php endif; ?>
                                        <?php echo esc_html($data->wind_deg); ?> 
                                    </div>
                                <?php endif; ?>
                                
                                <?php if($settings['pressure'] =='yes'): ?>
                                    <div class="wind-pressure"> 
                                    <?php if($settings['pressure_text'] !=''): ?>
                                            <span> <?php echo esc_html( $settings['pressure_text'] ); ?> </span>
                                        <?php endif; ?>
                                        <?php echo esc_html($data->pressure); ?> 
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div> 

                    </div>
            <?php endif; ?>
            <?php if(isset($api_data->daily)): ?>
                <div class="element-ready-weather-tabs-wrapper">

                    <div class="element-ready-weather-tabs-item">

                            <?php foreach($api_data->daily as $k => $day): ?>
                                <div style="display:<?php echo $k>0?'none':'block'; ?>" id="<?php echo strtolower(date('D',$day->dt)); ?>" class="element-ready-w3-container city day <?php echo $k>0?'inactive':'active'; ?>">
                                    <div class="element-ready-weather-map-item">
                                        <div class="element-ready-weather-map-meta">
                                            <div class="date"><?php echo date("F j",$day->dt); ?></div>
                                            <div class="temperature">
                                                <?php echo esc_html($day->temp->day); ?> 
                                                <?php if($settings['units'] == 'metric'): ?>  
                                                    °C
                                                <?php elseif($settings['units'] == 'imperial'): ?>   
                                                    °F
                                                <?php else: ?>  
                                                    k
                                                <?php endif; ?>
                                            </div>
                                            <div class="windspeed"><?php echo esc_html($day->wind_speed) ?> <?php echo esc_html__('KMPH','element-ready-pro') ?></div>
                                            <?php if(isset($day->rain)): ?>
                                                <div class="rain"><?php echo esc_html($day->rain); ?></div>
                                            <?php endif; ?>
                                            <?php if(isset($day->snow)): ?>
                                                <div class="snow"><?php echo esc_html($day->snow); ?></div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="element-ready-weather-map-details">
                    
                                            <div class="weather-map-text">
                                                <div class="weather-Sunny">
                                                    <div class="weather-map-thumb">
                                                        <img height="50" width="50" src="<?php echo esc_url(ELEMENT_READY_ROOT_IMG.'icon-1.svg'); ?>" /> 
                                                    </div>
                                                    <P><?php echo esc_html($day->weather[0]->main); ?></P>
                                                </div>
                                                
                                                <div class="weather-sunset">
                                                    <div class="weather-map-thumb">
                                                        <img height="50" width="50" src="<?php echo esc_url(ELEMENT_READY_ROOT_IMG.'icon-2.svg'); ?>" />
                                                    </div>
                                                    <p><?php echo esc_html__('sunset','element-ready-pro'); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                            <div class="element-ready-w3-bar w3-black">
                                <?php foreach($api_data->daily as $k => $day): ?>
                                    <div class="element-ready-w3-bar-item w3-button" onclick="element_ready_weather_daily('<?php echo strtolower(date('D',$day->dt)); ?>')">
                                        <div class="text">
                                            <p><?php echo date('D',$day->dt); ?></p>
                                        </div>
                                        <div class="icon">
                                            <img height="50" width="50" src="<?php echo esc_url(ELEMENT_READY_ROOT_IMG.'icon-1.svg'); ?>" />
                                        </div>
                                        <div class="temperature">
                                            <span> 
                                            <?php echo esc_html($day->temp->day); ?> 
                                                <?php if($settings['units'] == 'metric'): ?>  
                                                    °C
                                                <?php elseif($settings['units'] == 'imperial'): ?>   
                                                    °F
                                                <?php else: ?>  
                                                    k
                                                <?php endif; ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                      </div>
                   </div>

            <?php endif; ?>
            <script>
                function element_ready_weather_daily(dayname) {
                var i;
                var x = document.getElementsByClassName("day");
                for (i = 0; i < x.length; i++) {
                    x[i].style.display = "none";  
                    x[i].classList.remove("active");
               
                }
                document.getElementById(dayname).style.display = "block";  
                document.getElementById(dayname).classList.add("active")  
             
                }
            </script>

      <?php endif; ?>


      <?php  
    }
    

    
}