<?php
namespace Element_Ready_Pro\Widgets\wpdefault;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;

require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

if ( ! defined( 'ABSPATH' ) ) exit;

class Element_Ready_WP_Tag_Cloud extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public function get_name() {
        return 'Element_Ready_Wp_Tag_Cloud';
    }

    public function get_title() {
        return esc_html__( 'ER WP Tag Cloud', 'element-ready-pro' );
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_icon() { 
        return 'eicon-cloud-check';
    }

    public function e_ready_get_taxonomies(){

        $return_data = [];
        $data = get_taxonomies();

        foreach($data as $key => $item){
            $return_data[$key] = ucfirst(str_replace('_',' ',$item));
        }

        $return_data['all'] = esc_html__('All','element-ready-pro');
        return $return_data;
    }

    protected function register_controls() {

        /*---------------------------
            Tag Cloud
        -----------------------------*/
        
         $this->content_text([
            'title' => esc_html__('Settings','element-ready-pro'),
            'slug' => '_heading_content',
            'condition' => '',
            'controls' => [

                
                'advanced_settings' => [
                    'label' => esc_html__( 'Advanced Settings', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Yes', 'element-ready-pro' ),
                    'label_off' => esc_html__( 'No', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default' => '',
                ],
                

                'title_hide' =>   [
                    'label' => esc_html__( 'Hide title', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => '',
                    'options' => [
                        'none'  => esc_html__( 'Yes', 'element-ready-pro' ),
                        '' => esc_html__( 'No', 'element-ready-pro' ),
                    ],
                    'selectors' => [
                       '{{WRAPPER}} .widget-title' => 'display: {{VALUE}};',
                       '{{WRAPPER}} .widgettitle' => 'display: {{VALUE}};',
                    ],
                    'condition' => [
                        'advanced_settings' => ''
                    ]
                ],
               
                'widget_title'=> [
                    'label'   => esc_html__( 'Title', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                    'condition' => [
                        'advanced_settings' => ''
                    ]
                ],

                'show_count' =>   [
                    'label' => esc_html__( 'Show Count', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'no',
                    'options' => [
                        'yes'  => esc_html__( 'Yes', 'element-ready-pro' ),
                        'no' => esc_html__( 'No', 'element-ready-pro' ),
                    ],
                   
                    'condition' => [
                        'advanced_settings' => 'yes'
                    ]
                ],

                
                'number'=> [
                    'label'   => esc_html__( 'Number', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'default' => 20,
                     'condition' => [
                         'advanced_settings' => 'yes'
                     ]
                ],
                               
                'smallest'=> [
                    'label'   => esc_html__( 'Smallest', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'default' => '',
                    'condition' => [
                        'advanced_settings' => 'yes'
                    ]
                ],
                
                'largest'=> [
                    'label'   => esc_html__( 'largest', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'default' => '',
                    'condition' => [
                        'advanced_settings' => 'yes'
                    ]
                ],

                'order' =>   [
                    'label' => esc_html__( 'Order', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'ASC',
                    'options' => [
                        'ASC'  => esc_html__( 'ASC', 'element-ready-pro' ),
                        'DESC' => esc_html__( 'DESC', 'element-ready-pro' ),
                    ],
                    'condition' => [
                        'advanced_settings' => 'yes'
                    ]
                   
                ],

                'separator'=> [
                    'label'   => esc_html__( 'Separator', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                    'condition' => [
                        'advanced_settings' => 'yes'
                    ]
                ],

                

                'taxonomy' =>   [
                    'label' => esc_html__( 'Texonomy', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'all',
                    'options' => $this->e_ready_get_taxonomies(),
                    'condition' => [
                        'advanced_settings' => 'yes'
                    ]
                ],


            ]
         ]);
        /*---------------------------
            Tag END
        -----------------------------*/

        /*--------------------------
            TITLE STYLE
        ----------------------------*/
        $this->text_css(
            array(
                'title' => esc_html__('Title','element-ready-pro'),
                'slug' => '_title_style',
                'element_name' => 'title_element_ready_',
                'selector' => '{{WRAPPER}} .widget-title,{{WRAPPER}} .widgettitle',
                'hover_selector' => '{{WRAPPER}}.widget-title:hover,{{WRAPPER}} .widgettitle:hover',
                'condition' => [
                    'title_hide' => '',
                ],
            )
        );
        /*--------------------------
            TITLE STYLE END
        ----------------------------*/
       
        $this->text_css(
            array(
                'title' => esc_html__('Tag','element-ready-pro'),
                'slug' => '_tag_box_style',
                'element_name' => 'tag_element_ready_',
                'selector' => '{{WRAPPER}} a',
                'hover_selector' => '{{WRAPPER}} a:hover',
            )
        ); 
        
        $this->text_wrapper_css(
            array(
                'title' => esc_html__('Count','element-ready-pro'),
                'slug' => '_count_box_style',
                'element_name' => 'count_element_ready_',
                'selector' => '{{WRAPPER}} .tag-link-count',
                'hover_selector' => '{{WRAPPER}} .tag-link-count:hover',
                'condition' => [
                    'advanced_settings' => 'yes'
                ]
            )
        ); 
        
      
        $this->box_css(
            array(
                'title' => esc_html__('Wrapper','element-ready-pro'),
                'slug' => 'wrapper_body_box_style',
                'element_name' => 'wrapper_body_element_ready_',
                'selector' => '{{WRAPPER}} .tagcloud',
                'condition' => [
                    'advanced_settings' => ''
                ]
               
            )
        );

    
    }

    protected function render() {

      
       $settings         = $this->get_settings();

       if($settings['advanced_settings'] =='yes'){
        add_filter( 'widget_tag_cloud_args', [$this,'filter_tag_cloud'] );
       }

       $widget_args      = [];
       $widget_args['title'] = $settings['widget_title']==''?'':$settings['widget_title']; 
     
       ?>

        <div class="element-ready-wp-widget-tag-cloud">
            <?php the_widget( 'WP_Widget_Tag_Cloud' ,$widget_args); ?>
        </div>
    <?php
    }

   public function filter_tag_cloud(){
        $settings   = $this->get_settings();
        $args = array(
          
        );

        if($settings['number'] !=''){
            $args['number'] = $settings['number'];
        }
        
        if($settings['smallest'] !=''){
            $args['smallest'] = $settings['smallest'];
        }
        
        if($settings['largest'] !=''){
            $args['largest'] = $settings['largest'];
        }
        
        if($settings['separator'] !=''){
            $args['separator'] = $settings['separator'];
        }
        if($settings['order'] !=''){
            $args['order'] = $settings['order'];
        }
        
       if($settings['taxonomy'] !='all'){
         $args['taxonomy'] = $settings['taxonomy'];
        }

        if($settings['show_count'] == 'yes'){
            $args['show_count'] = 1;
        }

        return $args;
    }
    protected function content_template() {}
}

