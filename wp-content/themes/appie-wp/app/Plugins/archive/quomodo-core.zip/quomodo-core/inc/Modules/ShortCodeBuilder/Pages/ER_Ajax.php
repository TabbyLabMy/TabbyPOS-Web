<?php 
namespace Element_Ready_Pro\Modules\ShortCodeBuilder\Pages;
use WP_REST_Request;
use WP_REST_Server;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\File_Maker;
use Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Traits\Common as BuilderCommon;
if ( ! defined( 'ABSPATH' ) ) exit;

Class ER_Ajax {
    use File_Maker;
    use BuilderCommon;
    public $widget_key = ELEMENT_READY_PRO_BUILDER_WIDGET_KEY;  
    public function register(){

     $this->execute();   
     $this->register_rest_route();   
    }

    public function execute(){

        $ajax_data_actions  = [
            'element_ready_pro_scb'                        => 'pro_scb',
            'element_ready_pro_scb_store_cdn'              => 'cdn_store',
            'element_ready_pro_scb_fatch_cdn'              => 'cdn_get',
            'element_ready_pro_scb_widget_settings_'       => '_get_all_widget_seetings',
            'element_ready_pro_scb_set_widget_settings_'   => '_set_all_widget_seetings',
            'element_ready_pro_scb_set_widget_regenerate_' => 'widget_regenerate_',
            'element_ready_pro_scb_remove_widget_'         => 'widget_remove_',
        ];

        foreach( $ajax_data_actions as $action => $method ){

            if( method_exists($this,$method) ){
                
                add_action("wp_ajax_".$action, [$this,$method]);
            }
        }
    }

    public function register_rest_route(){
              
       add_action( 'rest_api_init', [ $this, '_rest_pro_scb' ] );
    }

    public function _rest_pro_scb(){
     
       

        $ajax_data_actions  = [
            'service' => 'set_attribute',
        ];
            // WP_REST_Server::READABLE = ‘GET’,
            // WP_REST_Server::EDITABLE = ‘POST, PUT, PATCH’,
            // WP_REST_Server::DELETABLE = ‘DELETE’,
            // WP_REST_Server::ALLMETHODS = ‘GET, POST, PUT, PATCH, DELETE’
        foreach( $ajax_data_actions as $path => $method ) {
           
            if( method_exists( $this, $method ) ) {
                
                register_rest_route( 'erscb/api', '/'.$path , array(
                    'methods' => WP_REST_Server::READABLE,
                    'callback' => $method ,
                    'permission_callback' => function() { return ''; }
                ));

            }
        }

    }

    public function set_attribute(\WP_REST_Request $request){
         $request_data = $request->username;

         return rest_ensure_response( $request['data'] );
     
    }

    public function pro_scb(){

        if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'element_ready_pro_scb_nonce' ) ) {
            return;
        }

        $return = array(
            'message' => esc_html__( 'Saved', 'element-ready-pro' ),
            'username'      => $_REQUEST['username'],
        
        );

        wp_send_json_success( $return ); 
        wp_die();
        
    } 
    
    public function cdn_store(){

        if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'element_ready_pro_scb_nonce' ) ) {
            return;
        }
        $key = 'element_ready_scb_builder_cdn_list';
        update_option($key, $_REQUEST['cdn_template_data']); 
        $return = array(
            'message' => esc_html__( 'Saved', 'element-ready-pro' ),
            'cdn_template_data'      => get_option($key),
        );
        
        wp_send_json_success( $return ); 
        wp_die();
        
    }
    
    public function cdn_get(){

        if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'element_ready_pro_scb_nonce' ) ) {
            return;
        }
        $key = 'element_ready_scb_builder_cdn_list';
        
        $return = array(
            'message' => esc_html__( 'success', 'element-ready-pro' ),
            'cdn_template_data'      => get_option($key),
        );
        
        wp_send_json_success( $return ); 
        wp_die();
        
    }

    public function _get_all_widget_seetings(){

        if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'element_ready_pro_scb_nonce' ) ) {
            return;
        }

        $post_id = sanitize_text_field($_REQUEST['post_id']);
        $return = array(
            'message' => esc_html__( 'success', 'element-ready-pro' ),
            '_get_all_settings' => get_post_meta($post_id,$this->widget_key,true),
        );
        
        wp_send_json_success( $return ); 
        wp_die();
    }
    public function _set_all_widget_seetings(){

        if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'element_ready_pro_scb_nonce' ) ) {
            return;
        }

        $post_id = sanitize_text_field($_REQUEST['post_id']);
        $settings = $_REQUEST['settings'];
        update_post_meta($post_id,$this->widget_key,$settings);
        $return = array(
            'message' => esc_html__( 'success', 'element-ready-pro' ),
            '_all_settings' => get_post_meta($post_id,$this->widget_key,true),
        );
      
        $s = new \Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Shortcode_Generate();
        $s->single_widget_init($post_id);
        
        wp_send_json_success( $return ); 
        wp_die();
    }

    public function widget_regenerate_(){

        if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'element_ready_pro_scb_nonce' ) ) {
            return;
        }
        try{
            $s = new \Element_Ready_Pro\Modules\ShortCodeBuilder\Base\Shortcode_Generate();
            $s->recreate();
            $return = array(
                'message' => esc_html__( 'Successfully Generated widgets', 'element-ready-pro' ),
               
            );
            wp_send_json_success( $return ); 
        }catch(\Exception $e){
            $return = array(
                'message' => $e->getMessage(),
               
            );
            wp_send_json_error( $return ); 
        }
    
        wp_die();
    }
    
    public function widget_remove_(){
       

        if ( ! wp_verify_nonce( $_REQUEST['nonce'], 'element_ready_pro_scb_nonce' ) ) {
            return;
        }
        try{
            
            $id = sanitize_text_field($_REQUEST['post_id']);
            $widget = $this->get_post($id);
        
            $class_uniq_name = ucfirst('er_scb_'.preg_replace('/\s+/', '_', $widget['slug']));
            $class_uniq_name = preg_replace('/-/', '_', $class_uniq_name);
            $this->remove_widget_from_dir($class_uniq_name);
            
            wp_delete_post($id,true);
            $return = array(
                'message' => esc_html__( 'Widget Deleted', 'element-ready-pro' ),
               
            );

            wp_send_json_success( $return ); 
        }catch(\Exception $e){
            $return = array(
                'message' => $e->getMessage(),
               
            );
            wp_send_json_error( $return ); 
        }
    
        wp_die();
    }

    

}