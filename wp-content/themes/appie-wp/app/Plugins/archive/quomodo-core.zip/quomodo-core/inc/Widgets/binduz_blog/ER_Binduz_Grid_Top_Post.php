<?php
namespace Element_Ready_Pro\Widgets\binduz_blog;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Element_Ready\Base\Repository\Base_Modal;
use Elementor\Group_Control_Image_Size;
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

if ( ! defined( 'ABSPATH' ) ) exit;

class ER_Binduz_Grid_Top_Post extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;
    public $base;

    public function get_name() {
        return 'element-ready-binduz-grid-top-post';
    }

    public function get_title() {
        return esc_html__( 'ER News Card', 'element-ready-pro' );
    }
    public function get_style_depends(){

        wp_register_style( 'element-ready-bunduz-post-card' , ELEMENT_READY_ROOT_CSS. 'widgets/bunduz-post-cart.css' );
        
        return [
            'element-ready-bunduz-post-card'
        ];
    }

    public function get_icon() { 
        return "eicon-post-list";
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    protected function register_controls() {
          
        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'element-ready-pro'),
            ]
        );

        $this->add_control(
			'block_style',
			[
				'label' => esc_html__( 'Style', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'element-ready-pro' ),
					
				],
			]
		);

       $this->end_controls_section();
     
       $this->start_controls_section(
            'section_overlay_general_tab',
                [
                    'label' => esc_html__('General', 'element-ready-pro'),
                ]
            );

                    $this->add_control(
                        'post_count',
                        [
                            'label'         => esc_html__( 'Post count', 'element-ready-pro' ),
                            'type'          => Controls_Manager::NUMBER,
                            'default'       => '8',
                        ]
                    );

                    $this->add_control(
                        'post_title_crop',
                        [
                            'label'         => esc_html__( 'Post Title Crop', 'element-ready-pro' ),
                            'type'          => Controls_Manager::NUMBER,
                            'default'       => '8',
                        ]
                    );
               
                    $this->add_control(
                        'show_content',
                        [
                            'label'     => esc_html__('Content?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'no',
                           
                        ]
                    );

                    $this->add_control(
                        'show_image',
                        [
                            'label'     => esc_html__('Image?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'no',
                           
                        ]
                    );

                    $this->add_group_control(
                        \Elementor\Group_Control_Image_Size::get_type(),
                        [
                            'name' => 'thumb_size', 
                            'exclude' => [ 'custom' ],
                            'include' => [],
                            'default' => 'thumbnail',
                            'condition' => [
                                'show_image' => ['yes']
                            ] 
                        ]
                    );

                    $this->add_control(
                        'show_meta_over_image',
                        [
                            'label'     => esc_html__('Meta Over Image?', 'element-ready-pro'),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'default' => '',
                            'options' => [
                                'cat'  => esc_html__( 'Category', 'element-ready-pro' ),
                                'date' => esc_html__( 'Date', 'element-ready-pro' ),
                                '' => esc_html__( 'None', 'element-ready-pro' ),
                            ],
                            'condition' => [
                                'show_image' => ['yes']
                            ]
                        ]
                    );

                    $this->add_control(
                        'er_image_date_format',
                        [
                           'label'     => esc_html__('Date Format', 'element-ready-pro'),
                           'type' => \Elementor\Controls_Manager::SELECT,
                           'default' => '',
                           'options' => [
                              ''          => '',
                              'F j'       => esc_html__( 'F j', 'element-ready-pro' ),
                              'F , j'       => esc_html__( 'F , j', 'element-ready-pro' ),
                              'l F j Y' => esc_html__( 'l F j Y', 'element-ready-pro' ),
                              'l, F j, Y' => esc_html__( 'l, F j, Y', 'element-ready-pro' ),
                              'l, F j'    => esc_html__( 'l, F j', 'element-ready-pro' ),
                              'l F j'    => esc_html__( 'l F j', 'element-ready-pro' ),
                              'M j Y'    => esc_html__( 'M j Y', 'element-ready-pro' ),
                              'M j, Y'    => esc_html__( 'M j, Y', 'element-ready-pro' ),
                              'M , j'       => esc_html__( 'M , j', 'element-ready-pro' ),
                              'M j'       => esc_html__( 'M j', 'element-ready-pro' ),
                              'Y-m-d'     => esc_html__( 'Y-m-d', 'element-ready-pro' ),
                              'Y/m/d'     => esc_html__( 'Y/m/d', 'element-ready-pro' ),
                              'F Y'      => esc_html__( 'F Y', 'element-ready-pro' ),
                              'F , Y'      => esc_html__( 'F, Y', 'element-ready-pro' ),
                           ],
                           'condition' => [
    
                              'show_meta_over_image' => ['date'],
                              'show_image' => ['yes']
                              
                           ]
                        ]
                     );
               
               
                    $this->add_control(
                        'post_content_crop',
                            [
                                'label'         => esc_html__( 'content Crop', 'element-ready-pro' ),
                                'type'          => Controls_Manager::NUMBER,
                                'default'       => '30',
                                'condition' => [ 'show_content' => ['yes'] ]
                            ]
                    );
               
                    $this->add_control(
                        'show_date',
                        [
                            'label'     => esc_html__('Date?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'yes',
                          
                        ]
                    );

                    $this->add_control(
                        'show_cat',
                        [
                            'label'     => esc_html__('Category?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'no',
                          
                        ]
                    );
      

                    $this->add_control(
                        'show_author',
                        [
                            'label'     => esc_html__('Author?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'no',
                          
                        ]
                    );

                    $this->add_control(
                        'show_author_image',
                        [
                            'label'     => esc_html__('Author Image?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'no',
                          
                        ]
                    );

                    $this->add_control(
                        'show_readmore',
                        [
                            'label'     => esc_html__('Readmore?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'no',
                          
                        ]
                    );

                    $this->add_control(
                        'readmore_text',
                            [
                                'label'         => esc_html__( 'Readmore Text', 'element-ready-pro' ),
                                'type'          => Controls_Manager::TEXT,
                                'default'       => 'readmore',
                                'condition' => [
                                    
                                    'show_readmore' => ['yes']
                                ]
                            ]
                    );

                    $this->add_control(
                        'readmore_icon',
                        [
                            'label' => esc_html__( 'Icon', 'element-ready-pro' ),
                            'type' => \Elementor\Controls_Manager::ICONS,
                            'condition' => [
                                    
                                'show_readmore' => ['yes']
                            ]
                        ]
                    );

                    $this->add_control(
                        'show_comment',
                        [
                            'label'     => esc_html__('Comment?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'no',
                          
                        ]
                    );

                    $this->add_control(
                        'show_comment_text',
                        [
                            'label'     => esc_html__('Comment Text?', 'element-ready-pro'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                            'label_off' => esc_html__('No', 'element-ready-pro'),
                            'default'   => 'no',
                            'condition' => [
                                'show_comment' => ['yes']
                            ]
                          
                        ]
                    );

                    $this->add_control(
                    'comment_text',
                        [
                            'label'         => esc_html__( 'Comment', 'element-ready-pro' ),
                            'type'          => Controls_Manager::TEXT,
                            'default'       => 'comment',
                            'condition' => [
                                'show_comment_text' => ['yes'],
                                'show_comment' => ['yes']
                            ]
                        ]
                    );

                    $this->add_control(
                    'comment_texts',
                        [
                            'label'         => esc_html__( 'Comments', 'element-ready-pro' ),
                            'type'          => Controls_Manager::TEXT,
                            'default'       => 'comments',
                            'condition' => [
                                'show_comment_text' => ['yes'],
                                'show_comment' => ['yes']
                            ]
                        ]
                    );
                      
            $this->end_controls_section();	
            
            $this->start_controls_section(
                'sectionmeta_order_item_tab',
                    [
                        'label' => esc_html__('Item Order', 'element-ready-pro'),
                    ]
                );

                $this->add_control(
                    '_order_title',
                    [
                        'label'      => esc_html__( 'Title', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .binduz-er-title er-news-title-gl' => 'order: {{SIZE}};',
                        ],
                       
                    ]
                );

                $this->add_control(
                    '_order_image',
                    [
                        'label'      => esc_html__( 'Image', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .er-post-thumb' => 'order: {{SIZE}};',
                        ],
                       
                    ]
                );

                $this->add_control(
                    '_order_content',
                    [
                        'label'      => esc_html__( 'Content', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .er-binduz-post-content' => 'order: {{SIZE}};',
                        ],

                        'condition' => [
                            'show_content' => ['yes']
                        ]
                       
                    ]
                );

                $this->add_control(
                    '_order_readmore',
                    [
                        'label'      => esc_html__( 'ReadMore', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .er-post-raed-more' => 'order: {{SIZE}};',
                        ],

                        'condition' => [
                            'show_readmore' => ['yes']
                        ]
                       
                    ]
                );

                $this->add_control(
                    'meta_order_container',
                    [
                        'label'      => esc_html__( 'Meta', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .er-binduz-meta-wrapper' => 'order: {{SIZE}};',
                        ],
                       
                    ]
                );

            $this->end_controls_section();	

            $this->start_controls_section(
                'sectionmeta_order_general_tab',
                    [
                        'label' => esc_html__('Meta Order', 'element-ready-pro'),
                    ]
                );
             
                $this->add_control(
                    'meta_order_comment_control',
                    [
                        'label'      => esc_html__( 'Comment', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .er-binduz-meta-wrapper .binduz-post-comment' => 'order: {{SIZE}};',
                        ],
                        'condition' => [
                            'show_comment' => ['yes']
                        ]
                    ]
                );

                $this->add_control(
                    'meta_order_date_control',
                    [
                        'label'      => esc_html__( 'Date', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .er-binduz-meta-wrapper .binduz-er-meta-date' => 'order: {{SIZE}};',
                        ],
                        'condition' => [
                            'show_date' => ['yes']
                        ]
                    ]
                );

                
                $this->add_control(
                    'meta_order_cat_control',
                    [
                        'label'      => esc_html__( 'Category', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .er-binduz-meta-wrapper .binduz-post-cat' => 'order: {{SIZE}};',
                        ],
                        'condition' => [
                            'show_cat' => ['yes']
                        ]
                    ]
                );

                $this->add_control(
                    'meta_order_author_control',
                    [
                        'label'      => esc_html__( 'Author', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => -20,
                                'max'  => 100,
                                'step' => 1,
                            ],
                        
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .er-binduz-meta-wrapper .binduz-post-author' => 'order: {{SIZE}};',
                        ],
                        'condition' => [
                            'show_author' => ['yes']
                        ]
                    ]
                );

            $this->end_controls_section();	

            $this->content_text([
                'title' => esc_html__('Meta Icon','element-ready-pro'),
                'slug' => '_meta_icons_content',
                'condition' => '',
                'controls' => [
       
                       'meta_icon'=> [
                        'label'         => esc_html__( 'Meta Icon', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::ICONS,
                       ],
                  
                       'meta_date_icon'=> [
                         'label'         => esc_html__( 'Date Icon', 'element-ready-pro' ),
                         'type' => \Elementor\Controls_Manager::ICONS,
                       ],
       
                       'meta_cat_icon'=> [
                           'label'         => esc_html__( 'Category Icon', 'element-ready-pro' ),
                           'type' => \Elementor\Controls_Manager::ICONS,
                       ],
       
                       'meta_comment_icon'=> [
                           'label'         => esc_html__( 'Comment Icon', 'element-ready-pro' ),
                           'type' => \Elementor\Controls_Manager::ICONS,
                       ],
       
                       'meta_author_icon'=> [
                           'label'         => esc_html__( 'Author Icon', 'element-ready-pro' ),
                           'type' => \Elementor\Controls_Manager::ICONS,
                       ],
   
                ]
             ]);
  
     
       do_action( 'element_ready_section_data_exclude_tab', $this , $this->get_name() );  
       do_action( 'element_ready_section_date_filter_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_taxonomy_filter_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_sort_tab', $this , $this->get_name());  
       do_action( 'element_ready_section_sticky_tab', $this , $this->get_name());  
    

      $this->text_css(
         array(
             'title' => esc_html__('Number','element-ready-pro'),
             'slug' => '_title_number_style',
             'element_name' => '_title_number_element_ready_',
             'selector' => '{{WRAPPER}} .binduz-er-top-news-item > span',
             'hover_selector' => '{{WRAPPER}} .binduz-er-top-news-item > span:hover',
             'disable_controls' => [
                'alignment','box-shadow','display','css'
            ]
         )
      );

       $this->box_css(
            array(
                'title' => esc_html__('Title Wrapper','element-ready-pro'),
                'slug' => '_title_wrapper_style',
                'element_name' => '_title_wrapper_element_ready_',
                'selector' => '{{WRAPPER}} .binduz-er-top-news-item .binduz-er-title',
                'hover_selector' => false,
                'disable_controls' => [
                    'bg','alignment','box-shadow','position','display','size','css'
                ]
            
            )
        );

      $this->text_minimum_css(
         array(
             'title' => esc_html__('Title','element-ready-pro'),
             'slug' => '_title__style',
             'element_name' => '_title_apper_element_ready_',
             'selector' => '{{WRAPPER}} .binduz-er-top-news-item .binduz-er-title a',
             'hover_selector' => '{{WRAPPER}} .binduz-er-top-news-item .binduz-er-title:hover a',
             'disable_controls' => [
                'bg','alignment','box-shadow','position','display','size','css','border','dimension'
            ]
            
         )
      );

      $this->text_minimum_css(
        array(
            'title' => esc_html__('Content','element-ready-pro'),
            'slug' => 'poist_content__style',
            'element_name' => '_content_apper_element_ready_',
            'selector' => '{{WRAPPER}} .er-binduz-post-content',
            'hover_selector' => false,
            'disable_controls' => [
               'bg','alignment','position','display','size','css'
           ]
        )
     );

     $this->text_css(
        array(
            'title'          => esc_html__('Meta Over Image','element-ready-pro'),
            'slug'           => 'cat_over_iage_style',
            'element_name'   => '_cat_over_image_apper_element_ready_',
            'selector'       => '{{WRAPPER}} .binduz-post-meta-over-image',
            'hover_selector' => false,
            'condition'      => [
                'show_meta_over_image' => ['cat','date']
            ],
            'disable_controls' => [
             'alignment','display','size','css'
            ]
        )
     );

     $this->box_css(
        array(
            'title' => esc_html__('Thumb Image','element-ready-pro'),
            'slug' => 'post_image_icon_style',
            'element_name' => 'post_image_icon_element_ready_',
            'selector' => '{{WRAPPER}} .er-post-thumb img',
            'hover_selector' => false,
            'condition' => [
                'show_image' => 'yes',
            ],
            'disable_controls' => [
            'alignment','box-shadow','position','display','css','bg'
            ]
        )
    );
   
   


     $this->text_css(
        array(
           'title' => esc_html__('Readmore','element-ready-pro'),
           'slug' => 'post_readmore_buton_style',
           'element_name' => 'post_readmore_element_ready_',
           'selector' => '{{WRAPPER}} .er-post-raed-more',
           'hover_selector' => '{{WRAPPER}} .er-post-raed-more:hover',
           'disable_controls' => [
               'alignment','position','size','css','display'
           ],
           'condition' => [
            'show_readmore' => 'yes',
          ],
        )
    ); 

    $this->text_minimum_css(
        array(
           'title' => esc_html__('ReadMore icon','element-ready-pro'),
           'slug' => 'post_readmore_icon_style',
           'element_name' => 'post_readmore_icon_element_ready_',
           'selector' => '{{WRAPPER}} .er-post-raed-more i',
           'hover_selector' => false,
           'condition' => [
              'show_readmore' => 'yes',
           ],
           'disable_controls' => [
            'alignment','box-shadow','position','display','size','css','bg','border'
          ]
        )
    );

    $this->text_minimum_css(
        array(
           'title' => esc_html__('Meta Text','element-ready-pro'),
           'slug' => 'post_date_style',
           'element_name' => 'post_date_element_ready_',
           'selector' => '{{WRAPPER}} .binduz-er-top-news-item .binduz-er-meta-mod a',
           'hover_selector' => '{{WRAPPER}} .binduz-er-top-news-item .binduz-er-meta-mod a:hover',
           'disable_controls' => [
               'bg','alignment','box-shadow','position','display','size','css'
           ]
        )
    ); 


   
      $this->text_minimum_css(
            array(
               'title' => esc_html__('Meta icon','element-ready-pro'),
               'slug' => 'post_date_icon_style',
               'element_name' => 'post_date_icon_element_ready_',
               'selector' => '{{WRAPPER}} .binduz-er-top-news-item .binduz-er-meta-mod span i',
               'hover_selector' => false,
               'condition' => [
                  'show_date' => 'yes',
               ],
               'disable_controls' => [
                'alignment','box-shadow','position','display','size','css'
              ]
            )
        );

        $this->box_css(
            array(
                'title' => esc_html__('Author Image','element-ready-pro'),
                'slug' => 'post_author_icon_style',
                'element_name' => 'post_auth_icon_element_ready_',
                'selector' => '{{WRAPPER}} .binduz-er-top-news-item .binduz-er-meta-mod img',
                'hover_selector' => false,
                'condition' => [
                    'show_author_image' => 'yes',
                ],
                'disable_controls' => [
                'alignment','box-shadow','position','display','css','bg'
                ]
            )
        );

      $this->box_css(
        array(

            'title'        => esc_html__('Single Box','element-ready-pro'),
            'slug'         => '_box_verwr_box_style',
            'element_name' => '_box_ver_wer_wrapper_element_ready_',
            'selector'     => '{{WRAPPER}} .binduz-er-top-news-item',
            'disable_controls' => [
                'alignment','position','size','css'
            ]
        )
     ); 
     

    }

    protected function render( ) { 

        $settings        = $this->get_settings();
        $post_title_crop = $settings['post_title_crop'];
        $post_count      = $settings['post_count'];
        
   
        if(is_search()){
            global $wp_query;
            $query = $wp_query;
        }else{
            $data  = new Base_Modal($settings);
            $query = $data->get();
        }
        
        if(!$query){
          return;  
        }

        ?>

           <?php if( $settings[ 'block_style' ] == 'style1' ): ?>

                     <?php while ($query->have_posts()) : $query->the_post(); ?>
                         
                           <div class="binduz-er-top-news-item">
                                 <span> <?php echo str_pad($query->current_post+1, 2, "0", STR_PAD_LEFT); ?> </span>
                                 <?php if( $settings['show_meta_over_image'] == 'cat'): ?>
                                        <?php  $categories = get_the_category();
                                            if(! empty( $categories)  ): ?>
                                                
                                            <?php echo '<a class="binduz-post-meta-over-image" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>'; ?>
                                           
                                        <?php endif; ?>
                                <?php endif; ?>
                                <?php if( $settings['show_meta_over_image'] == 'date'): ?>
                                            <?php
                                                $archive_year  = get_the_time( 'Y' ); 
                                                $archive_month = get_the_time( 'm' ); 
                                                $archive_day   = get_the_time( 'd' ); 
                                                $date_content = 'F j';
                                                if($settings['er_image_date_format'] !=''){
                                                    
                                                    $format_arr = explode(',',$settings['er_image_date_format']);
                                
                                                    if(is_array($format_arr)){
                                                        $date_content  = '';
                                                        foreach($format_arr as $item){
                                                            $date_content .= '<span>'. get_the_date( $item ) . '</span>';
                                                        }
                                                    }else{
                                                        $date_content  = get_the_date( $settings['er_image_date_format'] );
                                                    }
                                
                                                }else{
                                                    $date_content  = get_the_date( get_option('date_format') );
                                                }
                                            ?>
                                               
                                            <a class="binduz-post-meta-over-image" href="<?php echo esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ); ?>">
                                                <?php echo wp_kses_post($date_content); ?>
                                            </a>
                                <?php endif; ?>
                                 <?php if(has_post_thumbnail() && $settings['show_image'] == 'yes'): ?>
                                    <?php 
                                        $thumb_link  = Group_Control_Image_Size::get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumb_size', $settings );
                                    ?>
                                   <a class="er-post-thumb" href="<?php the_permalink();?>"><img src="<?php echo esc_url( $thumb_link ) ?>" alt="<?php the_title(); ?>"></a>
                                   
                                <?php endif; ?>
                                 <?php include('parts/title2.php');  ?>
                                
                                 <div class="er-binduz-meta-wrapper">
                                    <?php include('parts/date2.php');  ?>
                                    <?php include('parts/cat.php');  ?>
                                    <?php include('parts/comment.php');  ?>
                                    <?php include('parts/author.php');  ?>
                                </div>

                                <?php if($settings['show_content'] == 'yes'): ?> 
                                 <p class="er-binduz-post-content"> 
                                    <?php echo esc_html(wp_trim_words( get_the_excerpt(), $settings['post_content_crop'],'' )); ?>
                                 </p> 
                                <?php endif; ?> 

                                <?php if( $settings[ 'show_readmore' ] == 'yes' ): ?> 
                                    <a class="er-post-raed-more" href="<?php the_permalink();?>">
                                       <?php echo $settings['readmore_text']; ?>
                                       <?php \Elementor\Icons_Manager::render_icon( $settings['readmore_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </a>
                                <?php endif; ?> 
                                
                          </div>

                       <?php

                           if( $post_count == $query->current_post + 1 ){
                                break;
                            }

                           endwhile; 
                        
                        ?>
                <?php wp_reset_postdata(); ?>
            <?php endif; ?>
           
      <?php  
    }

  

    
}