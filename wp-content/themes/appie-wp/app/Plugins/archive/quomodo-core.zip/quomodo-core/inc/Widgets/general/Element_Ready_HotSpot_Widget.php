<?php
namespace Element_Ready_Pro\Widgets\general;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Element_Ready\Controls\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Element_Ready_HotSpot_Widget extends Widget_Base {

    public function get_name() {
        return 'Element_Ready_HotSpot_Widget';
    }
    
    public function get_title() {
        return __( 'ER HotSport', 'element-ready-pro' );
    }

    public function get_icon() {
        return 'eicon-image-rollover';
    }

    public function get_categories() {
        return [ 'element-ready-pro' ];
    }

    public function get_script_depends() {
      
        return [
           'element-ready-core'
        ];
    }
    public function get_style_depends() {
       
        wp_register_style( 'eready-hotspot' , ELEMENT_READY_ROOT_CSS. 'widgets/hotspot.css' );
        return [ 'eready-hotspot' ];
    }

	public function get_keywords() {
        return [ 'hotspot','er' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            '_content_section',
            [
                'label' => __( 'Content', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

            $this->add_control(
                'layout',
                [
                    'label' => esc_html__( 'Layout', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => '1',
                    'options' => [
                        '1'  => 'Style 1',
                        '2'  => 'Style 2',
                        '3'  => 'Style 3',
                    ],
                ]
            );

            $this->add_control(
                'open_all',
                [
                    'label'        => esc_html__( 'Open All', 'element-ready-pro' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
                    'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                    'condition' => [
                        'layout!' => ['3']
                    ],
                    
                ]
            );

            $this->add_control(
                'content_display_event',
                [
                    'label' => esc_html__( 'Display Event', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'click',
                    'condition' => [
                        'layout' => ['1','2']
                    ],
                    'options' => [
                        'click'  => 'Click',
                        'hover'  => 'Hover',
                   
                    ],
                ]
            );

            $this->add_control(
                'hotspot_icon',
                [
                    'label' => esc_html__( 'Icon', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'default' => [
                        'value' => 'fas fa-eye',
                        'library' => 'fa-solid',
                    ],
                    'condition' => [
                        'layout' => ['3','2']
                    ],
                    
                ]
            );

            $this->add_control(
                'image',
                [
                    'label'   => esc_html__( 'Background Image', 'element-ready-pro' ),
                    'type'    => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ]
                ]
            );

        
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label'       => esc_html__( 'Title', 'element-ready-pro' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'List Title' , 'element-ready-pro' ),
				'label_block' => true
			]
		);

		$repeater->add_control(
			'list_content', [
				'label'      => esc_html__( 'Content', 'element-ready-pro' ),
				'type'       => \Elementor\Controls_Manager::TEXTAREA,
				'default'    => esc_html__( 'List Content' , 'element-ready-pro' ),
				'show_label' => false
			]
		);


        $repeater->add_control(
			'list_button_text', [
				'label'       => esc_html__( 'Button Text', 'element-ready-pro' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Buy Now' , 'element-ready-pro' ),
				'label_block' => true
			]
		);

        $repeater->add_control(
			'website_link',
			[
				'label' => esc_html__( 'Link', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'element-ready-pro' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

        $repeater->add_control(
			'list_left',
			[
				'label' => esc_html__( 'Position Left', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range' => [
					
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 28,
				],
				
			]
		);

    

        $repeater->add_control(
			'list_top',
			[
				'label' => esc_html__( 'Position Top', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range' => [
					
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 41,
				],
				
			]
		);

        $repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => '_listtsbackground',
				'label' => esc_html__( 'Background', 'element-ready-pro' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}.er-hotspot-hotspot,{{WRAPPER}} {{CURRENT_ITEM}} .er--hotspot--lg-hotspot__button:after',
			]
		);

        
        $repeater->add_group_control(
            Group_Control_Border:: get_type(),
                [
                    'name'     => '_listtstable_border',
                    'label'    => esc_html__( 'Border', 'element-ready-pro' ),
                    'selector' => '
                        {{WRAPPER}} {{CURRENT_ITEM}} .er--content,
                        {{WRAPPER}} {{CURRENT_ITEM}}.er-hotspot-hotspot:before,
                        {{WRAPPER}} {{CURRENT_ITEM}} .er--hotspot--lg-hotspot__button
                    ',
                    'separator' => 'before',
                ]
        );

        $repeater->add_responsive_control(
            '_listtstable_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    
                    '{{WRAPPER}} {{CURRENT_ITEM}} .er--content' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    '{{WRAPPER}} {{CURRENT_ITEM}}.er-hotspot-hotspot:before' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .er--hotspot--lg-hotspot__button' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );

		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'HotSpot List', 'element-ready-pro' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
                        'list_top' => [
                            'unit' => '%',
                            'size' => 28,
                        ],
						'list_left' => [
                            'unit' => '%',
                            'size' => 41,
                        ],
						'list_title'   => esc_html__( 'Title #1', 'element-ready-pro' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'element-ready-pro' ),
					],
					[
						'list_title'   => esc_html__( 'Title #2', 'element-ready-pro' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'element-ready-pro' ),
						'list_top' => [
                            'unit' => '%',
                            'size' => 23,
                        ],
						'list_left' => [
                            'unit' => '%',
                            'size' => 73,
                        ],
					],
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

        $this->end_controls_section();
        $this->start_controls_section(
            '_hotspot_icon_style_section',
            [
                'label' => __( 'HotSpot Icon', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
               
            ]
        );

        
            $this->start_controls_tabs(
                '_icon__wrapstyle_tabs'
            );
            
            $this->start_controls_tab(
                'style_icon_tab',
                [
                    'label' => esc_html__( 'Icon', 'element-ready-pro' ),
                ]
            );

                $this->add_control(
                    'pulse_type',
                    [
                        'label' => esc_html__( 'Icon Pulse', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => 'pulse_two',
                        'options' => [
                            'pulse_one'  => 'Pulse One',
                            'pulse_two'  => 'Pulse Two',
                        ],
                    ]
                );

                $this->add_control(
                    'animation_type',
                    [
                        'label' => esc_html__( 'Animation Type', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => '',
                        'options' => [
                            ''  => 'None',
                            'wheel'  => 'Wheel',
                            'slack'  => 'Slack',
                        ],
                        'condition' => [
                            'layout' => ['3','2' ]
                        ]
                    ]
                );

                $this->add_control(
                    'icon_pulse_color',
                    [
                        'label' => esc_html__( 'Pulse Color', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .pulse_two' => '--er_hostspot_keyframe_pulse_color: {{VALUE}}',
                            // '{{WRAPPER}} .er--trigger' => '--er_hostspot_keyframe_pulse_color: {{VALUE}}',
                        ],
                        'condition' => [
                            'pulse_type!' => ['pulse_one']
                        ]
                    ]
                );

                $this->add_control(
                    'adasdasd_color_update',
                    [
                        'label' => esc_html__( 'Color Update', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => esc_html__( 'Show', 'element-ready-pro' ),
                        'label_off' => esc_html__( 'Hide', 'element-ready-pro' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                        'condition' => [
                            'layout' => ['3']
                        ]
                    ]
                );

                $this->add_control(
                    'icon__color',
                    [
                        'label' => esc_html__( 'Icon Color', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .er-hotspot-icon' => 'color: {{VALUE}}',
                        ],
                        'condition' => [
                            'layout' => ['3']
                        ]
                    ]
                );


                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'hotspot_spotbackground',
                        'label' => esc_html__( 'Background', 'element-ready-pro' ),
                        'types' => [ 'classic' ],
                        'condition' => [
                            'layout' => ['1','2']
                        ],
                        'selector' => '{{WRAPPER}} .er-hotspot-hotspot:before,{{WRAPPER}} .er--hotspot--lg-hotspot__button::after',
                    ]
                );

                $this->add_control(
                    'rotate_icon',
                    [
                        'label' => esc_html__( 'Rotate Icon On Click', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => esc_html__( 'Yes', 'element-ready-pro' ),
                        'label_off' => esc_html__( 'No', 'element-ready-pro' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                        'condition' => [
                            'layout' => ['1']
                        ]
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'hotspot_iconsr__border',
                        'label' => esc_html__( 'Border', 'element-ready-pro' ),
                        'selector' => '
                        {{WRAPPER}} .er--hotspots .er--hotspot .er--trigger,
                        {{WRAPPER}} .er-hotspot-hotspot:before,
                        {{WRAPPER}} .er--hotspot--lg-hotspot__button
                        ',
                    ]
                );

                $this->add_responsive_control(
                    'hotspot_icons__border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'selectors' => [

                            '{{WRAPPER}} .er--hotspots .er--hotspot .er--trigger' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            '{{WRAPPER}} .er-hotspot-hotspot:before' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            '{{WRAPPER}} .er--hotspot--lg-hotspot__button' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        ],
                    ]
                );
            
            $this->end_controls_tab();

            $this->start_controls_tab(
                'style_conten_icon_tab',
                [
                    'label' => esc_html__( 'Click Content', 'element-ready-pro' ),
                    'condition' => [
                        'layout' => ['1']
                    ]
                ]
            );

                $this->add_control(
                    'icon_title_color',
                    [
                        'label' => esc_html__( 'Color', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .er-hotspot-hotspot' => 'color: {{VALUE}}',
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Typography::get_type(),
                    [
                        'name' => 'icon_titlecontent_typography',
                        'selector' => '{{WRAPPER}} .er-hotspot-hotspot',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'hotspot_wrapper_iconbackground',
                        'label' => esc_html__( 'Background', 'element-ready-pro' ),
                        'types' => [ 'classic' ],
                        'selector' => '{{WRAPPER}} .er-hotspot-hotspot',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'hotspot_wrapper__border',
                        'label' => esc_html__( 'Border', 'element-ready-pro' ),
                        'selector' => '{{WRAPPER}} .er-hotspot-hotspot',
                    ]
                );

                $this->add_responsive_control(
                    'hotspot_wrapper__border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'selectors' => [
                            '{{WRAPPER}} .er-hotspot-hotspot' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        ],
                    ]
                );

            $this->end_controls_tab();
            
            $this->end_controls_tabs();
        $this->end_controls_section();
        // TABLE STYLE
        $this->start_controls_section(
            '_table_style_section',
            [
                'label' => __( 'Active Details', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                
            ]
        );

            $this->start_controls_tabs(
                'hot__style_tabs'
            );
            
            $this->start_controls_tab(
                'style_button_normal_tab',
                [
                    'label' => esc_html__( 'Normal', 'element-ready-pro' ),
                ]
            );

            $this->add_control(
                'text_align',
                [
                    'label' => esc_html__( 'Alignment', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => esc_html__( 'Left', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__( 'Center', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => esc_html__( 'Right', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'default' => 'left',
                    'toggle' => true,
                    'selectors' => [
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .er-hotspot-hotspots-label.er-hotspot-is-visible' => 'justify-content: {{VALUE}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'justify-content: {{VALUE}};',
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption' => 'justify-content: {{VALUE}};',
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content .figure figcaption' => 'text-align: {{VALUE}}; ',
                    ],
                ]
            );

       

            $this->add_control(
                'active_content_display',
                [
                    'label' => esc_html__( 'Display', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'inline-block',
                    'options' => [
                        'block' => esc_html__( 'Block', 'element-ready-pro' ),
                        'inline-block' => esc_html__( 'Inline Block', 'element-ready-pro' ),
                        'flex' => esc_html__( 'Flex', 'element-ready-pro' ),
                   ],
                    'selectors' => [
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'display: {{VALUE}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'display: {{VALUE}};',
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption' => 'display: {{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'h_text_align',
                [
                    'label' => esc_html__( 'Horizontal Alignment', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'options' => [
                        'flex-start' => [
                            'title' => esc_html__( 'Left', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__( 'Center', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'flex-end' => [
                            'title' => esc_html__( 'Right', 'element-ready-pro' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'condition' => [
                        'active_content_display' => [
                            'flex'
                        ]
                    ],
                    'default' => 'flex-start',
                    'toggle' => true,
                    'selectors' => [

                        '{{WRAPPER}} .er-hotspot-hotspots-label.er-hotspot-is-visible' => 'align-items:{{VALUE}};',

                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'align-items:{{VALUE}};',
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption' => 'align-items:{{VALUE}};',

                    ],
                ]
            );

            $this->add_control(
                'flex_direction',
                [
                    'label' => esc_html__( 'Flex Direction', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'inline-block',
                    'options' => [
                        'row' => esc_html__( 'Row', 'element-ready-pro' ),
                        'column' => esc_html__( 'Column', 'element-ready-pro' ),
                      
                   ],
                   'condition' => [
                    'active_content_display' => ['flex']
                   ],
                    'selectors' => [
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'flex-direction: {{VALUE}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'flex-direction: {{VALUE}};',
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption' => 'flex-direction: {{VALUE}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'flex_direction_gap',
                [
                    'label' => esc_html__( 'Gap', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 200,
                            'step' => 1,
                        ],
                      
                    ],
                  
                    'selectors' => [
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'gap: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'gap: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption' => 'gap: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => [
                        'active_content_display' => ['flex']
                    ],
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => esc_html__( 'Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                       '{{WRAPPER}} .er-hotspot-hotspots-label' => 'color: {{VALUE}}',
                       '{{WRAPPER}} .er--hotspot--lg-hotspot__label p' => 'color: {{VALUE}}',
                       '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'title_more_options',
                [
                    'label' => esc_html__( 'Title', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'heading_color',
                [
                    'label' => esc_html__( 'Title Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                       '{{WRAPPER}} .er-hotspot-hotspots-label h4' => 'color: {{VALUE}}',
                       '{{WRAPPER}} .er--hotspot--lg-hotspot__label h4' => 'color: {{VALUE}}',
                       '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption h4' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'label' => esc_html__( 'Title Typography', 'element-ready-pro' ),
                    'name' => 'title_typography',
                    'selector' => '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption h4,{{WRAPPER}} .er-hotspot-hotspots-label h4,{{WRAPPER}} .er--hotspot--lg-hotspot__label h4',
                ]
            );

            $this->add_responsive_control(
                'title___margin',
                [
                    'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                   
                    'selectors'  => [
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .er-hotspot-hotspots-label h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name'     => 'title___background',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption h4,{{WRAPPER}} .er-hotspot-hotspots-label h4, {{WRAPPER}} .er--hotspot--lg-hotspot__label h4',
                ]
            );

             $this->add_control(
                'button_more_options',
                [
                    'label' => esc_html__( 'Button', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'button_color',
                [
                    'label' => esc_html__( 'Button Color', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                       '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption a' => 'color: {{VALUE}}',
                       '{{WRAPPER}} .er-hotspot-hotspots-label a' => 'color: {{VALUE}}',
                       '{{WRAPPER}} .er--hotspot--lg-hotspot__label a' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'label' => esc_html__( 'Button Typography', 'element-ready-pro' ),
                    'name' => 'button_typography',
                    'selector' => '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption a, {{WRAPPER}} .er-hotspot-hotspots-label a,{{WRAPPER}} .er--hotspot--lg-hotspot__label a',
                ]
            );

            
            $this->add_responsive_control(
                'button__margin',
                [
                    'label'      => esc_html__( 'Button Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                   
                    'selectors'  => [
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};display:inline-block;',
                        '{{WRAPPER}} .er-hotspot-hotspots-label a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};display:inline-block;',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};display:inline-block;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'button__padding',
                [
                    'label'      => esc_html__( 'Button Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                   
                    'selectors'  => [
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .er-hotspot-hotspots-label a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name'     => 'button___background',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient'],
                    'selector' => '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figure figcaption a,{{WRAPPER}} .er-hotspot-hotspots-label a, {{WRAPPER}} .er--hotspot--lg-hotspot__label a',
                ]
            );

            $this->add_control(
                'container_more_options',
                [
                    'label' => esc_html__( 'Container', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'content_typography',
                    'selector' => '{{WRAPPER}} .er--hotspots .er--hotspot .er--content,{{WRAPPER}} .er-hotspot-hotspots-label,{{WRAPPER}} .er--hotspot--lg-hotspot__label',
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name'     => 'table_background',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient'],
                    'selector' => '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figcaption ,{{WRAPPER}} .er-hotspot-hotspots-label, {{WRAPPER}} .er--hotspot--lg-hotspot__label',
                ]
            );

            $this->add_group_control(
                Group_Control_Border:: get_type(),
                    [
                        'name'     => 'table_border',
                        'label'    => esc_html__( 'Border', 'element-ready-pro' ),
                        'selector' => '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figcaption,{{WRAPPER}} .er-hotspot-hotspots-label, {{WRAPPER}} .er--hotspot--lg-hotspot__label',
                        'separator' => 'before',
                    ]
            );

            $this->add_responsive_control(
                'table_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figcaption' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'table_padding',
                [
                    'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'default' => [
                        'top' => 10,
                        'bottom' => 10,
                        'left' => 10,
                        'right' => 10,
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figcaption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'table_margin',
                [
                    'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                   
                    'selectors'  => [
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figcaption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );


            $this->add_responsive_control(
                'position_detail_bottom',
                [
                    'label' => esc_html__( 'Bottom', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figcaption' => 'bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'top: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'position_detail__left',
                [
                    'label' => esc_html__( 'Left', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figcaption' => 'left: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .er-hotspot-hotspots-label' => 'left: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .er--hotspot--lg-hotspot__label' => 'left: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

           
            
            $this->end_controls_tab();

            $this->start_controls_tab(
                'style_button_hover_tab',
                [
                    'label' => esc_html__( 'Hover', 'element-ready-pro' ),
                ]
            );
            
                $this->add_control(
                    'title_hover_color',
                    [
                        'label' => esc_html__( 'Title Color', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .er--hotspots .er--hotspot .er--content figcaption:hover h4' => 'color: {{VALUE}}',
                            '{{WRAPPER}} .er-hotspot-hotspots-label:hover h4' => 'color: {{VALUE}}',
                            '{{WRAPPER}} .er--hotspot--lg-hotspot__label:hover h4' => 'color: {{VALUE}}',
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name'     => 'hover_table_background',
                        'label'    => __( 'Background', 'element-ready-pro' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .er--hotspots .er--hotspot .er--content,{{WRAPPER}} .er-hotspot-hotspots-label:hover h4,{{WRAPPER}} .er--hotspot--lg-hotspot__label:hover h4',
                    ]
                );

                $this->add_control(
                    'input_box_transition',
                    [
                        'label'      => __( 'Transition', 'element-ready-pro' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min'  => 0.1,
                                'max'  => 3,
                                'step' => 0.1,
                            ],
                        ],
                        'default' => [
                            'unit' => 'px',
                            'size' => 0.3,
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .er--hotspots .er--hotspot .er--content h4'   => 'transition: {{SIZE}}s;',
                            '{{WRAPPER}} .er-hotspot-hotspots-label h4'   => 'transition: {{SIZE}}s;',
                            '{{WRAPPER}} .er--hotspot--lg-hotspot__label h4'   => 'transition: {{SIZE}}s;',
                           
                        ],
                    ]
                );


            $this->end_controls_tab();
            
            $this->end_controls_tabs();
    

        $this->end_controls_section();
          

     
   }

    protected function render( $instance = [] ) {

        $settings = $this->get_settings_for_display();
        $url = '#';
    
        ?> 
        <?php if($settings['layout'] == '1'): ?>  
            <?php
                $this->add_render_attribute( 'er_hotspot_content_wrap_attr', 'class', 'element__ready____hotspot__wrap' );
                $this->add_render_attribute( 'er_hotspot_content_wrap_attr', 'data-event', $settings['content_display_event']);
                $this->add_render_attribute( 'er_hotspot_content_wrap_attr', 'data-open_all', $settings['open_all']);
                $this->add_render_attribute( 'er_hotspot_wrap_attr', 'class', 'er-hotspot-contain' );
                $rotate_icon = $settings['rotate_icon'] == 'yes' ? 'rotate' : '';
                $list = $settings['list']; 
                if(isset($settings['image']['url'])){
                    $url = $settings['image']['url'];
                    $this->add_render_attribute( 'er_hotspot_wrap_attr', 'style', 
                    "background-image: url($url);"
                    );
                }    
            ?> 
            <div <?php echo $this->get_render_attribute_string( 'er_hotspot_content_wrap_attr' ); ?>>
                <div class="er-hotspot-image">
                    <div <?php echo $this->get_render_attribute_string( 'er_hotspot_wrap_attr' ); ?>>
                        <?php foreach($list as $item): 
                            $buton_url  = $item['website_link']['url'];
                            ?>  
                            <a 
                                class="elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?> er-hotspot-hotspot <?php echo $rotate_icon; ?>" 
                                data-left="<?php echo $item['list_left']['size']; ?>" 
                                data-top="<?php echo $item['list_top']['size']; ?>" 
                                data-button-text="<?php echo $item['list_button_text']; ?>" 
                                data-button-url="<?php echo esc_url($buton_url); ?>" 
                                data-text="<?php echo $item['list_content']; ?>">
                                
                                <?php echo $item['list_title']; ?>
                            </a>
                        <?php endforeach ?>
                       
                        <div class="er-hotspot-hotspots-label"></div>
                    </div>
                </div> 
            </div>
        <?php elseif($settings['layout'] == '2'): ?> 
            <?php
                $this->add_render_attribute( 'er_hotspot_content_wrap_attr', 'class', 'element__ready____hotspot__wrap' );
                $this->add_render_attribute( 'er_hotspot_content_wrap_attr', 'data-event', $settings['content_display_event']);
                $this->add_render_attribute( 'er_hotspot_content_wrap_attr', 'data-open_all', $settings['open_all']);
                $this->add_render_attribute( 'er_hotspot_wrap_attr', 'class', 'er--hotspot--er-hotspot-contain' );
                $rotate_icon = $settings['rotate_icon'] == 'yes' ? 'rotate' : '';
                $list = $settings['list']; 
                if(isset($settings['image']['url'])){
                    $url = $settings['image']['url'];
                }  
                $has_icon = isset($settings['hotspot_icon']['value']) && $settings['hotspot_icon']['value'] !=''? 'icon' : 'no-icon';  
            ?> 
              <div <?php echo $this->get_render_attribute_string( 'er_hotspot_content_wrap_attr' ); ?>>
                <img class="er--hotspot--lg-image" src="<?php echo $url; ?>"/>
                <?php foreach($list as $item): 
                
                    $buton_url  = $item['website_link']['url'];
                    ?>  
                    <div style="top: <?php echo $item['list_top']['size']; ?>%; left: <?php echo $item['list_left']['size']; ?>%;" class="er--hotspot--lg-hotspot er--hotspot--lg-hotspot--top-left elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?>">
                        <div style="--er_hostspot_keyframe_pulse_color: <?php echo $settings['icon_pulse_color']; ?>;--er_hostspot_keyframe_pulse_hover_color: <?php echo element_ready_hex2rgba( $settings['icon_pulse_color']); ?>" data-normal_color="<?php echo $settings['icon_pulse_color']; ?>" data-color="<?php echo element_ready_hex2rgba( $settings['icon_pulse_color']); ?>" class="er--hotspot--lg-hotspot__button <?php echo $settings['pulse_type']; ?> <?php echo $has_icon.' '.$settings['animation_type']; ?>">
                            <?php \Elementor\Icons_Manager::render_icon( $settings['hotspot_icon'], [ 'class' => 'er-hotspot-icon' ] ); ?>
                        </div>
                        <div class="er--hotspot--lg-hotspot__label">
                            <h4><?php echo $item['list_title']; ?></h4>
                            <?php echo wpautop( $item['list_content'] ); ?>
                            <?php if($item['list_button_text'] !=''): ?>
                                <a href="<?php echo esc_url($buton_url); ?>"> <?php echo $item['list_button_text']; ?> </a>
                            <?php endif; ?> 
                        </div>
                    </div>
                <?php endforeach ?>
                
            </div>
        <?php elseif($settings['layout'] == '3'): 
           
            $list = $settings['list']; 
            $has_icon = isset($settings['hotspot_icon']['value']) && $settings['hotspot_icon']['value'] !=''? 'icon' : 'no-icon';
            if(isset($settings['image']['url'])){
                $url = $settings['image']['url'];
            }
            $this->add_render_attribute( 'er_hotspot_content_wrap_attr', 'class', 'element__ready____hotspot__wrap er-hotspot-main' );
                $this->add_render_attribute( 'er_hotspot_content_wrap_attr', 'data-event', $settings['content_display_event']);
                
            ?> 
            
            <main <?php echo $this->get_render_attribute_string( 'er_hotspot_content_wrap_attr' ); ?>>
                <div class="er-hotspot-container">
                    <div class="er--media">
                        <figure>
                            <img src="<?php echo esc_url($url); ?>"/>
                        </figure>
                    </div>
                    <div class="er--hotspots">
                    <?php foreach($list as $item): 
                        $buton_url  = $item['website_link']['url'];
                        ?>
                        <div class="er--hotspot elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?>">
                            <div style="--er_hostspot_keyframe_pulse_color: <?php echo $settings['icon_pulse_color']; ?>;--er_hostspot_keyframe_pulse_hover_color: <?php echo element_ready_hex2rgba( $settings['icon_pulse_color']); ?>" data-normal_color="<?php echo $settings['icon_pulse_color']; ?>" data-color="<?php echo element_ready_hex2rgba( $settings['icon_pulse_color']); ?>" data-top="<?php echo $item['list_top']['size']; ?>" data-left="<?php echo $item['list_left']['size']; ?>" class="er--trigger <?php echo $has_icon.' '.$settings['animation_type']; ?>">
                            <?php \Elementor\Icons_Manager::render_icon( $settings['hotspot_icon'], [ 'class' => 'er-hotspot-icon' ] ); ?>
                            </div>
                            <div class="er--content">
                                <figure class="figure">
                                    <?php if(isset($item['_listtsbackground_image']['url'])): ?> 
                                    <img src="<?php echo esc_url($item['_listtsbackground_image']['url']); ?>"/>
                                    <?php endif; ?>
                                    <figcaption>
                                        <h4> <?php echo $item['list_title']; ?> </h4> 
                                        <?php echo wpautop( $item['list_content'] ); ?>
                                        <?php if($item['list_button_text'] !=''): ?>
                                        <a href="<?php echo esc_url($buton_url); ?>"> <?php echo $item['list_button_text']; ?> </a>
                                    <?php endif; ?> 
                                    </figcaption>

                                </figure>
                            </div>
                        </div>
                        <?php endforeach ?>
                    </div>
                </div>
            </main>
       <?php endif; ?>    
        <?php
    }
}