<?php
namespace Element_Ready_Pro\Widgets\welcome;

use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Element_Ready_Site_Title extends Widget_Base {

    public function get_name() {
        return 'Element_Ready_Site_Title_Widget';
    }
    
    public function get_title() {
        return __( 'ER Site Title', 'element-ready-pro' );
    }

    public function get_icon() {
        return 'eicon-heading';
    }
    
	public function get_categories() {
		return [ 'element-ready-pro' ];
    }
    
    public function get_keywords() {
        return [ 'title','site title','er site title' ];
    }
  
    protected function register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'element-ready-pro' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'enable_link',
			[
				'label' => esc_html__( 'Enable Link', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'yes', 'element-ready-pro' ),
				'label_off' => esc_html__( 'no', 'element-ready-pro' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'heading_tag',
			[
				'label' => esc_html__( 'Tag', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'h1',
				'options' => [
					'h1'  => esc_html__( 'H1', 'element-ready-pro' ),
					'h2' => esc_html__( 'H2', 'element-ready-pro' ),
					'h3' => esc_html__( 'H3', 'element-ready-pro' ),
					'h4' => esc_html__( 'H4', 'element-ready-pro' ),
					
				],
			]
		);

		$this->add_control(
			'text_align',
			[
				'label' => esc_html__( 'Alignment', 'element-ready-pro' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'element-ready-pro' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'element-ready-pro' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'element-ready-pro' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}}',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'element-ready-pro' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->start_controls_tabs(
				'style_tabs'
			);
			
			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'element-ready-pro' ),
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' => esc_html__( 'Color', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .er-site-title' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'content_typography',
					'selector' => '{{WRAPPER}} .er-site-title',
				]
			);

			$this->add_control(
				'opacity',
				[
					'label' => esc_html__( 'opacity', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					
					'range' => [
						'px' => [
							'min'  => 0,
							'max'  => 1,
							'step' => 0.1
						],
					
					],
					'selectors' => [
						'{{WRAPPER}} .er-site-title' => 'opacity: {{SIZE}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'er_box_shadow',
					'label' => esc_html__( 'Box Shadow', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .er-site-title',
				]
			);
  
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'title_border',
					'label' => esc_html__( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .er-site-title',
				]
			);
		
			
			$this->end_controls_tab();

			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'element-ready-pro' ),
				]
			);

			$this->add_control(
				'hover_title_color',
				[
					'label' => esc_html__( 'Hover Color', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .er-site-title:hover' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'hover_opacity',
				[
					'label' => esc_html__( 'Hover opacity', 'element-ready-pro' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					
					'range' => [
						'px' => [
							'min'  => 0,
							'max'  => 1,
							'step' => 0.1
						],
					
					],
					'selectors' => [
						'{{WRAPPER}} .er-site-title:hover' => 'opacity: {{SIZE}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'hover_border',
					'label' => esc_html__( 'Hover Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .er-site-title:hover',
				]
			);

			$this->end_controls_tab();
			
			$this->end_controls_tabs();
	
        $this->end_controls_section();
    }

    protected function render( $instance = [] ) {

      $settings   = $this->get_settings_for_display();
      $site_title = get_bloginfo( 'name' );

	 ?>
      <?php if($settings['enable_link'] == 'yes'): ?> 
        <a href="<?php echo get_home_url() ?>">
		   <<?php echo $settings['heading_tag']; ?> class="er-site-title">
              <?php echo $site_title; ?>  
	       </<?php echo $settings['heading_tag']; ?>>
        </a> 
      <?php else: ?>
		 <<?php echo $settings['heading_tag']; ?> class="er-site-title">
           <?php echo $site_title; ?>  
	  	 </<?php echo $settings['heading_tag']; ?>>
      <?php endif; ?>

    <?php
    }
}