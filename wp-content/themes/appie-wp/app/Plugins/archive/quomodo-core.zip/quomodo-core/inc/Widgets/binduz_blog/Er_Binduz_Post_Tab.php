<?php
namespace Element_Ready_Pro\Widgets\binduz_blog;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

if ( ! defined( 'ABSPATH' ) ) exit;

class Er_Binduz_Post_Tab extends Widget_Base {

   use \Elementor\Element_Ready_Common_Style;
   use \Elementor\Element_ready_common_content;
   use \Elementor\Element_Ready_Box_Style;

	public function get_name() {
		return 'element-ready-binduz-grid-post-tabs';
	}

	public function get_title() {
		return esc_html__( 'ER News tab', 'element-ready-pro' );
	}

	public function get_icon() {
		return "eicon-tabs";
	}

	public function get_categories() {
		return [ 'element-ready-pro' ];
    }
   
    public function get_style_depends(){
            
        wp_register_style( 'element-ready-binduz-post-slider' , ELEMENT_READY_ROOT_CSS. 'widgets/binduz-post-slider.css' );
        
        return [
            'element-ready-binduz-post-slider','modal-video'
        ];
      
    }
    
    public function get_script_depends() {
        return [
            'element-ready-core','modal-video'
        ];
    }

	protected function register_controls() {
        
        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'element-ready-pro'),
            ]
        );

                $this->add_control(
                    'block_style',
                    [
                        'label'   => esc_html__( 'Style', 'element-ready-pro' ),
                        'type'    => \Elementor\Controls_Manager::SELECT,
                        'default' => 'style2',
                        'options' => [
                            'style1' => esc_html__( 'Style 1', 'element-ready-pro' ),
                            'style2' => esc_html__( 'Style 2', 'element-ready-pro' ),
                            'style3' => esc_html__( 'Style 3', 'element-ready-pro' ),
                      
                        ],
                    ]
                );

       $this->end_controls_section();
 
   
      $this->start_controls_section(
         'section_tab',
         [
             'label' => esc_html__('Post', 'element-ready-pro'),
         ]
     );
   
            $this->add_control(
                'post_count',
                [
                'label'   => esc_html__( 'Post count', 'element-ready-pro' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => '8',
                ]
            );
            
            $this->add_control(
                'post_title_crop',
                [
                    'label'   => esc_html__( 'Post title crop', 'element-ready-pro' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => '50',
                ]
            );  
            
            
            $this->add_control(
                'show_content',
                [
                    'label'     => esc_html__('Show content', 'element-ready-pro'),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                    'label_off' => esc_html__('No', 'element-ready-pro'),
                    'default'   => 'yes',
                   
                ]
            );

       
            $this->add_control(
                'post_content_crop',
                    [
                        'label'         => esc_html__( 'Post content crop', 'element-ready-pro' ),
                        'type'          => Controls_Manager::NUMBER,
                        'default'       => '18',
                        'condition' => [ 'show_content' => ['yes'] ]
                    ]
            );

            $this->add_control(
                'show_post_meta',
                [
                    'label'     => esc_html__('Post Meta', 'element-ready-pro'),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                    'label_off' => esc_html__('No', 'element-ready-pro'),
                    'default'   => 'yes',
                ]
            );

             $this->add_control(
                'show_post_meta_toggle',
                [
                   'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                   'label' => esc_html__( 'Post Top Meta', 'element-ready-pro' ),
                   'label_off' => esc_html__( 'Default', 'element-ready-pro' ),
                   'label_on' => esc_html__( 'Custom', 'element-ready-pro' ),
                   'return_value' => 'no',
                  
                ]
             );
             
             $this->start_popover();

             $this->add_control(
                'top_meta_enable',
                [
                   'label'     => esc_html__('Enable', 'element-ready-pro'),
                   'type'      => Controls_Manager::SWITCHER,
                   'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                   'label_off' => esc_html__('No', 'element-ready-pro'),
                   'default'   => 'no',
                   'condition' => [
                      'show_post_meta' => ['yes']
                   ]
                ]
          );

             $this->add_control(
                   'show_top_author',
                   [
                      'label'     => esc_html__('Show Author', 'element-ready-pro'),
                      'type'      => Controls_Manager::SWITCHER,
                      'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                      'label_off' => esc_html__('No', 'element-ready-pro'),
                      'default'   => 'no',
                      'condition' => [
                         'top_meta_enable' => ['yes']
                      ]
                   ]
             );

             $this->add_control(
                'show_top_author_image',
                [
                   'label'     => esc_html__('Show Author Image', 'element-ready-pro'),
                   'type'      => Controls_Manager::SWITCHER,
                   'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                   'label_off' => esc_html__('No', 'element-ready-pro'),
                   'default'   => 'no',
                   'condition' => [
                      'top_meta_enable' => ['yes']
                   ]
                ]
          );

             $this->add_control(
                'show_top_date',
                [
                   'label'     => esc_html__('Show Date', 'element-ready-pro'),
                   'type'      => Controls_Manager::SWITCHER,
                   'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                   'label_off' => esc_html__('No', 'element-ready-pro'),
                   'default'   => 'yes',
                   'condition' => [
                      'top_meta_enable' => ['yes']
                   ]
                ]
          );

             $this->add_control(
                'show_top_cat',
                [
                   'label'     => esc_html__('Show Cat', 'element-ready-pro'),
                   'type'      => Controls_Manager::SWITCHER,
                   'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                   'label_off' => esc_html__('No', 'element-ready-pro'),
                   'default'   => 'no',
                   'condition' => [
                      'top_meta_enable' => ['yes']
                   ]
                ]
              );

              $this->add_control(
                'show_top_cat_icon',
                [
                   'label' => esc_html__( 'Category Icon', 'element-ready-pro' ),
                   'type' => \Elementor\Controls_Manager::ICONS,
                   'condition' => [
                      'show_top_cat' => ['yes']
                   ]
                ]
             );
       

              $this->add_control(
                'show_top_comment',
                [
                   'label'     => esc_html__('Show Comment', 'element-ready-pro'),
                   'type'      => Controls_Manager::SWITCHER,
                   'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                   'label_off' => esc_html__('No', 'element-ready-pro'),
                   'default'   => 'no',
                   'condition' => [
                      'top_meta_enable' => ['yes']
                   ]
                ]
             );
                
             $this->end_popover();

             $this->add_control(
                'bottom_post_meta_toggle',
                [
                   'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                   'label' => esc_html__( 'Meta', 'element-ready-pro' ),
                   'label_off' => esc_html__( 'Default', 'element-ready-pro' ),
                   'label_on' => esc_html__( 'Custom', 'element-ready-pro' ),
                   'return_value' => 'yes',
                 
                ]
             );
             
             $this->start_popover();

                $this->add_control(
                      'show_author',
                      [
                         'label'     => esc_html__('Show Author', 'element-ready-pro'),
                         'type'      => Controls_Manager::SWITCHER,
                         'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                         'label_off' => esc_html__('No', 'element-ready-pro'),
                         'default'   => 'no',
                         'condition' => [
                            'show_post_meta' => ['yes']
                         ]
                      ]
                );

                $this->add_control(
                   'show_author_image',
                   [
                      'label'     => esc_html__('Show Author Image', 'element-ready-pro'),
                      'type'      => Controls_Manager::SWITCHER,
                      'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                      'label_off' => esc_html__('No', 'element-ready-pro'),
                      'default'   => 'no',
                      'condition' => [
                         'show_author' => ['yes']
                      ]
                   ]
                );

            
                $this->add_control(
                      'show_date',
                      [
                         'label'     => esc_html__('Show Date', 'element-ready-pro'),
                         'type'      => Controls_Manager::SWITCHER,
                         'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                         'label_off' => esc_html__('No', 'element-ready-pro'),
                         'default'   => 'yes',
                         'condition' => [
                            'show_post_meta' => ['yes']
                         ]
                      ]
                );



      
                $this->add_control(
                      'show_cat',
                      [
                         'label'     => esc_html__('Show Category', 'element-ready-pro'),
                         'type'      => Controls_Manager::SWITCHER,
                         'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                         'label_off' => esc_html__('No', 'element-ready-pro'),
                         'default'   => 'yes',
                         'condition' => [
                            'show_post_meta' => ['yes']
                         ]
                      ]
                );

                $this->add_control(
                   'show_meta_over_image',
                   [
                      'label'     => esc_html__('Meta Over Image?', 'element-ready-pro'),
                      'type' => \Elementor\Controls_Manager::SELECT,
                      'default' => '',
                      'options' => [
                         'cat'  => esc_html__( 'Category', 'element-ready-pro' ),
                         'date' => esc_html__( 'Date', 'element-ready-pro' ),
                         '' => esc_html__( 'None', 'element-ready-pro' ),
                      ],
                   ]
                );

                $this->add_control(
                    'er_image_date_format',
                    [
                       'label'     => esc_html__('Date Format', 'element-ready-pro'),
                       'type' => \Elementor\Controls_Manager::SELECT,
                       'default' => '',
                       'options' => [
                          ''          => '',
                          'F j'       => esc_html__( 'F j', 'element-ready-pro' ),
                          'F , j'       => esc_html__( 'F , j', 'element-ready-pro' ),
                          'l F j Y' => esc_html__( 'l F j Y', 'element-ready-pro' ),
                          'l, F j, Y' => esc_html__( 'l, F j, Y', 'element-ready-pro' ),
                          'l, F j'    => esc_html__( 'l, F j', 'element-ready-pro' ),
                          'l F j'    => esc_html__( 'l F j', 'element-ready-pro' ),
                          'M j Y'    => esc_html__( 'M j Y', 'element-ready-pro' ),
                          'M j, Y'    => esc_html__( 'M j, Y', 'element-ready-pro' ),
                          'M , j'       => esc_html__( 'M , j', 'element-ready-pro' ),
                          'M j'       => esc_html__( 'M j', 'element-ready-pro' ),
                          'Y-m-d'     => esc_html__( 'Y-m-d', 'element-ready-pro' ),
                          'Y/m/d'     => esc_html__( 'Y/m/d', 'element-ready-pro' ),
                          'F Y'      => esc_html__( 'F Y', 'element-ready-pro' ),
                          'F , Y'      => esc_html__( 'F, Y', 'element-ready-pro' ),
                       ],
                       'condition' => [

                          'show_meta_over_image' => ['date']
                          
                       ]
                    ]
                 );
       
      
           
                $this->add_control(
                      'show_readmore',
                      [
                         'label'     => esc_html__('Show Readmore', 'element-ready-pro'),
                         'type'      => Controls_Manager::SWITCHER,
                         'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                         'label_off' => esc_html__('No', 'element-ready-pro'),
                         'default'   => 'yes',
                         'condition' => [
                            'show_post_meta' => ['yes']
                         ]
                      ]
                );

             $this->add_control(
                'readmore_text',
                      [
                         'label'     => esc_html__('Readmore Text?', 'element-ready-pro'),
                         'type'          => Controls_Manager::TEXT,
                         'default'       => 'readmore',
                         'condition' => [
                            'show_readmore' => ['yes'],
                           
                         ]
                      ]
                );

                $this->add_control(
                      'show_comment',
                      [
                         'label'     => esc_html__('Show Comment', 'element-ready-pro'),
                         'type'      => Controls_Manager::SWITCHER,
                         'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                         'label_off' => esc_html__('No', 'element-ready-pro'),
                         'default'   => 'yes',
                         'condition' => [
                            'show_post_meta' => ['yes']
                         ]
                      ]
                );

                

                $this->add_control(
                      'show_comment_text',
                      [
                         'label'     => esc_html__('Comment Text?', 'element-ready-pro'),
                         'type'      => Controls_Manager::SWITCHER,
                         'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                         'label_off' => esc_html__('No', 'element-ready-pro'),
                         'default'   => 'no',
                         'condition' => [
                            'show_comment' => ['yes']
                         ]
                      
                      ]
                );

                $this->add_control(
                'comment_text',
                      [
                         'label'         => esc_html__( 'Comment', 'element-ready-pro' ),
                         'type'          => Controls_Manager::TEXT,
                         'default'       => 'comment',
                         'condition' => [
                            'show_comment_text' => ['yes'],
                            'show_comment' => ['yes']
                         ]
                      ]
                );

                $this->add_control(
                'comment_texts',
                      [
                         'label'         => esc_html__( 'Comments', 'element-ready-pro' ),
                         'type'          => Controls_Manager::TEXT,
                         'default'       => 'comments',
                         'condition' => [
                            'show_comment_text' => ['yes'],
                            'show_comment' => ['yes']
                         ]
                      ]
                );
          

             $this->end_popover();
  

           
            $this->add_control(
                'show_video',
                [
                    'label'     => esc_html__('Show Video', 'element-ready-pro'),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                    'label_off' => esc_html__('No', 'element-ready-pro'),
                    'default'   => 'no',
                    'condition' => [
                       
                    ]
                    
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Image_Size::get_type(),
                [
                    'name' => 'thumbnail', 
                    'exclude' => [ 'custom' ],
                    'include' => [],
                    'default' => 'thumbnail',
                ]
            );

            $this->add_control(
                'more_options',
                [
                    'label' => esc_html__( 'Middle Post image', 'element-ready-pro' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [
                        'block_style' => ['style1']
                    ]
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Image_Size::get_type(),
                [
                    'name' => 'full_image_size', 
                    'exclude' => [ 'custom' ],
                    'include' => [],
                    'default' => 'full',
                    'condition' => [
                        'block_style' => ['style1']
                    ]
                ]
            );

         


         $this->end_controls_section();

         $this->content_text([
            'title' => esc_html__('Meta Icon','element-ready-pro'),
            'slug' => '_meta_iconss_content',
            'condition' => '',
            'controls' => [
              'meta_icon'=> [
                    'label' => esc_html__( 'Meta Icon', 'element-ready-pro' ),
                    'type'  => \Elementor\Controls_Manager::ICONS,
               ],

              'meta_cat_icon'=> [
                'label' => esc_html__( 'Meta Category Icon', 'element-ready-pro' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
              ],
   
              'meta_author_icon'=> [
                'label' => esc_html__( 'Meta Author Icon', 'element-ready-pro' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
              ],
   
              'meta_date_icon'=> [
                'label' => esc_html__( 'Meta Date Icon', 'element-ready-pro' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
              ],
   
              'meta_comment_icon'=> [
                'label' => esc_html__( 'Meta Comment Icon', 'element-ready-pro' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
              ],
              
              'meta_video_icon'=> [
                'label' => esc_html__( 'Meta Video Icon', 'element-ready-pro' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
              ],
          
              'meta_readmore_icon'=> [
                'label' => esc_html__( 'Readmore Icon', 'element-ready-pro' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
              ],
          
            ]
         ]);

        
        $this->start_controls_section(
            'section_tab_settings',
            [
                'label' => esc_html__('Tabs Settings', 'element-ready-pro'),
            ]
        );

            $this->add_control(
                'news_tab_menu',
                [
                'label'        => esc_html__( 'Tab Menu', 'element-ready-pro' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'element-ready-pro' ),
                'label_off'    => esc_html__( 'Hide', 'element-ready-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                ]
            );

           $repeater = new \Elementor\Repeater();

           $repeater->add_control(
                'title', [
                           
                            'label'   => esc_html__( 'Tab title', 'element-ready-pro' ),
                            'type'    => Controls_Manager::TEXT,
                            'default' => 'Latest post',
                ]
            );

            $repeater->add_control(
                'post_format', [
                   
                    'label'   => esc_html__('Select Post Format', 'element-ready-pro'),
                    'type'    => Controls_Manager::SELECT2,
                    'options' => [
                        
                        'post-format-video' => esc_html__( 'Video', 'element-ready-pro' ),
                        'post-format-image' => esc_html__( 'Image', 'element-ready-pro' ),
                        'post-format-audio' => esc_html__( 'Audio', 'element-ready-pro' ),
                    ],
                    'default'     => [],
                    'label_block' => true,
                    'multiple'    => true,
                ]
            );

            $repeater->add_control(
                'post_cats', [
                   
                    'label'     => esc_html__('Select Categories', 'element-ready-pro'),
                    'type'        => Controls_Manager::SELECT2,
                    'options'     => element_ready_get_post_category(),
                    'label_block' => true,
                    'multiple'    => true,
                ]
            );

            $repeater->add_control(
                'post_tags', [
                            'label'       => esc_html__('Select tags', 'element-ready-pro'),
                            'type'        => Controls_Manager::SELECT2,
                            'options'     => element_ready_get_post_tags(),
                            'label_block' => true,
                            'multiple'    => true,
                ]
            );

            $repeater->add_control(
                'post_sortby', [
                    'name'    => 'post_sortby',
                    'label'   => esc_html__( 'Post sort by', 'element-ready-pro' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'latestpost',
                    'options' => 
                        [
                            'latestpost'    => esc_html__( 'Latest posts', 'element-ready-pro' ),
                            'popularposts'  => esc_html__( 'Popular posts', 'element-ready-pro' ),
                            'mostdiscussed' => esc_html__( 'Most discussed', 'element-ready-pro' ),
                            'tranding'      => esc_html__( 'Tranding', 'element-ready-pro' ),
                            
                        ],
                ]
            );
            
            $repeater->add_control(
                'post_order', [
                    'name'    => 'post_order',
                    'label'   => esc_html__( 'Post order', 'element-ready-pro' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'DESC',
                    'options' => [
                            'DESC' => esc_html__( 'Descending', 'element-ready-pro' ),
                            'ASC'  => esc_html__( 'Ascending', 'element-ready-pro' ),
                        ],
                ]
            );
            $repeater->add_control(
                'offset_enable', [
                    'label'     => esc_html__( 'Post Skip', 'element-ready-pro' ),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__('Yes', 'element-ready-pro'),
                    'label_off' => esc_html__('No', 'element-ready-pro'),
                ]
            );

            $repeater->add_control(
                'offset_item_num', [
                    'label'     => esc_html__( 'Skip post count', 'element-ready-pro' ),
                    'type'      => Controls_Manager::NUMBER,
                    'default'   => '1',
                    'condition' => [ 'offset_enable' => 'yes' ]
                ]
            );


            $this->add_control(
                'element_ready_post_tabs',
                [
                    'label'   => esc_html__('Tabs', 'element-ready-pro'),
                    'type'    => Controls_Manager::REPEATER,
                    'default' => [
                        [
                            'tab_title' => esc_html__('Add Tab', 'element-ready-pro'),
                            'post_cats' => 1,
                        ],
                    ],
                    'fields' => $repeater->get_controls(),
                   
                ]
            );

    $this->end_controls_section();

    
    $this->box_layout_css(
        array(
            'title' => esc_html__('Tab Container','element-ready-pro'),
            'slug' => 'post_item_wrapper_box_style',
            'element_name' => 'post_item_wrapper_element_ready_',
            'selector' => '{{WRAPPER}} .element-ready-pro-b-tab-wrapper',
            'disable_controls' => [

            ]
         )
    );
  
   $this->box_css(
        array(
        'title' => esc_html__('Tab Menu Container','element-ready-pro'),
        'slug' => 'post_tabwer_menu_wer_style',
        'element_name' => 'post_tabwe_wre_element_ready_',
        'selector' => '{{WRAPPER}} .er-binduz-nav',
        'hover_selector' => false,
        'disable_controls' => [
            'alignment','css','position','bg','size'
        ]

        )
    );

     $this->text_minimum_css(
        array(
        'title' => esc_html__('Active Menu link','element-ready-pro'),
        'slug' => 'post_asatab_menu_sr_style',
        'element_name' => 'post_tab_s_aaelement_ready_',
        'selector' => '{{WRAPPER}} .er-binduz-nav-link.er-b-active',
        'hover_selector' => false,
        'disable_controls' => [
            'alignment','display','css','position'
        ]
        )
    );

    $this->text_minimum_css(
        array(
        'title' => esc_html__('Tab Menu link','element-ready-pro'),
        'slug' => 'post_tab_menu_link_sr_style',
        'element_name' => 'post_tab_link_element_ready_',
        'selector' => '{{WRAPPER}} .er-binduz-nav-link',
        'hover_selector' => '{{WRAPPER}} .er-binduz-nav-link:hover',
        'disable_controls' => [
            'alignment','display','css','position'
        ]

        )
    );
    
    $this->box_minimum_css(
        array(
        'title' => esc_html__('Tab Content','element-ready-pro'),
        'slug' => 'post_tab_content_r_style',
        'element_name' => 'post_tab_content_element_ready_',
        'selector' => '{{WRAPPER}} .er-binduz-news-tab-content',
        'hover_selector' => false,
        'disable_controls' => [
            'alignment','box-shadow','display','css','position','bg','border'
        ]
        )
    );

  

    $this->text_minimum_css(
        array(
        'title' => esc_html__('Title','element-ready-pro'),
        'slug' => 'post_title__style',
        'element_name' => 'post_title__element_ready_',
        'selector' => '{{WRAPPER}} .binduz-er-title a',
        'hover_selector' => '{{WRAPPER}} .binduz-er-title a:hover',
        'disable_controls' => [
            'alignment','box-shadow','display','css','position','border','size','bg'
           ]
        )
    ); 

    $this->text_minimum_css(
        array(
           'title' => esc_html__('Content','element-ready-pro'),
           'slug' => 'post_content_style',
           'element_name' => 'post_content_element_ready_',
           'selector' => '{{WRAPPER}} .er-binduz-news-content',
           'hover_selector' => false,
           'condition' => [
              'show_content' => 'yes',
           ],
           'disable_controls' => [
              'alignment','position','display','size','bg'
           ]
        )
    );

    $this->box_css(
        array(
           'title' => esc_html__('Inner Content','element-ready-pro'),
           'slug' => 'post_content_inner_style',
           'element_name' => 'post_content_inner_element_ready_',
           'selector' => '{{WRAPPER}} .binduz-er-content',
           'hover_selector' => false,
          'disable_controls' => [
              'alignment','position','display','size','css'
           ]
        )
    );
   
   
     $this->text_wrapper_css(
            array(
               'title' => esc_html__('Category','element-ready-pro'),
               'slug' => 'post_cat_style',
               'element_name' => 'post_cat_element_ready_',
               'selector' => '{{WRAPPER}} .binduz-er-meta-category a',
               'hover_selector' => '{{WRAPPER}} .binduz-er-meta-category a:hover',
               'disable_controls' => [
                'alignment','box-shadow','display','css','position'
               ]
            )
      );

     
     $this->text_wrapper_css(
        array(
           'title' => esc_html__('Video','element-ready-pro'),
           'slug' => 'post_video_style',
           'element_name' => 'post_video_element_ready_',
           'selector' => '{{WRAPPER}} .binduz-er-video-popup',
           'hover_selector' => false,
           'disable_controls' => [
            'alignment','box-shadow','display','css'
           ]
        )
     ); 
     
     $this->text_wrapper_css(
        array(
           'title' => esc_html__('Video Icon','element-ready-pro'),
           'slug' => 'post_icon_video_style',
           'element_name' => 'post_icon_video_element_ready_',
           'selector' => '{{WRAPPER}} .binduz-er-video-popup i',
           'hover_selector' => '{{WRAPPER}} .binduz-er-video-popup:hover i',
           'disable_controls' => [
            'alignment','box-shadow','display','css','position','border','dimension','size','bg'
           ]
    
        )
     );

     $this->text_css(
        array(
            'title'          => esc_html__('Meta Over Image','element-ready-pro'),
            'slug'           => 'cat_over_iage_style',
            'element_name'   => '_cat_over_image_apper_element_ready_',
            'selector'       => '{{WRAPPER}} .er-meta-over-image .element-ready-cat',
            'hover_selector' => false,
            'condition'      => [
                'show_meta_over_image' => ['cat','date']
            ],
            'disable_controls' => [
             'alignment','display','size','css'
            ]
        )
     );


     $this->start_controls_section('er_binduz_image_section',
            [
               'label' => esc_html__( 'Image ', 'element-ready-pro' ),
               'tab'   => Controls_Manager::TAB_STYLE,
               
            ]
      );

        $this->add_responsive_control(
            'image_padding',
            [
            'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
                '{{WRAPPER}} .binduz-er-thumb'     => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            
            ],
            ]
        );

         $this->add_responsive_control(
            'image_margin',
            [
               'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .binduz-er-thumb img'     => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
               ],
            ]
         );

         $this->add_responsive_control(
            'box_image_height',
            [
               'label'      => esc_html__( 'Image height', 'element-ready-pro' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
               
               ],
               
               'selectors' => [
                  '{{WRAPPER}} .binduz-er-thumb img'     => 'height: {{SIZE}}{{UNIT}};',
               
               ],
               
            ]
         );
    
     
         $this->add_responsive_control(
            'box_image_amax_width',
            [
               'label'      => esc_html__( 'Max width', 'element-ready-pro' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
               
               ],
               'selectors' => [
                  '{{WRAPPER}} .binduz-er-thumb img'     => 'max-width: {{SIZE}}{{UNIT}};',
               
               ],
            
            ]
         ); 

         $this->add_responsive_control(
            'img_borders__radius',
            [
               'label'      => esc_html__( 'Image Border radius', 'element-ready-pro' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .binduz-er-thumb'  => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
               ],
            ]
         );


      $this->end_controls_section();
      

      $this->text_css(
        array(
           'title'            => esc_html__('Readmore','element-ready-pro'),
           'slug'             => 'post_readmore_buton_style',
           'element_name'     => 'post_readmore_element_ready_',
           'selector'         => '{{WRAPPER}} .er-readmore-btn',
           'hover_selector'   => '{{WRAPPER}} .er-readmore-btn:hover',
           'disable_controls' => [
               'alignment','position','size','css'
           ],
           'condition' => [
            'show_readmore' => 'yes',
          ],
        )
    ); 

    $this->text_minimum_css(
        array(
           'title'          => esc_html__('ReadMore icon','element-ready-pro'),
           'slug'           => 'post_readmore_icon_style',
           'element_name'   => 'post_readmore_icon_element_ready_',
           'selector'       => '{{WRAPPER}} .er-readmore-btn i',
           'hover_selector' => false,
           'condition'      => [
              'show_readmore' => 'yes',
           ],
           'disable_controls' => [
            'alignment','box-shadow','position','display','size','css','bg','border'
          ]
        )
    );

    $this->text_minimum_css(
        array(
           'title' => esc_html__('Meta Text','element-ready-pro'),
           'slug' => 'post_date_style',
           'element_name' => 'post_date_element_ready_',
           'selector' => '{{WRAPPER}} .binduz-er-meta-item a',
           'hover_selector' => '{{WRAPPER}} .binduz-er-meta-item a:hover',
           'disable_controls' => [
               'bg','alignment','box-shadow','position','display','size','css'
           ]
        )
    ); 

    $this->text_minimum_css(
            array(
               'title' => esc_html__('Meta icon','element-ready-pro'),
               'slug' => 'post_date_icon_style',
               'element_name' => 'post_date_icon_element_ready_',
               'selector' => '{{WRAPPER}} .binduz-er-meta-item i',
               'hover_selector' => false,
               'condition' => [
                  'show_date' => 'yes',
               ],
               'disable_controls' => [
                'alignment','box-shadow','position','display','size','css'
              ]
            )
        );

        $this->start_controls_section('er_binduz_single_item_section',
        [
           'label' => esc_html__( 'Single Item', 'element-ready-pro' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );

            $this->add_responsive_control(
                'single_item_padding',
                [
                'label'      => esc_html__( 'Padding', 'element-ready-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .binduz-er-trending-news-list-box'     => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
                ],
                ]
            );

            $this->add_responsive_control(
                'single_item_margin',
                [
                'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .binduz-er-trending-news-list-box'     => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
                ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'single_item_border',
                    'label' => esc_html__( 'Border', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} .binduz-er-trending-news-list-box',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'single_item_bobackground',
                    'label' => esc_html__( 'Background', 'element-ready-pro' ),
                    'types' => [ 'classic', 'gradient'],
                    'selector' => '{{WRAPPER}} .binduz-er-content',
                ]
            );

         

        $this->end_controls_section();

        $this->start_controls_section('er_binduz_flex_item_section',
        [
           'label' => esc_html__( 'Single Item layout', 'element-ready-pro' ),
           
        ]
       );

            $this->add_responsive_control(
                    'post_tab_grid_display',
                    [
                        'label' => esc_html__( 'Layout', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => '',
                        'options' => [
                            'flex'         => esc_html__( 'Flexible', 'element-ready-pro' ),
                            'block'        => esc_html__( 'Block', 'element-ready-pro' ),
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .binduz-er-trending-news-list-box' => 'display: {{VALUE}};'
                        ],
                    ]
                    
                );

                
                $this->add_responsive_control(
                    'post_tab_grid_display_row_clum',
                    [
                        'label' => esc_html__( 'Flex Direction', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => '',
                        'options' => [
                            'column'         => esc_html__( 'Column', 'element-ready-pro' ),
                            'row'            => esc_html__( 'Row', 'element-ready-pro' ),
                            'column-reverse' => esc_html__( 'Column Reverse', 'element-ready-pro' ),
                            'row-reverse'    => esc_html__( 'Row Reverse', 'element-ready-pro' ),
                    
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .binduz-er-trending-news-list-box' => 'flex-direction: {{VALUE}};'
                        ],
                        'condition' => [
                            'post_tab_grid_display!' => ['block']
                        ]
                     ]
                    
                );

                $this->add_responsive_control(
                    'er_tab_flex_layouts',
                    [
                        'label' => esc_html__( 'Content Column Gap', 'element-ready-pro' ),
                        'type' => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 14,
                                'step' => 1,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .binduz-er-trending-news-list-box' => 'gap: {{SIZE}}{{UNIT}};',
                        ],
                        'condition' => [
                            'post_tab_grid_display!' => ['block']
                        ]
                    ]
                );
   

        $this->end_controls_section();

        $this->start_controls_section('er_binduz_grid_item_section',
        [
           'label' => esc_html__( 'Grid layout', 'element-ready-pro' ),
           
        ]
       );

       $this->add_responsive_control(
            'er_tab_grid_layouts',
            [
                'label' => esc_html__( 'Column', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 14,
                        'step' => 1,
                    ],
                 ],
                'selectors' => [
                    '{{WRAPPER}} .er-binduz-news-tab-content .er--qnews-block-row' => 'grid-template-columns: repeat({{SIZE}},1fr);',
                    '{{WRAPPER}} .binduz-er-trending-news-list-item' => 'grid-template-columns: repeat({{SIZE}},1fr);',
                ],
            ]
        );

        

        $this->add_responsive_control(
            'er_tab_grid_layouts_gap',
            [
                'label' => esc_html__( 'Column Gap', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                 ],
                'selectors' => [
                    '{{WRAPPER}} .er-binduz-news-tab-content .er--qnews-block-row' => 'column-gap: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .binduz-er-trending-news-list-item' => 'column-gap: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .binduz-er-trending-news-list-item' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'er_tab_grid_layouts_rowgap',
            [
                'label' => esc_html__( 'Row Gap', 'element-ready-pro' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1
                    ],
                 ],
                'selectors' => [
                    '{{WRAPPER}} .er-binduz-news-tab-content .er--qnews-block-row' => 'row-gap: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .binduz-er-trending-news-list-item' => 'row-gap: {{SIZE}}{{UNIT}};',
                ],
               
            ]
        );

       

        $this->add_responsive_control(
            'er_aligntext_flexc_align',
            [
               'label'   => esc_html__( 'Content Alignment', 'element-ready-pro' ),
               'type'    => \Elementor\Controls_Manager::CHOOSE,
               'options' => [
                  'align-items: start; text-align:left;' => [
                     'title' => esc_html__( 'Left', 'element-ready-pro' ),
                     'icon'  => 'eicon-text-align-left',
                  ],
                  'align-items: center; text-align: center;' => [
                     'title' => esc_html__( 'Center', 'element-ready-pro' ),
                     'icon'  => 'eicon-text-align-center',
                  ],
                  'align-items: end; text-align: right;' => [
                     'title' => esc_html__( 'Right', 'element-ready-pro' ),
                     'icon'  => 'eicon-text-align-right',
                  ],
               
               ],
            
               'toggle'    => true,
               'selectors' => [

                  '{{WRAPPER}} .binduz-er-content'           => '{{VALUE}}',
                  '{{WRAPPER}} .er-meta-over-image'           => '{{VALUE}}',
                
              ],
           
            ]
         );

        $this->add_responsive_control(
            'er_aligntext_meta_align',
            [
               'label'   => esc_html__( 'Meta Alignment', 'element-ready-pro' ),
               'type'    => \Elementor\Controls_Manager::CHOOSE,
               'options' => [
                  'justify-content: left;' => [
                     'title' => esc_html__( 'Left', 'element-ready-pro' ),
                     'icon'  => 'eicon-text-align-left',
                  ],
                  'width: 100%;justify-content: center;' => [
                     'title' => esc_html__( 'Center', 'element-ready-pro' ),
                     'icon'  => 'eicon-text-align-center',
                  ],
                  'width: 100%;justify-content: right;' => [
                     'title' => esc_html__( 'Right', 'element-ready-pro' ),
                     'icon'  => 'eicon-text-align-right',
                  ],
               
               ],
            
               'toggle'    => true,
               'selectors' => [

                  '{{WRAPPER}} .binduz-er-meta-item'  => '{{VALUE}}',
                 
              ],
            ]
         );
        $this->end_controls_section();


	}

	protected function render( ) {

        $settings                = $this->get_settings();
        $show_cat                = $settings['show_cat'];
        $show_date               = $settings['show_date'];
        $thumbnail_size          = $settings['thumbnail_size'];
        $full_image_size         = isset($settings['full_image_size_size'])?$settings['full_image_size_size']:'full';
        $post_title_crop         = $settings['post_title_crop'];
        $post_count              = $settings['post_count'];
        $id                      = $this->get_id();
        $element_ready_post_tabs = $settings['element_ready_post_tabs'];
        $post_tab_count          = count($element_ready_post_tabs);
         
     

    ?>
	<!--TAB WIDGET START-->
  
        <?php if($settings[ 'block_style' ] == 'style1'): ?>
            <div class="element-ready-pro-b-tab-wrapper"> 

                  <?php if( $settings['news_tab_menu'] =='yes' ): ?>
                        <div class="binduz-er-video-post-tab">
                            <ul class="er-binduz-nav">
                                <?php foreach($element_ready_post_tabs as $key => $tab): ?>
                                    <li class="er-binduz-nav-item">
                                        <a data-tab="<?php echo esc_attr('post-'.$key.'-'.$id); ?>" class="er-binduz-nav-link <?php echo esc_attr($key==0?'er-b-active':''); ?>" id="#<?php echo esc_attr('post-'.$key.'-'.$id); ?>" href="#<?php echo esc_attr('post-'.$key.'-'.$id); ?>"><?php echo esc_html($tab['title']); ?></a>
                                    </li>
                                <?php endforeach; ?> 
                            </ul>
                        </div>
                    <?php endif; ?>
      
                <div class="er-binduz-news-tab-content">
                    <?php foreach($element_ready_post_tabs as $sl => $tab_content): ?>
                        <div class="er-b-tab-pane <?php echo esc_attr($sl==0?'er-b-show er-b-fade er-b-active ':'er-b-fade'); ?>" id="<?php echo esc_attr('post-'.$sl.'-'.$id); ?>">
                            <div class="er--qnews-block-row">
                               <?php

                                    $query = array(
                                        'post_type'   => array( 'post' ),
                                        'post_status' => array( 'publish' ),
                                        'orderby'     => 'date',
                                        'order'       => 'DESC',
                                        'numberposts' => $post_count,
                                    ); 


                                    if( isset( $tab_content['post_order'] ) && $tab_content['post_order'] !=''){
                                        $query['order']  = $tab_content['post_order'];
                                    }

                                    if( isset( $tab_content['post_sortby'] ) && $tab_content['post_sortby'] !=''){
                                        
                                        if($tab_content['post_sortby'] == 'mostdiscussed') {
                                                $query['orderby'] = 'comment_count';
                                        }
                                        

                                        if(isset($tab_content['post_cats']) && is_array($tab_content['post_cats'])){ 
                                                $query['category__in'] = $tab_content['post_cats'];  
                                        }

                                        if(isset($tab_content['post_tags']) && is_array($tab_content['post_tags'])){ 
                                                $query['tag__in'] = $tab_content['post_tags'];  
                                        }

                                        if($tab_content['post_sortby'] == 'popularposts') {
                                                $query['meta_key'] = 'element_ready_post_views_count';
                                                $query['orderby']  = 'meta_value_num';
                                        } 
                                        
                                        if($tab_content['post_sortby'] == 'share') {
                                                $query['meta_key'] = 'element_ready_most_share_post';
                                                $query['orderby']  = 'meta_value_num';
                                        }

                                        if($tab_content['post_sortby'] == 'tranding') {
                                                $query['meta_query'][] = [
                                                'key'     => '_element_ready_trending',
                                                'value'   => 'yes',
                                                'compare' => '=',
                                                ];
                                        }
                                            
                                    }
                                    if( isset($tab_content['post_format']) && is_array($tab_content['post_format']) && count($tab_content['post_format']) > 0 ) {

                                        $query['tax_query'] = array(
                                                array(
                                                    'taxonomy' => 'post_format',
                                                    'field'    => 'slug',
                                                    'terms'    => $tab_content['post_format'],
                                                    'operator' => 'IN'
                                                ) 
                                            );

                                    } 

                                    if($tab_content['offset_enable']=='yes') {
                                        $query['offset'] = $tab_content['offset_item_num'];
                                    }

                                    $data = get_posts($query);
                                    $last = count($data)-1;

                                ?> 
                                <?php foreach( $data as $sl => $post ): ?>
                                    <?php if( $sl < 2 ): ?>
                                            <?php if( $sl  == 0 ): ?>
                                            <div class="er--qnews-block-col-lg">
                                                <div class="binduz-er-video-post-item">
                                                    <?php endif; ?>
                                                    <div class="binduz-er-trending-news-list-box">
                                                        
                                                        <?php if(has_post_thumbnail( $post->ID )): ?>
                                                            <div class="binduz-er-thumb er-meta-over-image">
                                                                <img src="<?php echo esc_url( get_the_post_thumbnail_url($post->ID , $thumbnail_size) ); ?>" alt="<?php echo esc_attr($post->post_title); ?>">
                                                                <?php include('parts/video.php');  ?>
                                                                <?php include('tab/parts/meta_over_image.php');  ?>
                                                            </div>
                                                        <?php endif; ?>
                                                       
                                                        <div class="binduz-er-content">
                                                            <?php include('tab/parts/top_meta.php');  ?>
                                                            <?php include('tab/parts/title.php'); ?>
                                                            <?php include('tab/parts/content.php');  ?>
                                                            <?php include('tab/parts/meta.php');  ?>
                                                            <?php include('tab/parts/readmore.php'); ?>
                                                        </div>
                                                     
                                                    </div>
                                            <?php if( $sl == 1 || $last == $sl ): ?>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                    <?php elseif( $sl == 2  ): ?>
                                        <div class="er--qnews-block-col-lg">
                                            <div class="binduz-er-video-post-item">
                                                <div class="binduz-er-trending-news-list-box main-item">
                                                    <?php if(has_post_thumbnail( $post->ID )): ?>
                                                        <div class="binduz-er-thumb er-meta-over-image">
                                                            <img src="<?php echo esc_url( get_the_post_thumbnail_url($post->ID,$full_image_size) ); ?>" alt="<?php echo esc_attr($post->post_title); ?>">
                                                            <?php include('parts/video.php');  ?>
                                                            <?php include('tab/parts/meta_over_image.php');  ?>
                                                        </div>
                                                    <?php endif; ?>
                                                   
                                                    <div class="binduz-er-content">
                                                        <?php include('tab/parts/top_meta.php');  ?>
                                                        <?php include('tab/parts/title.php'); ?>
                                                        <?php include('tab/parts/content.php');  ?>
                                                        <?php include('tab/parts/meta.php');  ?>
                                                        <?php include('tab/parts/readmore.php'); ?>
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif( $sl > 2): ?>
                                        <?php if($sl == 3): ?>
                                            <div class="er--qnews-block-col-lg sl-<?php echo $sl; ?>">
                                                <div class="binduz-er-video-post-item">
                                                    <?php endif; ?>
                                                    <div class="binduz-er-trending-news-list-box">
                                                        <?php if(has_post_thumbnail( $post->ID )): ?>
                                                            <div class="binduz-er-thumb er-meta-over-image">
                                                                <img src="<?php echo esc_url( get_the_post_thumbnail_url($post->ID , $thumbnail_size) ); ?>" alt="<?php echo esc_attr($post->post_title); ?>">
                                                                <?php include('parts/video.php');  ?>
                                                                <?php include('tab/parts/meta_over_image.php');  ?>
                                                            </div>
                                                        <?php endif; ?>
                                                  
                                                        <div class="binduz-er-content">
                                                            <?php include('tab/parts/top_meta.php');  ?>
                                                            <?php include('tab/parts/title.php'); ?>
                                                            <?php include('tab/parts/content.php');  ?>
                                                            <?php include('tab/parts/meta.php');  ?>
                                                            <?php include('tab/parts/readmore.php'); ?>
                                                        </div>
                                                   
                                                    </div>
                                                <?php if( $sl == 4 || $last == $sl ): ?>
                                                </div>
                                            </div>
                                            <?php break; endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>   
                </div> 
            </div>   
         <?php endif; ?>

    
        <?php if($settings[ 'block_style' ] == 'style2'): ?>
                 
            <div class="binduz-er-trending-news-list er-tab-style2">
                <?php if( $settings['news_tab_menu'] =='yes' ): ?>
                    <div class="binduz-er-video-post-tab">
                        <ul class="er-binduz-nav">
                            <?php foreach($element_ready_post_tabs as $key => $tab): ?>
                                <li class="er-binduz-nav-item">
                                    <a data-tab="<?php echo esc_attr('post-'.$key.'-'.$id); ?>" class="er-binduz-nav-link <?php echo esc_attr($key==0?'er-b-active':''); ?>" id="#<?php echo esc_attr('post-'.$key.'-'.$id); ?>" href="#<?php echo esc_attr('post-'.$key.'-'.$id); ?>"><?php echo esc_html($tab['title']); ?></a>
                                </li>
                            <?php endforeach; ?> 
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="er-binduz-news-tab-content">
                    <?php foreach($element_ready_post_tabs as $sl => $tab_content): ?>
                        <div class="er-b-tab-pane <?php echo esc_attr($sl==0?'er-b-show er-b-fade er-b-active ':'er-b-fade'); ?>" id="<?php echo esc_attr('post-'.$sl.'-'.$id); ?>">
                            <div class="binduz-er-trending-news-list-item">
                                    <?php
                                        $query = array(
                                            'post_type'   => array( 'post' ),
                                            'post_status' => array( 'publish' ),
                                            'orderby'     => 'date',
                                            'order'       => 'DESC',
                                            'numberposts' => $post_count,
                                        ); 


                                        if( isset( $tab_content['post_order'] ) && $tab_content['post_order'] !=''){
                                            $query['order']  = $tab_content['post_order'];
                                        }

                                        if( isset( $tab_content['post_sortby'] ) && $tab_content['post_sortby'] !=''){
                                            
                                            if($tab_content['post_sortby'] == 'mostdiscussed') {
                                                    $query['orderby'] = 'comment_count';
                                            }
                                            

                                            if(isset($tab_content['post_cats']) && is_array($tab_content['post_cats'])){ 
                                                    $query['category__in'] = $tab_content['post_cats'];  
                                            }

                                            if(isset($tab_content['post_tags']) && is_array($tab_content['post_tags'])){ 
                                                    $query['tag__in'] = $tab_content['post_tags'];  
                                            }

                                            if($tab_content['post_sortby'] == 'popularposts') {
                                                    $query['meta_key'] = 'element_ready_post_views_count';
                                                    $query['orderby']  = 'meta_value_num';
                                            } 
                                            
                                            if($tab_content['post_sortby'] == 'share') {
                                                    $query['meta_key'] = 'element_ready_most_share_post';
                                                    $query['orderby']  = 'meta_value_num';
                                            }

                                            if($tab_content['post_sortby'] == 'tranding') {
                                                    $query['meta_query'][] = [
                                                    'key'     => '_element_ready_trending',
                                                    'value'   => 'yes',
                                                    'compare' => '=',
                                                    ];
                                            }
                                                
                                        }
                                        if( isset($tab_content['post_format']) && is_array($tab_content['post_format']) && count($tab_content['post_format']) > 0 ) {

                                            $query['tax_query'] = array(
                                                    array(
                                                        'taxonomy' => 'post_format',
                                                        'field'    => 'slug',
                                                        'terms'    => $tab_content['post_format'],
                                                        'operator' => 'IN'
                                                    ) 
                                                );

                                        } 

                                        if($tab_content['offset_enable']=='yes') {
                                            $query['offset'] = $tab_content['offset_item_num'];
                                        }

                                        $data = get_posts($query);
                                        $last = count($data)-1;

                                    ?> 
                                    <?php foreach( $data as $sl => $post ): ?>
                                        <div class="binduz-er-trending-news-list-box">

                                            <?php if(has_post_thumbnail( $post->ID  )): ?>

                                                <div class="binduz-er-thumb er-meta-over-image">
                                                    <img src="<?php echo esc_url( get_the_post_thumbnail_url($post->ID , $thumbnail_size) ); ?>" alt="<?php echo esc_attr($post->post_title); ?>">
                                                    <?php include('parts/video.php');  ?>
                                                    <?php include('tab/parts/meta_over_image.php');  ?>
                                                </div>

                                            <?php endif; ?>
                                                
                                            <div class="binduz-er-content">
                                                <?php include('tab/parts/top_meta.php');  ?>
                                                <?php include('tab/parts/title.php'); ?>
                                                <?php include('tab/parts/content.php');  ?>
                                                <?php include('tab/parts/meta.php');  ?>
                                                <?php include('tab/parts/readmore.php'); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>   
                            </div>
                        </div>
                    <?php endforeach; ?>   
                </div> <!-- </div> end tab-content -->
            </div>
        <?php endif; ?>

        <?php if( $settings['block_style'] == 'style3' ): ?>
           <div class="binduz-er-trending-news-list er-tab-style3">
                <?php if( $settings['news_tab_menu'] =='yes' ): ?>
                    <div class="binduz-er-video-post-tab">
                        <ul class="er-binduz-nav">
                            <?php foreach($element_ready_post_tabs as $key => $tab): ?>
                                <li class="er-binduz-nav-item">
                                    <a data-tab="<?php echo esc_attr('post-'.$key.'-'.$id); ?>" class="er-binduz-nav-link <?php echo esc_attr($key==0?'er-b-active':''); ?>" id="#<?php echo esc_attr('post-'.$key.'-'.$id); ?>" href="#<?php echo esc_attr('post-'.$key.'-'.$id); ?>"><?php echo esc_html($tab['title']); ?></a>
                                </li>
                            <?php endforeach; ?> 
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="er-binduz-news-tab-content">
                    <?php foreach($element_ready_post_tabs as $sl => $tab_content): ?>
                        <div class="er-b-tab-pane <?php echo esc_attr($sl==0?'er-b-show er-b-fade er-b-active ':'er-b-fade'); ?>" id="<?php echo esc_attr('post-'.$sl.'-'.$id); ?>">
                            <div class="binduz-er-trending-news-list-item">
                               
                                    <?php
                                        $query = array(
                                            'post_type'   => array( 'post' ),
                                            'post_status' => array( 'publish' ),
                                            'orderby'     => 'date',
                                            'order'       => 'DESC',
                                            'numberposts' => $post_count,
                                        ); 


                                        if( isset( $tab_content['post_order'] ) && $tab_content['post_order'] !=''){
                                            $query['order']  = $tab_content['post_order'];
                                        }

                                        if( isset( $tab_content['post_sortby'] ) && $tab_content['post_sortby'] !=''){
                                            
                                            if($tab_content['post_sortby'] == 'mostdiscussed') {
                                                    $query['orderby'] = 'comment_count';
                                            }
                                            

                                            if(isset($tab_content['post_cats']) && is_array($tab_content['post_cats'])){ 
                                                    $query['category__in'] = $tab_content['post_cats'];  
                                            }

                                            if(isset($tab_content['post_tags']) && is_array($tab_content['post_tags'])){ 
                                                    $query['tag__in'] = $tab_content['post_tags'];  
                                            }

                                            if($tab_content['post_sortby'] == 'popularposts') {
                                                    $query['meta_key'] = 'element_ready_post_views_count';
                                                    $query['orderby']  = 'meta_value_num';
                                            } 
                                            
                                            if($tab_content['post_sortby'] == 'share') {
                                                    $query['meta_key'] = 'element_ready_most_share_post';
                                                    $query['orderby']  = 'meta_value_num';
                                            }

                                            if($tab_content['post_sortby'] == 'tranding') {
                                                    $query['meta_query'][] = [
                                                    'key'     => '_element_ready_trending',
                                                    'value'   => 'yes',
                                                    'compare' => '=',
                                                    ];
                                            }
                                                
                                        }
                                        if( isset($tab_content['post_format']) && is_array($tab_content['post_format']) && count($tab_content['post_format']) > 0 ) {

                                            $query['tax_query'] = array(
                                                    array(
                                                        'taxonomy' => 'post_format',
                                                        'field'    => 'slug',
                                                        'terms'    => $tab_content['post_format'],
                                                        'operator' => 'IN'
                                                    ) 
                                                );

                                        } 

                                        if($tab_content['offset_enable']=='yes') {
                                            $query['offset'] = $tab_content['offset_item_num'];
                                        }

                                        $data = get_posts($query);
                                        $last = count($data)-1;

                                    ?> 
                                    <?php foreach( $data as $sl => $post ): ?>
                                            <div class="binduz-er-trending-news-list-box">
                                                <?php if(has_post_thumbnail( $post->ID  )): ?>

                                                    <div class="binduz-er-thumb er-meta-over-image">
                                                        <img src="<?php echo esc_url( get_the_post_thumbnail_url($post->ID , $thumbnail_size) ); ?>" alt="<?php echo esc_attr($post->post_title); ?>">
                                                        <?php include('parts/video.php');  ?>
                                                        <?php include('tab/parts/meta_over_image.php');  ?>
                                                    </div>

                                                <?php endif; ?>
                                                
                                                <div class="binduz-er-content">
                                                    <?php include('tab/parts/top_meta.php');  ?>
                                                    <?php include('tab/parts/title.php'); ?>
                                                    <?php include('tab/parts/content.php');  ?>
                                                    <?php include('tab/parts/meta.php');  ?>
                                                    <?php include('tab/parts/readmore.php'); ?>
                                                </div>
                                            </div>
                                    <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
      
        <?php wp_reset_postdata(); ?>
	<?php
     }

}

