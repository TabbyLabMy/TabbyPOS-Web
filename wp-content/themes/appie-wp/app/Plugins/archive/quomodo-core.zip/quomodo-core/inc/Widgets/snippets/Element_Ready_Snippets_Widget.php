<?php
namespace Element_Ready_Pro\Widgets\snippets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;
use Elementor\Plugin;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Element_Ready_Snippets_Widget extends Widget_Base {

    public function get_name() {
        return 'Element_Ready_Snippets_Widget';
    }
    
    public function get_title() {
        return __( 'ER Code Snippet Preview', 'element-ready-pro' );
    }

    public function get_icon() {
        return 'eicon-code';
    }
    
	public function get_categories() {
		return [ 'element-ready-pro' ];
	}

    public function get_script_depends() {
        return [
            'prism',
        ];
    }

    public function get_style_depends() {
        return [
            'prism',
        ];
    }

    static function content_layout_style(){
        return[
            'language-javascript'        => esc_html__('Javascript / Json', 'element-ready-pro'),
            'language-markup'            => esc_html__('Markup', 'element-ready-pro'),
            'language-markup-templating' => esc_html__('Markup Templateing', 'element-ready-pro'),
            'language-css'               => esc_html__('CSS', 'element-ready-pro'),
            'language-css-extras'        => esc_html__('CSS Extras', 'element-ready-pro'),
            'language-clike'             => esc_html__('Clike', 'element-ready-pro'),
            'language-php'               => esc_html__('PHP', 'element-ready-pro'),
            'language-python'            => esc_html__('Python', 'element-ready-pro'),
            'language-bash'              => esc_html__('Command Line', 'element-ready-pro'),
        ];
    }
    
    protected function register_controls() {

        /*----------------------------
            CONTENT SECTION
        -----------------------------*/
        $this->start_controls_section(
            '_content_section',
            [
                'label' => __( 'Content', 'element-ready-pro' ),
            ]
        );
            $this->add_control(
                'content_layout_style',
                [
                    'label'       => esc_html__( 'Slect Language Type', 'element-ready-pro' ),
                    'description' => esc_html__( 'Select a language type for show the same language format of the code.', 'element-ready-pro' ),
                    'type'        => Controls_Manager::SELECT,
                    'options'     => self::content_layout_style(),
                ]
            );

            $this->add_control(
                'show_json_highligh',
                [
                    'label'        => __( 'Json Highlight', 'element-ready-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'default'      => 'no',
                    'return_value' => 'yes',
                    'separator'    => 'before',
                    'condition'    => [
                        'content_layout_style' => 'language-javascript'
                    ],
                ]
            );
            $this->add_control(
                'content_json_url',
                [
                    'label'     => __( 'Set your json file url', 'element-ready-pro' ),
                    'type'      => Controls_Manager::TEXT,
                    'separator' => 'before',
                    'condition' => [
                        'show_json_highligh' => 'yes'
                    ],
                ]
            );

            $this->add_control(
                'content_snippet',
                [
                    'label'     => __( 'Write Your Code Here.', 'element-ready-pro' ),
                    'type'      => Controls_Manager::TEXTAREA,
                    'separator' => 'before',
                    'condition' => [
                        'show_json_highligh!' => 'yes'
                    ],
                ]
            );
        $this->end_controls_section();
        /*----------------------------
            CONTENT SECTION END
        -----------------------------*/

        /*----------------------------
            OPTIONS SECTION
        -----------------------------*/
        $this->start_controls_section(
            '_option_section',
            [
                'label' => __( 'Content', 'element-ready-pro' ),
            ]
        );
            $this->add_control(
                'show_line_number',
                [
                    'label'        => esc_html__('Show Line Number', 'element-ready-pro'),
                    'type'         => Controls_Manager::SWITCHER,
                    'default'      => 'yes',
                    'return_value' => 'yes',
                ]
            );
            $this->add_control(
                'show_command_line',
                [
                    'label'        => esc_html__('Show Command Line', 'element-ready-pro'),
                    'type'         => Controls_Manager::SWITCHER,
                    'default'      => 'no',
                    'return_value' => 'yes',
                    'separator'    => 'before',
                ]
            );
            $this->add_control(
                'command_line_host',
                [
                    'label'     => __( 'Host', 'element-ready-pro' ),
                    'type'      => Controls_Manager::TEXT,
                    'condition' => [
                        'show_command_line' => 'yes'
                    ],
                ]
            );
            $this->add_control(
                'command_line_user',
                [
                    'label'     => __( 'User', 'element-ready-pro' ),
                    'type'      => Controls_Manager::TEXT,
                    'condition' => [
                        'show_command_line' => 'yes'
                    ],
                ]
            );

            $this->add_control(
                'show_download_code',
                [
                    'label'        => esc_html__('Show Download Button', 'element-ready-pro'),
                    'type'         => Controls_Manager::SWITCHER,
                    'default'      => 'no',
                    'return_value' => 'yes',
                    'separator'    => 'before',
                ]
            );

            $this->add_control(
                'download_content_url',
                [
                    'label'     => __( 'Dwonload file url', 'element-ready-pro' ),
                    'type'      => Controls_Manager::TEXT,
                    'condition' => [
                        'show_download_code' => 'yes'
                    ],
                ]
            );

            $this->add_control(
                'download_button_text',
                [
                    'label'     => __( 'Download Button Text', 'element-ready-pro' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => __( 'Download The Code', 'element-ready-pro' ),
                    'condition' => [
                        'show_download_code' => 'yes'
                    ],
                ]
            );

            $this->add_control(
                'match_braces',
                [
                    'label'        => esc_html__('Match Braces Code', 'element-ready-pro'),
                    'type'         => Controls_Manager::SWITCHER,
                    'default'      => 'no',
                    'return_value' => 'yes',
                    'separator'    => 'before',
                ]
            );

        $this->end_controls_section();
        /*----------------------------
            OPTIONS SECTION END
        -----------------------------*/
        
        /*----------------------------
            CODE WRP
        -----------------------------*/
        $this->start_controls_section(
            '_style_section',
            [
                'label' => __( 'Code Wrap', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            // Typgraphy
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'wrap_typography',
                    'selector' => '{{WRAPPER}} .element__ready__snippet__content pre',
                ]
            );

            // Icon Color
            $this->add_control(
                'wrap_color',
                [
                    'label'     => __( 'Color', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__snippet__content pre' => 'color: {{VALUE}};',
                    ],
                ]
            );

            // Background
            $this->add_group_control(
                Group_Control_Background:: get_type(),
                [
                    'name'     => 'wrap_background',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .element__ready__snippet__content pre',
                ]
            );

            // Border
            $this->add_group_control(
                Group_Control_Border:: get_type(),
                [
                    'name'     => 'wrap_border',
                    'label'    => __( 'Border', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} .element__ready__snippet__content pre',
                ]
            );

            // Radius
            $this->add_responsive_control(
                'wrap_radius',
                [
                    'label'      => __( 'Border Radius', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__snippet__content pre' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            
            // Shadow
            $this->add_group_control(
                Group_Control_Box_Shadow:: get_type(),
                [
                    'name'     => 'wrap_shadow',
                    'selector' => '{{WRAPPER}} .element__ready__snippet__content pre',
                ]
            );

            // Margin
            $this->add_responsive_control(
                'wrap_margin',
                [
                    'label'      => __( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__snippet__content pre' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            // Padding
            $this->add_responsive_control(
                'wrap_padding',
                [
                    'label'      => __( 'Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__snippet__content pre' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
        $this->end_controls_section();
        /*----------------------------
            CODE WRP END
        -----------------------------*/

        /*----------------------------
            CODE WRP
        -----------------------------*/
        $this->start_controls_section(
            '_style_code_section',
            [
                'label' => __( 'Code Code Wrap', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            // Typgraphy
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'code_typography',
                    'selector' => '{{WRAPPER}} .element__ready__snippet__content pre code',
                ]
            );

            // Icon Color
            $this->add_control(
                'code_color',
                [
                    'label'     => __( 'Color', 'element-ready-pro' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} .element__ready__snippet__content pre code' => 'color: {{VALUE}};',
                    ],
                ]
            );

            // Background
            $this->add_group_control(
                Group_Control_Background:: get_type(),
                [
                    'name'     => 'code_background',
                    'label'    => __( 'Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .element__ready__snippet__content pre code',
                ]
            );

            // Border
            $this->add_group_control(
                Group_Control_Border:: get_type(),
                [
                    'name'     => 'code_border',
                    'label'    => __( 'Border', 'element-ready-pro' ),
                    'selector' => '{{WRAPPER}} .element__ready__snippet__content pre code',
                ]
            );

            // Radius
            $this->add_responsive_control(
                'code_radius',
                [
                    'label'      => __( 'Border Radius', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__snippet__content pre code' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            
            // Shadow
            $this->add_group_control(
                Group_Control_Box_Shadow:: get_type(),
                [
                    'name'     => 'code_shadow',
                    'selector' => '{{WRAPPER}} .element__ready__snippet__content pre code',
                ]
            );

            // Margin
            $this->add_responsive_control(
                'code_margin',
                [
                    'label'      => __( 'Margin', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__snippet__content pre code' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            // Padding
            $this->add_responsive_control(
                'code_padding',
                [
                    'label'      => __( 'Padding', 'element-ready-pro' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .element__ready__snippet__content pre code' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
        $this->end_controls_section();
        /*----------------------------
            CODE WRP END
        -----------------------------*/

        /*----------------------------
            CODE COPY BUTTON
        -----------------------------*/
        $this->start_controls_section(
            'copy_btn_style_section',
            [
                'label' => __( 'Code Copy Button', 'element-ready-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->start_controls_tabs( 'copy_btn_tabs_style' );
                $this->start_controls_tab(
                    'copy_btn_normal_tab',
                    [
                        'label' => __( 'Normal', 'element-ready-pro' ),
                    ]
                );
                    // Typgraphy
                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'copy_btn_typography',
                            'selector' => '{{WRAPPER}} .element__ready__snippet__content .toolbar button',
                        ]
                    );

                    // Icon Color
                    $this->add_control(
                        'copy_btn_color',
                        [
                            'label'     => __( 'Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .element__ready__snippet__content .toolbar button' => 'color: {{VALUE}};',
                            ],
                        ]
                    );

                    // Background
                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'copy_btn_background',
                            'label'    => __( 'Background', 'element-ready-pro' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .element__ready__snippet__content .toolbar button',
                        ]
                    );

                    // Border
                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'copy_btn_border',
                            'label'    => __( 'Border', 'element-ready-pro' ),
                            'selector' => '{{WRAPPER}} .element__ready__snippet__content .toolbar button',
                        ]
                    );

                    // Radius
                    $this->add_responsive_control(
                        'copy_btn_radius',
                        [
                            'label'      => __( 'Border Radius', 'element-ready-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .element__ready__snippet__content .toolbar button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );
                    
                    // Shadow
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'copy_btn_shadow',
                            'selector' => '{{WRAPPER}} .element__ready__snippet__content .toolbar button',
                        ]
                    );

                    // Margin
                    $this->add_responsive_control(
                        'copy_btn_margin',
                        [
                            'label'      => __( 'Margin', 'element-ready-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .element__ready__snippet__content .toolbar button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                    // Padding
                    $this->add_responsive_control(
                        'copy_btn_padding',
                        [
                            'label'      => __( 'Padding', 'element-ready-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .element__ready__snippet__content .toolbar button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                $this->end_controls_tab();

                $this->start_controls_tab(
                    'copy_btn_hover_tab',
                    [
                        'label' => __( 'Hover', 'element-ready-pro' ),
                    ]
                );

                    //Hover Color
                    $this->add_control(
                        'copy_btn_hover_color',
                        [
                            'label'     => __( 'Color', 'element-ready-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} :hover .element__ready__snippet__content .toolbar button, {{WRAPPER}} :focus .element__ready__snippet__content .toolbar button' => 'color: {{VALUE}};',
                            ],
                        ]
                    );

                    // Hover Background
                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'copy_btn_hover_background',
                            'label'    => __( 'Background', 'element-ready-pro' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} :hover .element__ready__snippet__content .toolbar button,{{WRAPPER}} :focus .element__ready__snippet__content .toolbar button',
                        ]
                    );	

                    // Border
                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'copy_btn_hover_border',
                            'label'    => __( 'Border', 'element-ready-pro' ),
                            'selector' => '{{WRAPPER}} :hover .element__ready__snippet__content .toolbar button,{{WRAPPER}} :hover .element__ready__snippet__content .toolbar button',
                        ]
                    );

                    // Radius
                    $this->add_responsive_control(
                        'copy_btn_hover_radius',
                        [
                            'label'      => __( 'Border Radius', 'element-ready-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} :hover .element__ready__snippet__content .toolbar button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                    // Shadow
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'copy_btn_hover_shadow',
                            'selector' => '{{WRAPPER}} :hover .element__ready__snippet__content .toolbar button',
                        ]
                    );
                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();
        /*----------------------------
            CODE COPY BUTTON END
        -----------------------------*/
    }

    protected function render( $instance = [] ) {
        $settings = $this->get_settings_for_display();        
        $this->add_render_attribute( 'element_ready_snippet_wrap_attr', 'class', 'element__ready__snippet__content' );

        $this->add_render_attribute( 'snippet_language_attr', 'class', $settings['content_layout_style'] );

        /*-------------------------------
            MATCH BRACES
        --------------------------------*/
        if( 'yes' == $settings['match_braces'] ){
            $this->add_render_attribute( 'snippet_language_attr', 'class', 'match-braces' );
        }

        /*-------------------------------
            ADD LANGUAGE IN PARENT
        --------------------------------*/
        $this->add_render_attribute( 'snippet_options', 'class', $settings['content_layout_style'] );
        
        /*-------------------------------
            SHOW LINE NUMBER
        --------------------------------*/
        if( 'yes' == $settings['show_line_number'] ){
            $this->add_render_attribute( 'snippet_options', 'class', 'line-numbers' );
        }

        /*-------------------------------
            COMMAND LINE
        --------------------------------*/
        if( 'yes' == $settings['show_command_line'] ){
            $this->add_render_attribute( 'snippet_options', 'class', 'command-line' );
        }
        if( 'yes' == $settings['show_command_line'] && !empty( $settings['command_line_user'] ) ){
            $this->add_render_attribute( 'snippet_options', 'data-user', $settings['command_line_user'] );
        }
        if( 'yes' == $settings['show_command_line'] && !empty( $settings['command_line_host'] ) ){
            $this->add_render_attribute( 'snippet_options', 'data-host', $settings['command_line_host'] );
        }

        /*-------------------------------
            JSON HIGHTLIGHT
        --------------------------------*/
        if( 'yes' == $settings['show_json_highligh'] && !empty( $settings['content_json_url'] ) ){
            $this->add_render_attribute( 'snippet_options', 'data-jsonp', $settings['content_json_url'] );
            $this->add_render_attribute( 'snippet_options', 'class', 'language-javascript' );
        }

        /*-------------------------------
            DOWNLOAD CODE FILE
        --------------------------------*/
        if( 'yes' == $settings['show_download_code'] && !empty( $settings['download_content_url'] ) ){
            $this->add_render_attribute( 'snippet_options', 'data-src', $settings['download_content_url'] );
            $this->add_render_attribute( 'snippet_options', 'data-download-link' );
            $this->add_render_attribute( 'snippet_options', 'data-download-link-label', $settings['download_button_text'] );
        }
    ?>
        <div <?php echo $this->get_render_attribute_string('element_ready_snippet_wrap_attr'); ?>>
            <?php if( 'yes' == $settings['show_json_highligh'] && !empty( $settings['content_json_url'] ) ) : ?>
            <pre <?php echo $this->get_render_attribute_string('snippet_options'); ?>></pre>
            <?php else : ?>
            <pre <?php echo $this->get_render_attribute_string('snippet_options'); ?>>
                <code <?php echo $this->get_render_attribute_string('snippet_language_attr'); ?>>
                    <?php echo esc_html( $settings['content_snippet'] ); ?>
                </code>
            </pre>
            <?php endif; ?>
        </div>
    <?php
    }
}