<div class="element-ready-admin-dashboard-container element-ready-pro-scb wrap">
     <div class="quomodo-container-wrapper">
          <div class="quomodo-row-wrapper">
               <div class="element-ready-component-form-wrapper components">
                    <div class="element-ready-components-topbar">
                         <div class="element-ready-title">
                         <h3 class="title"><i class="dashicons dashicons-welcome-widgets-menus"></i> <?php echo esc_html__('Widget Builder','element-ready'); ?> </h3>
                         </div>
 
                         <div class="element-ready-savechanges">
                         <a class="element-ready-scb-button-common" href="<?php echo admin_url( 'edit.php?post_type=erp_scb_builder' ); ?>"><?php echo esc_html__('Back To list','element-ready-pro'); ?></a>
                         <a class="element-ready-scb-button-common" href="<?php echo admin_url( 'post-new.php?post_type=erp_scb_builder' ); ?>"><?php echo esc_html__('Add New','element-ready-pro'); ?></a>
                              <button type="submit" class="element-ready-component-submit button element-ready-submit-btn er-scb-save-widget-settings"><i class="dashicons dashicons-yes"></i> <?php echo esc_html__('Save Change','element-ready'); ?></button>
                         </div>
                    </div>
                    <div id="element-ready-scb-tabs-header">
                         <div class="element-ready-scb-heading-container">
                              <div class="quomodo-row quomodo-no-gutters">
                                 
                                   <div class="quomodo-col-12">
                                        <ul>
                                             <li><a href="#element-ready-header-tab2"><?php echo get_the_title(sanitize_text_field($_REQUEST['post_id'])); ?></a></li>
                                        </ul> 
                                   </div> 
                                   
                              </div>
                         </div>
                       
                         <div id="element-ready-header-tab2">
                              <div class="quomodo-row">
                                   <div class="quomodo-col-lg-12">
                                        <div id="element-ready-scb-tabs">
                                             <div class="quomodo-row">
                                                  <div class="quomodo-col-2">
                                                       <ul>
                                                            <li><a href="#er-scb-tabs-1"><?php echo esc_html__('General','element-ready-pro'); ?></a></li>
                                                            <li><a href="#er-scb-tabs-2"><?php echo esc_html__('Controls','element-ready-pro'); ?></a></li>
                                                            <li><a href="#er-scb-tabs-3"><?php echo esc_html__('Html','element-ready-pro'); ?></a></li>
                                                            <li><a href="#er-scb-tabs-4"><?php echo esc_html__('Css','element-ready-pro'); ?></a></li>
                                                            <li><a href="#er-scb-tabs-5"><?php echo esc_html__('JS','element-ready-pro'); ?></a></li>
                                                            <li><a href="#er-scb-tabs-6"><?php echo esc_html__('Includes','element-ready-pro'); ?></a></li>
                                                            <li><a href="#er-scb-tabs-7"><?php echo esc_html__('Media','element-ready-pro'); ?></a></li>
                                                          
                                                       </ul>
                                                  </div>
                                                  <div class="quomodo-col-10">
                                                       <div id="er-scb-tabs-1" class="er-scb-widget-details">
                                                            
                                                               <div class="quomodo-row">
                                                                     <div class="quomodo-col-6">
                                                                          
                                                                           <fieldset>

                                                                                <legend><?php echo esc_html__('Shortcode Basic','element-ready-pro') ?>:</legend>
                                                                                <label for="widget-title"><?php echo esc_html__('Title','element-ready-pro') ?>:*</label>
                                                                                <input type="text" id="er-scb-widget-title" name="er-scb-widget-title" value="<?php echo get_the_title(sanitize_text_field($_REQUEST['post_id'])); ?>"><br><br>

                                                                                <label for="widget-name"><?php echo esc_html__('Name','element-ready-pro') ?>:*</label>
                                                                                <input readonly type="text" id="er-scb-widget-name" name="er-scb-widget-name"><br><br>
                                                                                
                                                                                <label for="widget-keyword"><?php echo esc_html__('Keyword','element-ready-pro') ?>:</label>
                                                                                <input type="text" id="er-scb-widget-keyword" name="er-scb-widget-keyword"><br><br>
                                                                                <label for="widget-desc"><?php echo esc_html__('About widget','element-ready-pro') ?>:</label>
                                                                                <textarea rows="5" cols="5" name="er-scb-widget-desc"> <?php echo get_the_content(null,false,sanitize_text_field($_REQUEST['post_id'])) ?> </textarea>
                                                                      
                                                                           </fieldset>
                                                                       
                                                                     </div>
                                                               </div> 
                                                           
                                                       </div>
                                                       <div id="er-scb-tabs-2">
                                                            <div class="quomodo-row">
                                                                 <div class="quomodo-col-12">
                                                                      <div style="display:none"> 
                                                                      <h3> <?php echo esc_html__('Enable Controls','element-ready-pro') ?>:</h3>
                                                                      <input type="radio" name="er-scb-dep-libs" value="yes"/>
                                                                      <label> <?php echo esc_html__('Yes','element-ready-pro'); ?>  </label>
                                                                      <input type="radio" name="er-scb-dep-libs" value="no"/>
                                                                      <label> <?php echo esc_html__('No','element-ready-pro'); ?>  </label>
                                                                      <hr/>
                                                                      </div>
                                                                      <div id="er-scb-content-control-modal" style="display:none;">
                                                                           <div class="er-scb-content-control-header">
                                                                                    
                                                                                    
                                                                                    <div class="erp-scb-control-container">
                                                                                          <div class="erp-scb-control-item">
                                                                                               <div class="quomodo-row er-quomodo-row">
                                                                                                    <div class="quomodo-col-6">
                                                                                                         <button id="er-scb-control-submit-to-table" class="element-ready-scb-add-new er-scb-control-submit-to-table"> <?php echo esc_html__('Save','element-ready-pro'); ?> </button>
                                                                                                    </div> 
                                                                                                  
                                                                                               </div> 
                                                                                          </div> 
                                                                                          <div class="erp-scb-control-item">
                                                                                               <div class="erp-scb-style-control-name">
                                                                                                    <div class="quomodo-row er-quomodo-row">
                                                                                                         <div class="quomodo-col-4">
                                                                                                             <label> <?php echo esc_html__('Title','element-ready-pro'); ?> </label>
                                                                                                         </div>
                                                                                                         <div class="quomodo-col-8">
                                                                                                             <input type="text" class="er-scb-attr-control-title" />
                                                                                                         </div>
                                                                                                    </div>
                                                                                               </div>
                                                                                          </div>
                                                                                          <div class="erp-scb-control-item" id="er-scb-builder-control-type">

                                                                                               <div class="erp-scb-control-type">
                                                                                                    <div class="quomodo-row er-quomodo-row">
                                                                                                         <div class="quomodo-col-4">
                                                                                                            <label> <?php echo esc_html__('Control Type','element-ready-pro'); ?> </label>
                                                                                                         </div> 
                                                                                                         <div class="quomodo-col-8">
                                                                                                              <select name="er-scb-control-type" class="er-scb-control-type" id="er-scb-attr-control-type">
                                                                                                                   <option value="style"> <?php echo esc_html__('Style','element-ready-pro'); ?> </option>
                                                                                                                   <option value="content"><?php echo esc_html__('Content','element-ready-pro'); ?></option>
                                                                                                              </select>      
                                                                                                         </div>    
                                                                                                    </div>
                                                                                               </div>
                                                                                              
                                                                                          </div>
                                                                                          <div class="erp-scb-control-item" id="er-scb-builder-control-content-type">
                                                                                               
                                                                                               <div class="erp-scb-content-control-type">
                                                                                                    <div class="quomodo-row er-quomodo-row">
                                                                                                         <div class="quomodo-col-4">
                                                                                                              <label> <?php echo esc_html__('Content Control','element-ready-pro'); ?> </label>
                                                                                                         </div> 
                                                                                                         <div class="quomodo-col-8">
                                                                                                              <select name="er-scb-control-type" class="er-scb-control-type" id="er-scb-control-type">
                                                                                                                   
                                                                                                                   <option value="text"> <?php echo esc_html__('Text','element-ready-pro'); ?> </option>
                                                                                                                   <option value="number"> <?php echo esc_html__('Number','element-ready-pro'); ?> </option>
                                                                                                                   <option value="textarea"> <?php echo esc_html__('TextArea','element-ready-pro'); ?> </option>
                                                                                                                   <option value="editor"> <?php echo esc_html__('Editor','element-ready-pro'); ?> </option>
                                                                                                                   <option value="choose"> <?php echo esc_html__('Choose ','element-ready-pro'); ?> </option>
                                                                                                                   <option value="media"> <?php echo esc_html__('Media','element-ready-pro'); ?> </option>
                                                                                                                   <option value="date-time"> <?php echo esc_html__('Date Time','element-ready-pro'); ?> </option>
                                                                                                                   <option value="url"><?php echo esc_html__('Url','element-ready-pro'); ?></option>
                                                                                                                   <option value="icon"><?php echo esc_html__('Icon','element-ready-pro'); ?></option>
                                                                                                                   <option value="select"><?php echo esc_html__('Select','element-ready-pro'); ?></option>
                                                                                                                   <option value="select2"><?php echo esc_html__('Select2','element-ready-pro'); ?></option>
                                                                                                                   <option value="post"><?php echo esc_html__('Posts','element-ready-pro'); ?></option>
                                                                                                                   <option value="social-repeater"><?php echo esc_html__('Social Repeater','element-ready-pro'); ?></option>
                                                                                                                   <option value="repeater"><?php echo esc_html__('Repeater','element-ready-pro'); ?></option>
                                                                                                             
                                                                                                              </select> 
                                                                                                         </div> 
                                                                                                    </div> 
                                                                                               </div>
                                                                                          </div>

                                                                                          <div class="erp-scb-control-item" id="erp-scb-builder-style-control-type">
                                                                                               <div class="erp-scb-style-control-type">
                                                                                                    <div class="quomodo-row er-quomodo-row">
                                                                                                         <div class="quomodo-col-4">
                                                                                                              <label> <?php echo esc_html__('Style Control','element-ready-pro'); ?> </label>
                                                                                                         </div> 
                                                                                                         <div class="quomodo-col-8">
                                                                                                              <select name="er-scb-control-type" class="er-scb-style-control-type" id="er-scb-style-control-type">
                                                                                                                   <option value="color"> <?php echo esc_html__('Color','element-ready-pro'); ?> </option>
                                                                                                                   <option value="background"> <?php echo esc_html__('Background','element-ready-pro'); ?> </option>
                                                                                                                   <option value="typhography"> <?php echo esc_html__('Typhography','element-ready-pro'); ?> </option>
                                                                                                                   <option value="border"> <?php echo esc_html__('Border','element-ready-pro'); ?> </option>
                                                                                                                   <option value="border-radius"> <?php echo esc_html__('Border Radius','element-ready-pro'); ?> </option>
                                                                                                                   <option value="slider-width"> <?php echo esc_html__('Slider Width','element-ready-pro'); ?> </option>
                                                                                                                   <option value="slider-height"> <?php echo esc_html__('Slider Height','element-ready-pro'); ?> </option>
                                                                                                                   <option value="margin"> <?php echo esc_html__('Margin','element-ready-pro'); ?> </option>
                                                                                                                   <option value="padding"> <?php echo esc_html__('Padding','element-ready-pro'); ?> </option>
                                                                                                                   <option value="box-shadow"> <?php echo esc_html__('Box Shadow','element-ready-pro'); ?> </option>
                                                                                                                   <option value="text-shadow"> <?php echo esc_html__('Text Shadow','element-ready-pro'); ?> </option>
                                                                                                                   <option value="box-preset"> <?php echo esc_html__('Box','element-ready-pro'); ?> </option>
                                                                                                                   <option value="basic-preset"> <?php echo esc_html__('Basic Preset','element-ready-pro'); ?> </option>
                                                                                                              </select> 
                                                                                                         </div> 
                                                                                                    </div> 
                                                                                               </div>
                                                                                          </div>

                                                                                          <div class="erp-scb-control-item" id="er-scb-cont-builder-default-value">
                                                                                               <div class="erp-scb-style-control-name er-scb-cont-default-value">
                                                                                                    <div class="quomodo-row er-quomodo-row">
                                                                                                         <div class="quomodo-col-4">
                                                                                                              <label> <?php echo esc_html__('Default Value','element-ready-pro'); ?> </label>
                                                                                                         </div> 
                                                                                                         <div class="quomodo-col-8">
                                                                                                              <input type="text" class="er-scb-attr-control-default-value" />
                                                                                                         </div> 
                                                                                                    </div> 
                                                                                               </div>
                                                                                          </div>

                                                                                          <div class="erp-scb-control-item" id="er-scb-cont-builder-css-selector-value" style="display:block">
                                                                                               <div class="erp-scb-style-control-name er-scb-cont-builder-css-selector">
                                                                                                    <div class="quomodo-row er-quomodo-row">
                                                                                                         <div class="quomodo-col-4">
                                                                                                              <label> <?php echo esc_html__('Css selector','element-ready-pro'); ?> </label>
                                                                                                         </div> 
                                                                                                         <div class="quomodo-col-8">
                                                                                                              <input type="text" class="er-scb-attr-control-css-selector-value" />
                                                                                                         </div> 
                                                                                                    </div> 
                                                                                               </div>
                                                                                          </div>

                                                                                          <div class="erp-scb-control-item" id="er-scb-cont-builder-choose-value">
                                                                                               <div class="erp-scb-style-control-choose er-scb-cont-choose-value">
                                                                                                    <div class="quomodo-row er-quomodo-row">
                                                                                                         <div class="quomodo-col-4">
                                                                                                              <label> <?php echo esc_html__('Choose Value','element-ready-pro'); ?> </label>
                                                                                                         </div> 
                                                                                                         <div class="quomodo-col-8">
                                                                                                              <input type="text" class="er-scb-builder-control-choose-value" />
                                                                                                              <button class="er-scb-builder-control-chosse-add"> <?php echo esc_html__('Add','element-ready-pro'); ?> </button>
                                                                                                              <br/>
                                                                                                              <div class="er-scb-builder-choose-controls-option" id="er-scb-builder-choose-controls-item"></div> 
                                                                                                         </div> 
                                                                                                    </div> 
                                                                                               </div>
                                                                                          </div>

                                                                                          <div class="erp-scb-control-item" id="er-scb-cont-builder-repeater-value">
                                                                                               <div class="erp-scb-style-control-choose er-scb-cont-repeater-value">
                                                                                                    <div class="quomodo-row er-quomodo-row">
                                                                                                         <div class="quomodo-col-4">
                                                                                                              <label> <?php echo esc_html__('Repeater Item','element-ready-pro'); ?> </label>
                                                                                                         </div> 
                                                                                                         <div class="quomodo-col-8">
                                                                                                              <div class="er-repeater-widget-new-control-fld" >
                                                                                                                   *<input required="required" type="text" placeholder="title here" value="" id="er-scb-widget-repeater-title-value-add" />     
                                                                                                                   <input type="text"  value="" placeholder="default value" id="er-scb-widget-repeater-default-value-add" />     
                                                                                                                   <select name="er-scb-repeater-control-type" class="er-scb-builder-control-repeater-value" id="er-scb-builder-control-repeater-control-type">
                                                                                                                        <optgroup label="Content Type">
                                                                                                                             <option value="text"> <?php echo esc_html__('Text','element-ready-pro'); ?> </option>
                                                                                                                             <option value="number"> <?php echo esc_html__('Number','element-ready-pro'); ?> </option>
                                                                                                                             <option value="textarea"> <?php echo esc_html__('TextArea','element-ready-pro'); ?> </option>
                                                                                                                             <option value="editor"> <?php echo esc_html__('Editor','element-ready-pro'); ?> </option>
                                                                                                                             <option value="media"> <?php echo esc_html__('Media','element-ready-pro'); ?> </option>
                                                                                                                             <option value="date-time"> <?php echo esc_html__('Date Time','element-ready-pro'); ?> </option>
                                                                                                                             <option value="url"><?php echo esc_html__('Url','element-ready-pro'); ?></option>
                                                                                                                             <option value="icon"><?php echo esc_html__('Icon','element-ready-pro'); ?></option>
                                                                                                                        
                                                                                                                             
                                                                                                                        </optgroup>
                                                                                                                        <!-- Style Control -->
                                                                                                                        <!-- <optgroup label="Style Type">
                                                                                                                             <option value="color-erstyle"> <?php echo esc_html__('Color','element-ready-pro'); ?> </option>
                                                                                                                             <option value="background-erstyle"> <?php echo esc_html__('Background','element-ready-pro'); ?> </option>
                                                                                                                             <option value="typhography-erstyle"> <?php echo esc_html__('Typhography','element-ready-pro'); ?> </option>
                                                                                                                             <option value="border-erstyle"> <?php echo esc_html__('Border','element-ready-pro'); ?> </option>
                                                                                                                             <option value="border-radius-erstyle"> <?php echo esc_html__('Border Radius','element-ready-pro'); ?> </option>
                                                                                                                             <option value="slider-width-erstyle"> <?php echo esc_html__('Slider Width','element-ready-pro'); ?> </option>
                                                                                                                             <option value="slider-height-erstyle"> <?php echo esc_html__('Slider Height','element-ready-pro'); ?> </option>
                                                                                                                             <option value="margin-erstyle"> <?php echo esc_html__('Margin','element-ready-pro'); ?> </option>
                                                                                                                             <option value="padding-erstyle"> <?php echo esc_html__('Padding','element-ready-pro'); ?> </option>
                                                  
                                                                                                                        </optgroup> -->
                                                                                                                   </select> 
                                                                                                              </div>
                                                                                                              <button class="er-scb-builder-control-repeater-add"> <?php echo esc_html__('Add','element-ready-pro'); ?> </button>
                                                                                                              
                                                                                                              <br/>
                                                                                                              <div class="er-scb-builder-repeater-controls-option" id="er-scb-builder-repeater-controls-item"></div> 

                                                                                                         </div> 
                                                                                                    </div> 
                                                                                               </div>
                                                                                          </div>
                         
                                                                                     </div>
                                                                           </div>
                                                                      </div>
                                                                      
                                                                      <div class="er-scb-add-new-control-header"> 
                                                                         <a href="#TB_inline?&width=600&height=550&inlineId=er-scb-content-control-modal" class="thickbox er-scb-control-add"><?php echo esc_html__('Add Controls','element-ready-pro'); ?></a>
                                                                      </div> 
                                                                    
                                                                      <div class="er-scb-item-attr-container" id="er-scb-item-attr-container-table">
                                                                            
                                                                      </div>     
                                                                 </div>
                                                            </div> 
                                                       </div>
                                                       <div id="er-scb-tabs-3" class="er-scb-widget-details er-html">
                                                                 <div class="quomodo-row">
                                                                     <div class="quomodo-col-12">
                                                                           
                                                                           <div class="er-scb-controls-html-section-header">
                                                                               <h3><?php echo esc_html__('Controls List: ','element-ready-pro') ?>: Use this below field in html</h3>
                                                                           </div>
                                                                          
                                                                           <div class="er-scb-controls-html-list-options" id="er-scb-controls-html-list-options">
                                                                                
                                                                           </div>
                                                                           <h3><?php echo esc_html__('Html','element-ready-pro') ?>:</h3>
                                                                           <textarea id="er-scb-builder-widget-html-content" rows="20" cols="15" name="er-scb-widget-html"> </textarea>
                                                                        
                                                                            
                                                                      </div>
                                               
                                                                 </div> 
                                                                 <div class="quomodo-row">    
                                                                     <div class="quomodo-col-12">
                                                                           <h3><?php echo esc_html__('Repeater Html','element-ready-pro') ?>:</h3>
                                                                           <div class="quomodo-row">
                                                                                <div class="quomodo-col-12"> 
                                                                                    <select name="repeater-html-one" id="er-scb-controls-html-repeater-list-options"> </select>
                                                                                </div>
                                                                                <div class="quomodo-col-12">
                                                                                     <div class="er-scb-controls-repeater-html-list-options-keys" id="er-scb-controls-repeater-html-list-options-keys">
                                                                                     
                                                                                     </div>  
                                                                                </div>
                                                                           </div>
                                                                           <div class="quomodo-row">
                                                                                <div class="quomodo-col-12">
                                                                                   <textarea id="er-scb-builder-widget-html-loop-content" rows="20" cols="15" name="er-scb-widget-html-item"> </textarea>
                                                                                </div>
                                                                           </div>       
                                                                      </div>
                                                                 </div> 
                                                                 <div class="quomodo-row">    
                                                                     <div class="quomodo-col-12">
                                                                           <h3><?php echo esc_html__('Repeater Html Two','element-ready-pro') ?>:</h3>
                                                                           <div class="quomodo-row">
                                                                                <div class="quomodo-col-12"> 
                                                                                    <select name="repeater-html-two" id="er-scb-controls-html-repeater-list-options2"> </select>
                                                                                </div>
                                                                                <div class="quomodo-col-12">
                                                                                     <div class="er-scb-controls-repeater-html-list-options-keys2" id="er-scb-controls-repeater-html-list-options-keys2">
                                                                                     
                                                                                     </div>  
                                                                                </div>
                                                                           </div>
                                                                           <div class="quomodo-row">
                                                                                <div class="quomodo-col-12">
                                                                                   <textarea id="er-scb-builder-widget-html-loop-content2" rows="20" cols="15" name="er-scb-widget-html-item2"> </textarea>
                                                                                </div>
                                                                           </div>       
                                                                      </div>
                                                                 </div> 
                                                       </div>
                                                       <div id="er-scb-tabs-4" class="er-css er-scb-widget-details">
                                                                 <div class="quomodo-row">
                                                                     <div class="quomodo-col-12">
                                                                           <h3><?php echo esc_html__('Css','element-ready-pro') ?>:</h3>
                                                                           <textarea id="er-scb-builder-widget-css-content" rows="20" cols="15" name="er-scb-widget-css"> </textarea>
                                                                     </div>
                                                                 </div> 
                                                       </div>
                                                       <div id="er-scb-tabs-5" class="er-js er-scb-widget-details">
                                                                 <div class="quomodo-row">
                                                                     <div class="quomodo-col-12">
                                                                           <h3><?php echo esc_html__('JS','element-ready-pro') ?>:</h3>
                                                                           <textarea id="er-scb-builder-widget-js-content" rows="20" cols="15" name="er-scb-widget-js"> </textarea>
                                                                     </div>
                                                                 </div>
                                                       </div>
                                                       <div id="er-scb-tabs-6" class="er-asset-inlcude">
                                                                 <div class="quomodo-row">
                                                                     <div class="quomodo-col-12">
                                                                           <h3><?php echo esc_html__('Dynamic Assets','element-ready-pro') ?>:</h3>
                                                                     </div>
                                                                     <div class="quomodo-col-10">

                                                                           <div class="er-scb-dynamic-content">
                                                                                <div class="er-scb-dependent-lib">
                                                                                    
                                                                                </div> 
                                                                           </div>

                                                                           <div class="er-scb-dependent-load">
                                                                              <h3 class="er-scb-cdn-libs-title">
                                                                                    <?php echo esc_html__('Load CDN library'); ?>
                                                                              </h3>     
                                                                           </div>
                                                                           <div class="er-scb-dependent-load-cdn">
                                                                                
                                                                               <div class="er-scb-cdn-library-list">
                                                                                     <div class="erp-scb-cdn-container">
                                                                                          <div class="erp-scb-cdn-item">
                                                                                          
                                                                                          <div class="erp-scb-cdn-type">
                                                                                               <select name="er-scb-cdn-assets-type" id="er-scb-cdn-assets">
                                                                                                    <option value="js"> <?php echo esc_html__('JS','element-ready-pro'); ?> </option>
                                                                                                    <option value="css"><?php echo esc_html__('CSS','element-ready-pro'); ?></option>
                                                                                               </select>   
                                                                                          </div>

                                                                                          <div class="erp-scb-cdn-name">
                                                                                               <input id="er-scb-cdn-assets-name" placeholder="place title" type="text" value="" name="er-scb-cdn-assets-name" />
                                                                                          </div>
                                                                                          <div class="erp-scb-cdn-link">
                                                                                               <input id="er-scb-cdn-assets-url" placeholder="place cdn url" type="text" value="" name="er-scb-cdn-assets-url" />
                                                                                          </div>
                                                                                          
                                                                                          </div>
                                                                                          <div class="erp-scb-cdn-add">
                                                                                               <button class="erp-scb-cdn-button element-ready-scb-add-new"> <?php echo esc_html__('Add','element-ready-pro'); ?>  </button> 
                                                                                          </div>
                                                                                     </div>
                                                                               </div>

                                                                           </div>

                                                                     </div>
                                                                 </div>
                                                       </div>
                                                       <div id="er-scb-tabs-7">
                                                            <div class="quomodo-row">
                                                                 <div class="quomodo-col-12">
                                                                      <h3><?php echo esc_html__('Media','element-ready-pro') ?>:</h3>
                                                                 </div>
                                                            </div>
                                                       </div>
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </div> <!-- container end -->
</div>

<div id="er_scb_builder_overlayWrapper">
     <div id="er_scb_builder_overlay"> Saving settings </div>
</div>