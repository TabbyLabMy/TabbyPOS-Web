<?php
/**
 * @package  appie-essential
 */
namespace AppieEssential\Base;

class Activate
{
	public static function activate() {
		flush_rewrite_rules();
	}
}