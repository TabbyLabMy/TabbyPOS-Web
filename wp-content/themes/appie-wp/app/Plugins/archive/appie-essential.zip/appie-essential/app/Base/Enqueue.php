<?php 
/**
 * @package  appie-essential
 */
namespace AppieEssential\Base;
use AppieEssential\Base\BaseController;

/**
* 
*/
class Enqueue extends BaseController
{
	public function register() {
		
	}


}