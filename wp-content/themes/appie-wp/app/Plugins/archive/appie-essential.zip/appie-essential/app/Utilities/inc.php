<?php 
/*
include all required functional file here like template tags, function ,helper .
*/

require_once dirname( __FILE__ ) . '/Inc/functions.php';
require_once dirname( __FILE__ ) . '/Inc/Hooks.php';



