<?php
/**
 * @package  Appscres-essential
 */
namespace AppieEssential\Base;

class Deactivate
{
	public static function deactivate() {
		flush_rewrite_rules();
	}
}