<?php 
/**
 * @package  quomodo
 */
namespace AppieEssential\Base;

class BaseController
{
	public $plugin_path;

	public $plugin_url;

	public $plugin;

	public function __construct() {
		$this->plugin_path = APPIE_ESSENTIAL_PLUGIN_PATH;
		$this->plugin_url  = APPIE_ESSENTIAL_PLUGIN_URL;
		$this->plugin      = APPIE_ESSENTIAL_PLUGIN;
	}
}