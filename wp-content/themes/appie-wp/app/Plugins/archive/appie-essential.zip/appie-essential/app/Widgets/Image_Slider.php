<?php
namespace AppieEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit;


class Image_Slider extends Widget_Base {


    public $base;

    public function get_name() {
        return 'appie-image-carousel';
    }

    public function get_title() {
        return esc_html__( 'Appie Image Carousel', 'appie-essential' );
    }

    public function get_keywords() {
		return [ 'appie', 'image-carousel' ];
	}

    public function get_icon() { 
        return 'eicon-testimonial';
    }

    public function get_categories() {
        return [ 'appie-elements' ];
    }

    public function get_script_depends() {
		return[
			'slick'
		];
	}

    protected function register_controls() { 

      $this->start_controls_section('section_tab',
         [
             'label' => esc_html__('Settings', 'appie-essential'),
         ]
      );

      $this->add_control(
        'style',
        [
            'label' => esc_html__( 'Style', 'appie-essential' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'style1',
            'options' => [
                'style1' => esc_html__( 'Style 1', 'appie-essential' ),
               
            ],
        ]
    );
 
      $repeater = new \Elementor\Repeater();
        
      $repeater->add_control(
       'title', [
           'label'       => esc_html__( 'Name', 'appie-essential' ),
           'type'        => Controls_Manager::TEXT,
           'label_block' => true,
           'placeholder' => esc_html__( 'Title here', 'appie-essential' ),
           'default'     => esc_html__( 'ThGet Amazing Support With', 'appie-essential' ),
           
       ]
      );

    
   
      $repeater->add_control(
       'image',
       [
           'label'   => esc_html__( 'Image', 'appie-essential' ),
           'type'    => \Elementor\Controls_Manager::MEDIA,
           'default' => [
               'url' => \Elementor\Utils::get_placeholder_image_src(),
           ],
       ]
      );

 

       $this->add_control(
           'list',
           [
               'label'       => esc_html__( 'List', 'appie-essential' ),
               'type'        => \Elementor\Controls_Manager::REPEATER,
               'fields'      => $repeater->get_controls(),
               'title_field' => '{{{ title }}}',
           ]
       );
    
     
     $this->end_controls_section();
     

      $this->start_controls_section(
			'section_style', [
				'label' => esc_html__( 'Image', 'appie-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			  ]
      );

      $this->add_responsive_control(
			'image_height',
			[
				'label'      => esc_html__( 'Height', 'appie-essential' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 5,
						'max'  => 200,
						'step' => 1,
					],
					
				],
				
				'selectors' => [
					'{{WRAPPER}} .appie-video-player-slider img' => 'height: {{SIZE}}{{UNIT}};',
			
				],
			]
        );
        $this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Width', 'appie-essential' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 5,
						'max'  => 200,
						'step' => 1,
					],
					
				],
				
				'selectors' => [
				
					'{{WRAPPER}} .appie-video-player-slider img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
        );   
          
      $this->end_controls_section();  
   

      $this->start_controls_section(
        'section_main', [
            'label' => esc_html__( 'Section', 'appie-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
          ]
      );

            $this->add_responsive_control(
                'sections-padding',
                [
                    'label'      => esc_html__( 'Padding', 'appie-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .appie-video-player-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'sections-margin',
                [
                    'label'      => esc_html__( 'Margin', 'appie-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .appie-video-player-slider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
       

      $this->end_controls_section();  

 

      $this->start_controls_section(
        'slider_nav_box_style', [
            'label' => esc_html__( 'Slider nav', 'appie-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'slider_nav__color', [

            'label'     => esc_html__( 'Color', 'appie-essential' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
            '{{WRAPPER}} .slick-arrow i' => 'color: {{VALUE}};',
           
            ],
        ]
    );

    $this->add_control(
        'slider_nav_bg_color', [

            'label'     => esc_html__( 'BGColor', 'appie-essential' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
            '{{WRAPPER}} .appie-video-player-slider .slick-arrow' => 'Background: {{VALUE}};',
            
            
            ],
        ]
    );

    $this->add_control(
       'slider_nav_bg_hv_color', [

           'label'     => esc_html__( 'Hover BGColor', 'appie-essential' ),
           'type'      => Controls_Manager::COLOR,
           'selectors' => [
           '{{WRAPPER}} .appie-video-player-slider .slick-arrow:hover' => 'Background: {{VALUE}};',
          
           ],
       ]
   );

   $this->add_group_control(
    \Elementor\Group_Control_Border::get_type(),
    [
        'name' => 'border',
        'label' => esc_html__( 'Border', 'appie-essential' ),
        'selector' => '{{WRAPPER}} .slick-arrow',
    ]
);


   $this->add_control(
       'slider_arrow_nav_prev',
       [
           'label' => esc_html__( 'Previous Right Position', 'appie-essential' ),
           'type' => \Elementor\Controls_Manager::SLIDER,
           'size_units' => [ 'px', '%' ],
           'range' => [
               'px' => [
                   'min' => 0,
                   'max' => 1000,
                   'step' => 5,
               ],
               '%' => [
                   'min' => 0,
                   'max' => 100,
               ],
           ],
          
       
           'selectors' => [
               '{{WRAPPER}} .appie-video-player-slider .slick-arrow.prev' => 'right: {{SIZE}}{{UNIT}};',
           ],
       ]
   );


   $this->add_control(
       'slider_arrow_nav_next',
       [
           'label' => esc_html__( 'Previous Right Position', 'appie-essential' ),
           'type' => \Elementor\Controls_Manager::SLIDER,
           'size_units' => [ 'px', '%' ],
           'range' => [
               'px' => [
                   'min' => 0,
                   'max' => 1000,
                   'step' => 5,
               ],
               '%' => [
                   'min' => 0,
                   'max' => 100,
               ],
           ],
          
       
           'selectors' => [
               '{{WRAPPER}} .appie-video-player-slider .slick-arrow.next' => 'right: {{SIZE}}{{UNIT}};',
           ],
       ]
   );



    $this->end_controls_section();

 
   }
   protected function render(){

     $settings = $this->get_settings();
     $list     = $settings['list'];

    
    
    ?>
    <div class="appie-video-player-slider">
        <?php foreach($list as $item): ?>
            <div class="item">
            <img src="<?php echo esc_url($item['image']['url']); ?>" alt="<?php echo esc_attr($item['title']); ?>">
            </div>
        <?php endforeach; ?>

        </div>
   <?php  
   }
}  